# Intro-Hub Rails Setup Instructions

## Downloading and Setting Up the Repository

1. Create a new folder for the project:
```
mkdir intro-hub-rails
cd intro-hub-rails
```

2. Initialize a Git repository:
```
git init
```

3. Create the following directory structure:
```
intro-hub-rails/
├── app/
│   ├── controllers/
│   │   ├── api/
│   │   │   ├── v1/
│   │   │   └── base_controller.rb
│   │   ├── application_controller.rb
│   │   └── concerns/
│   ├── models/
│   ├── serializers/
│   ├── services/
│   │   └── auth/
│   └── mailers/
│   │   └── views/
│   │       └── introduction_mailer/
├── config/
│   ├── initializers/
│   └── environments/
├── db/
│   └── migrate/
```

You can create this structure with the following commands:
```
mkdir -p app/controllers/api/v1
mkdir -p app/controllers/concerns
mkdir -p app/models
mkdir -p app/serializers
mkdir -p app/services/auth
mkdir -p app/mailers
mkdir -p app/views/introduction_mailer
mkdir -p config/initializers
mkdir -p config/environments
mkdir -p db/migrate
```

4. Create each file from the provided code and place it in the appropriate folder.

## Models

Create the following files:

**app/models/user.rb**
```ruby
class User < ApplicationRecord
  has_secure_password
  
  # Relations
  has_many :contacts, dependent: :destroy
  has_many :sent_requests, class_name: 'IntroductionRequest', foreign_key: 'requester_id', dependent: :destroy
  has_many :received_requests, class_name: 'IntroductionRequest', foreign_key: 'approver_id', dependent: :destroy
  
  # Validations
  validates :email, presence: true, uniqueness: { case_sensitive: false }
  validates :email, format: { with: URI::MailTo::EMAIL_REGEXP }
  validates :password, length: { minimum: 6 }, if: -> { password.present? }
  validates :first_name, :last_name, presence: true
  