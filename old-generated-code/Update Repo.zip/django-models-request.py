from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _


class IntroductionRequest(models.Model):
    def __str__(self):
        return f"Request from {self.requester} to {self.contact.full_name}"
    
    def mark_as_approved(self):
        """
        Mark the request as approved
        """
        self.status = 'approved'
        self.save()
        
    def mark_as_denied(self):
        """
        Mark the request as denied
        """
        self.status = 'denied'
        self.save()
        
    def mark_as_completed(self):
        """
        Mark the request as completed
        """
        from django.utils import timezone
        
        self.status = 'completed'
        self.completed_at = timezone.now()
        self.save()
    """
    Represents a request for introduction between a user and a contact
    """
    STATUS_CHOICES = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('denied', 'Denied'),
        ('completed', 'Completed'),
    ]
    
    requester = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='sent_requests'
    )
    contact_owner = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        on_delete=models.CASCADE,
        related_name='received_requests'
    )
    contact = models.ForeignKey(
        'Contact',
        on_delete=models.CASCADE,
        related_name='introduction_requests'
    )
    status = models.CharField(
        max_length=20,
        choices=STATUS_CHOICES,
        default='pending'
    )
    purpose = models.TextField()
    message = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(null=True, blank=True)
    
    class Meta:
        verbose_name = _('introduction request')
        verbose_name_plural = _('introduction requests')
        ordering = ['-created_at']
        indexes = [
            models.Index(fields=['requester']),
            models.Index(fields=['contact_owner']),
            models.Index(fields=['status']),
            models.Index(fields=['created_at']),
        ]
    
    