from django.contrib import admin
from django.contrib.auth import get_user_model
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin
from introhub.models.contact import Contact
from introhub.models.request import IntroductionRequest

User = get_user_model()

# User Admin
@admin.register(User)
class UserAdmin(BaseUserAdmin):
    list_display = ('email', 'username', 'first_name', 'last_name', 'is_staff', 'is_active')
    list_filter = ('is_staff', 'is_active', 'date_joined')
    search_fields = ('email', 'username', 'first_name', 'last_name')
    ordering = ('email',)
    fieldsets = (
        (None, {'fields': ('email', 'username', 'password')}),
        ('Personal Info', {'fields': ('first_name', 'last_name', 'job_title', 'company', 'profile_image')}),
        ('Bio Info', {'fields': ('bio', 'linkedin_profile')}),
        ('Permissions', {'fields': ('is_active', 'is_staff', 'is_superuser', 'groups', 'user_permissions')}),
        ('Important Dates', {'fields': ('last_login', 'date_joined')}),
    )
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('email', 'username', 'password1', 'password2', 'is_staff', 'is_active'),
        }),
    )


# Contact Admin
@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('full_name', 'email', 'company', 'user', 'created_at')
    list_filter = ('created_at', 'user', 'company')
    search_fields = ('first_name', 'last_name', 'email', 'company')
    readonly_fields = ('created_at', 'updated_at')
    fieldsets = (
        ('Basic Information', {
            'fields': ('user', 'first_name', 'last_name', 'email', 'phone')
        }),
        ('Professional Information', {
            'fields': ('company', 'job_title', 'linkedin_profile')
        }),
        ('Relationship Information', {
            'fields': ('relationship', 'notes')
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at')
        }),
    )
    
    def full_name(self, obj):
        return f"{obj.first_name} {obj.last_name}"
    full_name.short_description = 'Name'


# Introduction Request Admin
@admin.register(IntroductionRequest)
class IntroductionRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'requester', 'contact_owner', 'contact_name', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('requester__email', 'contact_owner__email', 'contact__first_name', 'contact__last_name')
    readonly_fields = ('created_at', 'updated_at', 'completed_at')
    fieldsets = (
        ('Request Information', {
            'fields': ('requester', 'contact_owner', 'contact')
        }),
        ('Status Information', {
            'fields': ('status', 'purpose', 'message')
        }),
        ('Metadata', {
            'fields': ('created_at', 'updated_at', 'completed_at')
        }),
    )
    
    def contact_name(self, obj):
        return f"{obj.contact.first_name} {obj.contact.last_name}"
    contact_name.short_description = 'Contact'
