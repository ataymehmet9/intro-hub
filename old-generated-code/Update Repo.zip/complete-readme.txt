# Intro-Hub

A platform for facilitating warm introductions between B2B SaaS sales teams and potential leads through existing networks.

![Intro-Hub Logo](https://placehold.co/800x200?text=Intro-Hub)

## Overview

Intro-Hub connects sales professionals with relevant contacts in their extended network. The platform streamlines the process of requesting and managing introductions, helping businesses build valuable relationships through trusted connections.

### Core Features

- **Contact Management**: Upload, import, and organize your professional contacts
- **Network Search**: Find relevant connections through your extended network
- **Introduction Requests**: Request warm introductions through mutual connections
- **Approval Workflow**: Review and manage introduction requests
- **Automated Introductions**: Facilitate email introductions between connected parties
- **User Dashboard**: Track and manage all networking activities in one place

## Technology Stack

### Backend
- **Framework**: Django 4.2 + Django REST Framework
- **Database**: PostgreSQL 14
- **Authentication**: JWT (JSON Web Tokens)
- **Caching**: Redis
- **Storage**: AWS S3 (production) / Local (development)
- **Email**: SMTP with HTML templates

### Frontend
- **Framework**: React 18
- **UI Library**: Material-UI v5
- **State Management**: React Context API
- **API Client**: Axios
- **Routing**: React Router v6
- **Form Handling**: Formik + Yup

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Web Server**: Nginx
- **HTTPS**: Let's Encrypt
- **CI/CD**: GitHub Actions
- **Monitoring**: Sentry

## Getting Started

### Prerequisites

- Docker and Docker Compose
- Git
- Make (optional, for using the provided Makefile)

### Local Development Setup

1. **Clone the repository**

   ```bash
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   ```

2. **Create environment variables file**

   ```bash
   cp .env.example .env
   # Edit .env with your configuration
   ```

3. **Build and start the containers**

   ```bash
   docker-compose up -d
   ```

   Alternatively, if you have Make installed:

   ```bash
   make up
   ```

4. **Create a superuser**

   ```bash
   docker-compose exec backend python manage.py createsuperuser
   ```

5. **Access the applications**

   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000/api/
   - API Documentation: http://localhost:8000/api/schema/swagger/
   - Django Admin: http://localhost:8000/admin/

### Running Tests

```bash
# Backend tests
docker-compose exec backend python manage.py test

# Frontend tests
docker-compose exec frontend npm test
```

With Make:

```bash
make test-backend
make test-frontend
```

## Production Deployment

### Option 1: Manual Deployment

1. **Set up your production server**

   - Recommended: Ubuntu 20.04+ with at least 2GB RAM
   - Install required dependencies:

     ```bash
     sudo apt update
     sudo apt install -y docker.io docker-compose nginx certbot python3-certbot-nginx
     ```

2. **Clone the repository and configure environment**

   ```bash
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   cp .env.example .env
   # Edit .env with production values
   ```

3. **Set up SSL certificates with Let's Encrypt**

   ```bash
   ./scripts/init-letsencrypt.sh your-domain.com your-email@example.com
   ```

4. **Start the production environment**

   ```bash
   docker-compose -f docker-compose.prod.yml up -d
   ```

5. **Create a superuser for the admin panel**

   ```bash
   docker-compose -f docker-compose.prod.yml exec backend python manage.py createsuperuser
   ```

### Option 2: Using Deployment Script

1. **Set up your server as described in Option 1**

2. **Run the deployment script**

   For a full deployment with SSL certificate setup:

   ```bash
   sudo ./scripts/deploy.sh --full your-domain.com your-email@example.com
   ```

   For a deployment without SSL certificate renewal:

   ```bash
   sudo ./scripts/deploy.sh --pull --backup --migrate
   ```

   See all options:

   ```bash
   ./scripts/deploy.sh --help
   ```

### Continuous Deployment with GitHub Actions

This repository includes GitHub Actions workflows for continuous integration and deployment. To set up CD:

1. **Add repository secrets in GitHub**:
   - `DOCKERHUB_USERNAME` - Your Docker Hub username
   - `DOCKERHUB_TOKEN` - Your Docker Hub access token
   - `DEPLOY_HOST` - Your production server hostname/IP
   - `DEPLOY_USER` - SSH username
   - `DEPLOY_SSH_KEY` - SSH private key for deployment
   - `REACT_APP_API_URL` - API URL for the frontend

2. **Push to the main branch** to trigger the workflow, which will:
   - Run tests
   - Build Docker images
   - Push images to Docker Hub
   - Deploy to your production server

## Project Structure

The repository follows a modular structure with clean separation of concerns:

```
intro-hub/
├── backend/                 # Django backend
│   ├── introhub/            # Main Django app
│   │   ├── models/          # Database models
│   │   ├── serializers/     # API serializers
│   │   ├── views/           # API views
│   │   ├── services/        # Business logic
│   │   └── utils/           # Utilities
│   ├── config/              # Project settings
│   │   └── settings/        # Split settings for different environments
│   ├── templates/           # Email templates
│   └── requirements/        # Split requirements
├── frontend/                # React frontend
│   ├── public/              # Static assets
│   ├── src/
│   │   ├── components/      # Reusable UI components
│   │   ├── contexts/        # React contexts for state management
│   │   ├── hooks/           # Custom React hooks
│   │   ├── pages/           # Page components
│   │   └── services/        # API service functions
├── nginx/                   # Nginx configuration
├── scripts/                 # Utility scripts
├── docker-compose.yml       # Development configuration
├── docker-compose.prod.yml  # Production configuration
└── Makefile                 # Convenience commands
```

## Development Guidelines

### Code Style

- **Backend**: Follow PEP 8 and Django's coding style
- **Frontend**: Follow Airbnb JavaScript Style Guide and React best practices

### Git Workflow

1. Create a feature branch from `develop`
2. Make your changes and commit with descriptive messages
3. Open a pull request to merge back to `develop`
4. Once features are stable, merge `develop` into `main` for production

### Database Migrations

- Create migrations after model changes:
  ```bash
  docker-compose exec backend python manage.py makemigrations
  ```

- Apply migrations:
  ```bash
  docker-compose exec backend python manage.py migrate
  ```

- Use the migration helper script for advanced operations:
  ```bash
  ./scripts/migrate.sh help
  ```

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes and commit: `git commit -m 'Add some feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Submit a pull request

## Troubleshooting

### Common Issues

1. **Docker containers not starting**
   - Check logs: `docker-compose logs -f`
   - Ensure ports are available: `sudo lsof -i:8000` and `sudo lsof -i:3000`

2. **Database migration errors**
   - Reset migrations (development only): `./scripts/migrate.sh reset`

3. **Frontend not connecting to backend**
   - Check the `REACT_APP_API_URL` environment variable
   - Ensure CORS is properly configured in backend settings

4. **SSL certificate issues**
   - Run the certificate renewal script: `./scripts/deploy.sh --certs your-domain.com your-email@example.com`

For more troubleshooting help, please [open an issue](https://github.com/yourusername/intro-hub/issues/new) with detailed information about your problem.

## License

[MIT License](LICENSE)

## Contact

For questions or support, please reach out to [your-email@example.com](mailto:your-email@example.com).
