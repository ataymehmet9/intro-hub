import pandas as pd
import io
import logging

logger = logging.getLogger(__name__)

class CSVProcessor:
    """
    Utility class for processing CSV files for contact imports
    """
    
    REQUIRED_COLUMNS = ['first_name', 'last_name', 'email']
    OPTIONAL_COLUMNS = ['phone', 'company', 'job_title', 'linkedin_profile', 'relationship', 'notes']
    ALL_COLUMNS = REQUIRED_COLUMNS + OPTIONAL_COLUMNS
    
    @classmethod
    def validate_file(cls, file_obj):
        """
        Validate that the file has the required columns
        
        Args:
            file_obj: File object to validate
            
        Returns:
            tuple: (is_valid, error_message, DataFrame)
        """
        try:
            # Read the file
            if file_obj.name.endswith('.csv'):
                df = pd.read_csv(io.StringIO(file_obj.read().decode('utf-8')))
            elif file_obj.name.endswith(('.xlsx', '.xls')):
                df = pd.read_excel(file_obj)
            else:
                return False, "Unsupported file format. Please upload a CSV or Excel file.", None
            
            # Check required columns
            missing_columns = [col for col in cls.REQUIRED_COLUMNS if col not in df.columns]
            if missing_columns:
                return False, f"Missing required columns: {', '.join(missing_columns)}", None
            
            # Clean column names (trim whitespace)
            df.columns = df.columns.str.strip()
            
            return True, "", df
            
        except Exception as e:
            logger.error(f"Error validating file: {str(e)}")
            return False, f"Error processing file: {str(e)}", None
    
    @classmethod
    def process_contacts(cls, df, user):
        """
        Process contacts DataFrame and return lists of contacts to create/update
        
        Args:
            df: Pandas DataFrame with contact data
            user: User object who owns the contacts
            
        Returns:
            tuple: (contacts_to_create, contacts_to_update, errors)
        """
        from introhub.models.contact import Contact
        
        contacts_to_create = []
        contacts_to_update = []
        errors = []
        
        # Process each row
        for index, row in df.iterrows():
            try:
                # Convert row to dict, handling NaN values
                contact_data = {
                    k: v if pd.notna(v) else '' 
                    for k, v in row.to_dict().items()
                    if k in cls.ALL_COLUMNS
                }
                
                # Add user reference
                contact_data['user'] = user
                
                # Check if contact exists by email
                try:
                    existing_contact = Contact.objects.get(
                        user=user,
                        email=contact_data['email']
                    )
                    
                    # Add to update list
                    contacts_to_update.append((existing_contact, contact_data))
                    
                except Contact.DoesNotExist:
                    # Add to create list
                    contacts_to_create.append(contact_data)
                    
            except Exception as e:
                errors.append(f"Row {index + 1}: {str(e)}")
        
        return contacts_to_create, contacts_to_update, errors
    
    @classmethod
    def execute_import(cls, df, user):
        """
        Execute the import process
        
        Args:
            df: Pandas DataFrame with contact data
            user: User object who owns the contacts
            
        Returns:
            dict: Import results
        """
        from introhub.models.contact import Contact
        from django.db import transaction
        
        contacts_to_create, contacts_to_update, errors = cls.process_contacts(df, user)
        
        try:
            with transaction.atomic():
                # Create new contacts
                created_contacts = []
                for contact_data in contacts_to_create:
                    created_contacts.append(Contact(**contact_data))
                
                if created_contacts:
                    Contact.objects.bulk_create(created_contacts)
                
                # Update existing contacts
                for existing_contact, contact_data in contacts_to_update:
                    # Update fields
                    for key, value in contact_data.items():
                        if key != 'user' and value:  # Skip user field and empty values
                            setattr(existing_contact, key, value)
                    
                    existing_contact.save()
            
            return {
                'contacts_created': len(contacts_to_create),
                'contacts_updated': len(contacts_to_update),
                'errors': errors
            }
            
        except Exception as e:
            logger.error(f"Error during import: {str(e)}")
            errors.append(f"Import error: {str(e)}")
            return {
                'contacts_created': 0,
                'contacts_updated': 0,
                'errors': errors
            }
