from django.urls import path, include
from rest_framework.routers import DefaultRouter
from introhub.views.user import (
    UserRegistrationView,
    UserProfileView,
    PasswordChangeView,
    CustomTokenObtainPairView,
)
from introhub.views.contact import ContactViewSet
from introhub.views.request import IntroductionRequestViewSet
from rest_framework_simplejwt.views import TokenRefreshView
from drf_spectacular.views import (
    SpectacularAPIView,
    SpectacularRedocView,
    SpectacularSwaggerView,
)

# Create a router for ViewSets
router = DefaultRouter()
router.register(r'contacts', ContactViewSet, basename='contact')
router.register(r'requests', IntroductionRequestViewSet, basename='request')

# URL patterns
urlpatterns = [
    # Authentication endpoints
    path('auth/register/', UserRegistrationView.as_view(), name='register'),
    path('auth/login/', CustomTokenObtainPairView.as_view(), name='login'),
    path('auth/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    path('auth/profile/', UserProfileView.as_view(), name='profile'),
    path('auth/change-password/', PasswordChangeView.as_view(), name='change_password'),
    
    # API documentation
    path('schema/', SpectacularAPIView.as_view(), name='schema'),
    path('schema/swagger/', SpectacularSwaggerView.as_view(url_name='schema'), name='swagger-ui'),
    path('schema/redoc/', SpectacularRedocView.as_view(url_name='schema'), name='redoc'),
    
    # Include router URLs
    path('', include(router.urls)),
]
