#!/bin/bash
# Database Migration Helper Script
# This script helps manage database migrations for the Intro-Hub application

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Get the directory of this script
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$SCRIPT_DIR/../backend"

# Activate virtual environment if it exists
if [ -d "venv" ]; then
    echo -e "${YELLOW}Activating virtual environment...${NC}"
    source venv/bin/activate
fi

# Function to display help
show_help() {
    echo -e "${GREEN}Database Migration Helper for Intro-Hub${NC}"
    echo ""
    echo "Usage: $0 [command]"
    echo ""
    echo "Commands:"
    echo "  makemigrations   - Create new migrations based on models changes"
    echo "  migrate          - Apply database migrations"
    echo "  showmigrations   - Show migration status"
    echo "  squashmigrations - Squash migrations for an app"
    echo "  reset            - Reset migrations for development (DANGEROUS)"
    echo "  help             - Show this help message"
    echo ""
    echo "Examples:"
    echo "  $0 makemigrations introhub"
    echo "  $0 migrate"
    echo "  $0 showmigrations"
    echo "  $0 squashmigrations introhub 0001 0010"
    echo ""
}

# Function to make migrations
make_migrations() {
    echo -e "${GREEN}Creating migrations...${NC}"
    if [ -z "$1" ]; then
        python manage.py makemigrations
    else
        python manage.py makemigrations "$1"
    fi
    echo -e "${GREEN}Done!${NC}"
}

# Function to apply migrations
migrate() {
    echo -e "${GREEN}Applying migrations...${NC}"
    if [ -z "$1" ]; then
        python manage.py migrate
    else
        python manage.py migrate "$1" "$2"
    fi
    echo -e "${GREEN}Done!${NC}"
}

# Function to show migrations
show_migrations() {
    echo -e "${GREEN}Showing migration status...${NC}"
    python manage.py showmigrations
}

# Function to squash migrations
squash_migrations() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: App name is required for squashing migrations.${NC}"
        echo "Usage: $0 squashmigrations [app_name] [start_migration] [end_migration]"
        exit 1
    fi

    APP_NAME=$1
    START_MIGRATION=$2
    END_MIGRATION=$3

    if [ -z "$START_MIGRATION" ] || [ -z "$END_MIGRATION" ]; then
        echo -e "${RED}Error: Both start and end migration names are required.${NC}"
        echo "Usage: $0 squashmigrations [app_name] [start_migration] [end_migration]"
        exit 1
    fi

    echo -e "${YELLOW}Squashing migrations for $APP_NAME from $START_MIGRATION to $END_MIGRATION...${NC}"
    echo -e "${YELLOW}Warning: This operation requires manual review of the generated migration.${NC}"
    read -p "Do you want to continue? (y/n) " -n 1 -r
    echo
    if [[ $REPLY =~ ^[Yy]$ ]]; then
        python manage.py squashmigrations "$APP_NAME" "$START_MIGRATION" "$END_MIGRATION"
        echo -e "${GREEN}Done!${NC}"
        echo -e "${YELLOW}Please review the generated migration file and make any necessary adjustments.${NC}"
    else
        echo -e "${YELLOW}Operation cancelled.${NC}"
    fi
}

# Function to reset migrations (DANGEROUS - only for development)
reset_migrations() {
    echo -e "${RED}WARNING: This will delete all migrations and recreate them.${NC}"
    echo -e "${RED}This is DANGEROUS and should only be used in development.${NC}"
    read -p "Are you ABSOLUTELY SURE you want to continue? (yes/no) " -r
    echo
    if [[ $REPLY =~ ^[Yy]es$ ]]; then
        echo -e "${YELLOW}Resetting migrations...${NC}"
        
        # Find all migration directories
        MIGRATION_DIRS=$(find . -path "*/migrations" -type d)
        
        # Delete all migration files except __init__.py
        for dir in $MIGRATION_DIRS; do
            echo "Cleaning $dir..."
            find "$dir" -name "*.py" -not -name "__init__.py" -delete
        done
        
        # Reset the database (drop all tables)
        echo "Resetting database..."
        python manage.py reset_db --noinput
        
        # Create new initial migrations
        echo "Creating new migrations..."
        python manage.py makemigrations
        
        # Apply migrations
        echo "Applying migrations..."
        python manage.py migrate
        
        echo -e "${GREEN}Done!${NC}"
        echo -e "${YELLOW}Remember to recreate a superuser with 'python manage.py createsuperuser'${NC}"
    else
        echo -e "${YELLOW}Operation cancelled.${NC}"
    fi
}

# Main logic
case "$1" in
    makemigrations)
        make_migrations "$2"
        ;;
    migrate)
        migrate "$2" "$3"
        ;;
    showmigrations)
        show_migrations
        ;;
    squashmigrations)
        squash_migrations "$2" "$3" "$4"
        ;;
    reset)
        reset_migrations
        ;;
    help)
        show_help
        ;;
    *)
        show_help
        ;;
esac
