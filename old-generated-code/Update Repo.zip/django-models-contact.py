from django.db import models
from django.conf import settings
from django.utils.translation import gettext_lazy as _


class Contact(models.Model):
    """
    Represents a contact that can be used for introductions
    """
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL, 
        on_delete=models.CASCADE,
        related_name='contacts'
    )
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField()
    phone = models.CharField(max_length=20, blank=True)
    company = models.CharField(max_length=100, blank=True)
    job_title = models.CharField(max_length=100, blank=True)
    linkedin_profile = models.URLField(blank=True)
    relationship = models.CharField(max_length=100, blank=True)
    notes = models.TextField(blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    class Meta:
        verbose_name = _('contact')
        verbose_name_plural = _('contacts')
        ordering = ['last_name', 'first_name']
        indexes = [
            models.Index(fields=['user', 'last_name', 'first_name']),
            models.Index(fields=['user', 'company']),
            models.Index(fields=['user', 'email']),
        ]
        constraints = [
            models.UniqueConstraint(
                fields=['user', 'email'],
                name='unique_user_contact_email'
            )
        ]
    
    def __str__(self):
        return f"{self.first_name} {self.last_name}"
    
    @property
    def full_name(self):
        """
        Return the full name of the contact
        """
        return f"{self.first_name} {self.last_name}"
