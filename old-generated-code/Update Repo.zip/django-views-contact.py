from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from introhub.models.contact import Contact
from introhub.serializers.contact import (
    ContactSerializer,
    ContactListSerializer,
    ContactBulkUploadSerializer
)
import pandas as pd
import io


class ContactViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing contacts
    """
    serializer_class = ContactSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['company', 'relationship']
    search_fields = ['first_name', 'last_name', 'email', 'company', 'job_title']
    ordering_fields = ['first_name', 'last_name', 'company', 'created_at']
    ordering = ['last_name', 'first_name']
    
    def get_queryset(self):
        """
        Return only contacts owned by the current user
        """
        return Contact.objects.filter(user=self.request.user)
    
    def get_serializer_class(self):
        """
        Return different serializers for different actions
        """
        if self.action == 'list':
            return ContactListSerializer
        if self.action == 'bulk_upload':
            return ContactBulkUploadSerializer
        return ContactSerializer
    
    @action(detail=False, methods=['post'])
    def bulk_upload(self, request):
        """
        Upload multiple contacts from a CSV or Excel file
        """
        serializer = self.get_serializer(data=request.data)
        if not serializer.is_valid():
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        
        file = serializer.validated_data['file']
        
        try:
            # Handle different file types
            if file.name.endswith('.csv'):
                df = pd.read_csv(io.StringIO(file.read().decode('utf-8')))
            else:  # Excel
                df = pd.read_excel(file)
            
            # Validate required columns
            required_columns = ['first_name', 'last_name', 'email']
            missing_columns = [col for col in required_columns if col not in df.columns]
            
            if missing_columns:
                return Response(
                    {"error": f"Missing required columns: {', '.join(missing_columns)}"},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Process contacts
            contacts_created = 0
            contacts_updated = 0
            errors = []
            
            for _, row in df.iterrows():
                # Convert row to dict, handling NaN values
                contact_data = {
                    k: v if pd.notna(v) else '' 
                    for k, v in row.to_dict().items()
                }
                
                # Set the user
                contact_data['user'] = request.user
                
                # Check if contact already exists
                try:
                    contact = Contact.objects.get(
                        user=request.user,
                        email=contact_data['email']
                    )
                    
                    # Update existing contact
                    for key, value in contact_data.items():
                        if hasattr(contact, key) and value != '':
                            setattr(contact, key, value)
                    
                    contact.save()
                    contacts_updated += 1
                    
                except Contact.DoesNotExist:
                    # Create new contact
                    try:
                        Contact.objects.create(**contact_data)
                        contacts_created += 1
                    except Exception as e:
                        errors.append(f"Row {contacts_created + contacts_updated + len(errors) + 1}: {str(e)}")
            
            return Response({
                "contacts_created": contacts_created,
                "contacts_updated": contacts_updated,
                "errors": errors
            }, status=status.HTTP_200_OK)
            
        except Exception as e:
            return Response(
                {"error": f"Error processing file: {str(e)}"},
                status=status.HTTP_400_BAD_REQUEST
            )
