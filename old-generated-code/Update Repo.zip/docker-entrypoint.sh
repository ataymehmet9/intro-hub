#!/bin/bash

set -e

# Wait for postgres
if [ "$DATABASE_URL" ]; then
  echo "Waiting for postgres..."
  
  while ! nc -z $DB_HOST $DB_PORT; do
    sleep 0.1
  done
  
  echo "PostgreSQL started"
fi

# Apply database migrations
echo "Applying migrations..."
python manage.py migrate

# Collect static files
echo "Collecting static files..."
python manage.py collectstatic --noinput

# Create superuser if needed
if [ "$DJANGO_SUPERUSER_USERNAME" ] && [ "$DJANGO_SUPERUSER_EMAIL" ] && [ "$DJANGO_SUPERUSER_PASSWORD" ]; then
  echo "Creating superuser..."
  python manage.py createsuperuser \
    --noinput \
    --username $DJANGO_SUPERUSER_USERNAME \
    --email $DJANGO_SUPERUSER_EMAIL
fi

# Start server
echo "Starting server..."
gunicorn config.wsgi:application --bind 0.0.0.0:8000
