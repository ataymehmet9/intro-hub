# Intro-Hub

A platform for facilitating warm introductions between B2B SaaS sales teams and potential leads through existing networks.

![Intro-Hub](https://placehold.co/600x400?text=Intro-Hub)

## Project Overview

Intro-Hub connects sales professionals with relevant contacts in their extended network. The platform allows users to:

- Upload and manage their professional contacts
- Search for potential leads through their connections' networks
- Request warm introductions to target contacts
- Manage introduction requests and approvals
- Facilitate email introductions between connected parties

## Tech Stack

### Backend
- **Framework**: Django + Django REST Framework
- **Database**: PostgreSQL
- **Authentication**: JWT (JSON Web Tokens)
- **Caching**: Redis
- **Storage**: AWS S3 (production)
- **Task Queue**: Celery (for email processing)

### Frontend
- **Framework**: React
- **UI Library**: Material-UI
- **State Management**: React Context API
- **API Client**: Axios
- **Routing**: React Router

### Infrastructure
- **Containerization**: Docker + Docker Compose
- **Web Server**: Nginx
- **HTTPS**: Let's Encrypt
- **CI/CD**: GitHub Actions
- **Monitoring**: Sentry

## Getting Started

### Prerequisites

- Docker and Docker Compose
- Git

### Local Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   ```

2. Create a `.env` file based on `.env.example`:
   ```bash
   cp .env.example .env
   # Edit .env file with your configuration
   ```

3. Start the development environment:
   ```bash
   docker-compose up
   ```

4. Access the applications:
   - Frontend: http://localhost:3000
   - Backend API: http://localhost:8000/api/
   - Django Admin: http://localhost:8000/admin/

### Running Tests

```bash
# Backend tests
docker-compose exec backend python manage.py test

# Frontend tests
docker-compose exec frontend npm test
```

## Production Deployment

1. Set up your production server (Ubuntu 20.04+ recommended)

2. Install required dependencies:
   ```bash
   sudo apt update
   sudo apt install -y docker.io docker-compose
   ```

3. Clone the repository and configure environment:
   ```bash
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   cp .env.example .env
   # Edit .env file with production values
   ```

4. Start the production environment:
   ```bash
   docker-compose -f docker-compose.prod.yml up -d
   ```

5. Set up SSL certificates:
   ```bash
   # Replace with your domain and email
   ./scripts/init-letsencrypt.sh your-domain.com your-email@example.com
   ```

## Project Structure

The repository follows a modular structure:

```
intro-hub/
├── backend/                 # Django backend
│   ├── introhub/            # Main Django app
│   ├── config/              # Project settings
│   └── ...
├── frontend/                # React frontend
│   ├── public/
│   ├── src/
│   │   ├── components/      # UI components
│   │   ├── contexts/        # React contexts
│   │   ├── hooks/           # Custom hooks
│   │   ├── pages/           # Page components
│   │   ├── services/        # API services
│   │   └── ...
│   └── ...
├── nginx/                   # Nginx configuration
├── docker-compose.yml       # Development configuration
├── docker-compose.prod.yml  # Production configuration
└── ...
```

## Contributing

1. Fork the repository
2. Create a feature branch: `git checkout -b feature/my-feature`
3. Make your changes and commit: `git commit -m 'Add some feature'`
4. Push to the branch: `git push origin feature/my-feature`
5. Submit a pull request

## License

[MIT License](LICENSE)

## Contact

For questions or support, please reach out to [your-email@example.com](mailto:your-email@example.com).
