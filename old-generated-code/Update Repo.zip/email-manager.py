import logging
from django.conf import settings
from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.utils import timezone

logger = logging.getLogger(__name__)

class EmailManager:
    """
    Utility class for managing email notifications
    """
    
    @classmethod
    def send_email(cls, subject, template_name, context, recipients, sender=None, cc=None, bcc=None, attachments=None):
        """
        Send an email using a template
        
        Args:
            subject (str): Email subject
            template_name (str): Template name (without extension)
            context (dict): Template context
            recipients (list): List of recipient email addresses
            sender (str, optional): Sender email address. Defaults to DEFAULT_FROM_EMAIL.
            cc (list, optional): List of CC email addresses. Defaults to None.
            bcc (list, optional): List of BCC email addresses. Defaults to None.
            attachments (list, optional): List of attachments. Defaults to None.
            
        Returns:
            bool: Whether the email was sent successfully
        """
        try:
            # Add timestamp to context
            context['timestamp'] = timezone.now()
            context['site_url'] = settings.SITE_URL
            
            # Render email templates
            html_content = render_to_string(f'emails/{template_name}.html', context)
            text_content = strip_tags(html_content)
            
            # Create email message
            from_email = sender or settings.DEFAULT_FROM_EMAIL
            email = EmailMultiAlternatives(
                subject=subject,
                body=text_content,
                from_email=from_email,
                to=recipients,
                cc=cc,
                bcc=bcc,
            )
            
            # Attach HTML content
            email.attach_alternative(html_content, "text/html")
            
            # Add attachments
            if attachments:
                for attachment in attachments:
                    email.attach(*attachment)
            
            # Send email
            email.send(fail_silently=False)
            
            # Log success
            logger.info(
                f"Email '{subject}' sent to {', '.join(recipients)} "
                f"using template {template_name}"
            )
            
            return True
            
        except Exception as e:
            # Log error
            logger.error(
                f"Error sending email '{subject}' to {', '.join(recipients)}: {str(e)}"
            )
            
            return False
    
    @classmethod
    def send_introduction_notification(cls, request):
        """
        Send a notification to the contact owner about a new introduction request
        
        Args:
            request: The IntroductionRequest instance
            
        Returns:
            bool: Whether the email was sent successfully
        """
        requester = request.requester
        contact = request.contact
        contact_owner = request.contact_owner
        
        # Build context
        context = {
            'request': request,
            'requester': requester,
            'contact': contact,
            'contact_owner': contact_owner,
            'dashboard_url': f"{settings.SITE_URL}/requests",
        }
        
        # Send email
        subject = f"New Introduction Request: {requester.get_full_name()} to {contact.full_name}"
        return cls.send_email(
            subject=subject,
            template_name='request_notification',
            context=context,
            recipients=[contact_owner.email],
        )
    
    @classmethod
    def send_introduction_email(cls, request):
        """
        Send an introduction email between the requester and the contact
        
        Args:
            request: The IntroductionRequest instance
            
        Returns:
            bool: Whether the email was sent successfully
        """
        requester = request.requester
        contact = request.contact
        contact_owner = request.contact_owner
        
        # Build context
        context = {
            'request': request,
            'requester': requester,
            'contact': contact,
            'contact_owner': contact_owner,
            'purpose': request.purpose,
            'dashboard_url': f"{settings.SITE_URL}/requests",
        }
        
        # Send email
        subject = f"Introduction: {requester.get_full_name()} <> {contact.full_name}"
        return cls.send_email(
            subject=subject,
            template_name='introduction',
            context=context,
            sender=f"{contact_owner.get_full_name()} <{settings.DEFAULT_FROM_EMAIL}>",
            recipients=[requester.email, contact.email],
            cc=[contact_owner.email],
            reply_to=[contact_owner.email],
        )
    
    @classmethod
    def send_welcome_email(cls, user):
        """
        Send a welcome email to a new user
        
        Args:
            user: The User instance
            
        Returns:
            bool: Whether the email was sent successfully
        """
        # Build context
        context = {
            'user': user,
            'dashboard_url': f"{settings.SITE_URL}/dashboard",
        }
        
        # Send email
        subject = f"Welcome to Intro-Hub, {user.first_name}!"
        return cls.send_email(
            subject=subject,
            template_name='welcome',
            context=context,
            recipients=[user.email],
        )
    
    @classmethod
    def send_password_reset_email(cls, user, reset_url):
        """
        Send a password reset email to a user
        
        Args:
            user: The User instance
            reset_url: Password reset URL
            
        Returns:
            bool: Whether the email was sent successfully
        """
        # Build context
        context = {
            'user': user,
            'reset_url': reset_url,
        }
        
        # Send email
        subject = "Reset Your Intro-Hub Password"
        return cls.send_email(
            subject=subject,
            template_name='password_reset',
            context=context,
            recipients=[user.email],
        )
    
    @classmethod
    def send_request_approved_email(cls, request):
        """
        Send a notification to the requester that their request was approved
        
        Args:
            request: The IntroductionRequest instance
            
        Returns:
            bool: Whether the email was sent successfully
        """
        requester = request.requester
        contact = request.contact
        contact_owner = request.contact_owner
        
        # Build context
        context = {
            'request': request,
            'requester': requester,
            'contact': contact,
            'contact_owner': contact_owner,
            'dashboard_url': f"{settings.SITE_URL}/requests",
        }
        
        # Send email
        subject = f"Your Introduction Request to {contact.full_name} was Approved"
        return cls.send_email(
            subject=subject,
            template_name='request_approved',
            context=context,
            recipients=[requester.email],
        )
    
    @classmethod
    def send_request_denied_email(cls, request):
        """
        Send a notification to the requester that their request was denied
        
        Args:
            request: The IntroductionRequest instance
            
        Returns:
            bool: Whether the email was sent successfully
        """
        requester = request.requester
        contact = request.contact
        
        # Build context
        context = {
            'request': request,
            'requester': requester,
            'contact': contact,
            'dashboard_url': f"{settings.SITE_URL}/requests",
        }
        
        # Send email
        subject = f"Your Introduction Request to {contact.full_name} was Declined"
        return cls.send_email(
            subject=subject,
            template_name='request_denied',
            context=context,
            recipients=[requester.email],
        )
