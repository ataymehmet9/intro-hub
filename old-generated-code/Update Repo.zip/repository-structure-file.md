# Intro-Hub Repository Structure

This document provides a comprehensive overview of the Intro-Hub repository structure. Use this as a reference when navigating the codebase or implementing new features.

## Directory Structure

```
intro-hub/
├── .env.example                       # Environment variables template
├── .github/                           # GitHub workflows
│   └── workflows/
│       ├── test.yml                   # CI testing workflow 
│       └── deploy.yml                 # CD deployment workflow
├── .gitignore                         # Git ignore rules
├── README.md                          # Project documentation
├── Makefile                           # Development convenience commands
├── docker-compose.yml                 # Development Docker configuration
├── docker-compose.prod.yml            # Production Docker configuration
├── scripts/                           # Utility scripts
│   ├── deploy.sh                      # Deployment script
│   ├── init-letsencrypt.sh            # Let's Encrypt initialization
│   └── migrate.sh                     # Database migration helper
├── backend/                           # Django backend
│   ├── Dockerfile                     # Backend container definition
│   ├── docker-entrypoint.sh           # Container startup script
│   ├── manage.py                      # Django management script
│   ├── introhub/                      # Main Django app
│   │   ├── __init__.py
│   │   ├── admin.py                   # Admin configuration
│   │   ├── apps.py                    # App configuration
│   │   ├── models/                    # Database models
│   │   │   ├── __init__.py
│   │   │   ├── user.py                # User model
│   │   │   ├── contact.py             # Contact model
│   │   │   └── request.py             # Request model
│   │   ├── serializers/               # API serializers
│   │   │   ├── __init__.py
│   │   │   ├── user.py                # User serializers
│   │   │   ├── contact.py             # Contact serializers
│   │   │   └── request.py             # Request serializers
│   │   ├── views/                     # API views
│   │   │   ├── __init__.py
│   │   │   ├── user.py                # User views
│   │   │   ├── contact.py             # Contact views
│   │   │   └── request.py             # Request views
│   │   ├── services/                  # Business logic
│   │   │   ├── __init__.py
│   │   │   ├── email.py               # Email service
│   │   │   └── search.py              # Contact search service
│   │   ├── urls.py                    # URL routing
│   │   └── utils/                     # Utility functions
│   │       ├── __init__.py
│   │       ├── validators.py          # Data validators
│   │       ├── csv_processor.py       # CSV import processing
│   │       └── email_manager.py       # Email notification manager
│   ├── config/                        # Project settings
│   │   ├── __init__.py
│   │   ├── asgi.py                    # ASGI configuration
│   │   ├── settings/                  # Split settings
│   │   │   ├── __init__.py
│   │   │   ├── base.py                # Base settings
│   │   │   ├── local.py               # Development settings
│   │   │   └── production.py          # Production settings
│   │   ├── urls.py                    # Main URL configuration
│   │   ├── wsgi.py                    # WSGI configuration
│   │   └── storage_backends.py        # Storage configuration
│   ├── templates/                     # Email templates
│   │   └── emails/
│   │       ├── introduction.html      # Introduction email template
│   │       ├── welcome.html           # Welcome email template
│   │       ├── request_notification.html  # Request notification template
│   │       ├── request_approved.html  # Request approval template
│   │       ├── request_denied.html    # Request denial template
│   │       └── password_reset.html    # Password reset template
│   ├── requirements/                  # Split requirements
│   │   ├── base.txt                   # Base requirements
│   │   ├── local.txt                  # Development requirements
│   │   └── production.txt             # Production requirements
│   └── tests/                         # Test directory
│       ├── __init__.py
│       ├── test_models.py             # Model tests
│       ├── test_views.py              # View tests
│       └── test_services.py           # Service tests
├── frontend/                          # React frontend
│   ├── Dockerfile                     # Frontend container definition
│   ├── nginx.conf                     # Frontend Nginx configuration
│   ├── package.json                   # NPM dependencies
│   ├── public/                        # Public assets
│   │   ├── favicon.ico
│   │   ├── index.html
│   │   └── manifest.json
│   └── src/                           # Source code
│       ├── App.js                     # Main App component
│       ├── index.js                   # Entry point
│       ├── routes.js                  # Application routes
│       ├── components/                # Reusable UI components
│       │   ├── common/                # Shared components
│       │   │   ├── Alert.js           # Custom alert component
│       │   │   ├── ConfirmationDialog.js  # Confirmation dialog
│       │   │   ├── DateFormat.js      # Date formatter component
│       │   │   ├── FileUploadButton.js # File upload component
│       │   │   ├── LoadingSpinner.js  # Loading spinner component
│       │   │   └── NoData.js          # Empty state component
│       │   ├── layouts/               # Layout components
│       │   │   ├── MainLayout.js      # Main application layout
│       │   │   ├── AuthLayout.js      # Authentication layout
│       │   │   └── PageLayout.js      # Page wrapper layout
│       │   ├── contacts/              # Contact components
│       │   │   ├── ContactCard.js     # Contact card component
│       │   │   ├── ContactForm.js     # Contact form component
│       │   │   └── ContactList.js     # Contact list component
│       │   └── requests/              # Request components
│       │       ├── RequestCard.js     # Request card component
│       │       └── RequestList.js     # Request list component
│       ├── contexts/                  # React contexts
│       │   ├── AuthContext.js         # Authentication context
│       │   ├── ContactContext.js      # Contact management context
│       │   └── RequestContext.js      # Request management context
│       ├── hooks/                     # Custom React hooks
│       │   ├── useAuth.js             # Authentication hook
│       │   ├── useContacts.js         # Contacts hook
│       │   └── useRequests.js         # Requests hook
│       ├── pages/                     # Page components
│       │   ├── auth/                  # Authentication pages
│       │   │   ├── Login.js           # Login page
│       │   │   └── Signup.js          # Signup page
│       │   ├── Dashboard.js           # Dashboard page
│       │   ├── Contacts.js            # Contacts management page
│       │   ├── Search.js              # Search page
│       │   ├── Requests.js            # Requests management page
│       │   └── Profile.js             # User profile page
│       ├── services/                  # API service functions
│       │   ├── api.js                 # API client setup
│       │   ├── auth.js                # Authentication service
│       │   ├── contacts.js            # Contacts service
│       │   └── requests.js            # Requests service
│       └── utils/                     # Utility functions
│           ├── tokenUtils.js          # JWT token utilities
│           └── formUtils.js           # Form helper utilities
└── nginx/                             # Nginx configuration
    ├── Dockerfile                     # Nginx container definition
    └── nginx.conf                     # Nginx configuration
```

## Key Components

### Backend

1. **Models**: Database schema definitions
   - `User`: Extended Django user model with additional fields
   - `Contact`: Represents a contact that can be used for introductions
   - `IntroductionRequest`: Represents a request for introduction

2. **Views**: API endpoints handling client requests
   - User-related endpoints (registration, profile, authentication)
   - Contact management (CRUD operations, bulk import)
   - Introduction requests (create, approve, deny, list)

3. **Services**: Business logic encapsulation
   - Email service for sending notifications
   - Search service for finding contacts

4. **Utilities**: Helper functions
   - CSV processor for contact imports
   - Email manager for notifications
   - Validators for data validation

### Frontend

1. **Components**: Reusable UI building blocks
   - Common components (alerts, dialogs, loaders)
   - Layout components (page structure)
   - Feature-specific components (contact cards, forms)

2. **Contexts**: Application state management
   - Authentication state
   - Contact management state
   - Request management state

3. **Pages**: Full application screens
   - Authentication pages (login, signup)
   - Main functionality pages (dashboard, contacts, search, requests)
   - User profile management

4. **Services**: API integration
   - API client setup with interceptors
   - Feature-specific service modules
   - Authentication and token management

### Infrastructure

1. **Docker**: Containerization
   - Development and production configurations
   - Service definitions and networking

2. **Nginx**: Web server and reverse proxy
   - Static file serving
   - API proxying
   - SSL termination

3. **CI/CD**: Continuous integration and deployment
   - Testing workflows
   - Deployment automation

## Development Guidelines

### Code Organization Principles

1. **Separation of Concerns**: Each file has a single responsibility
2. **Modularity**: Components are self-contained and reusable
3. **DRY (Don't Repeat Yourself)**: Common code is extracted into utilities
4. **SOLID Principles**: Particularly single responsibility and interface segregation

### Coding Standards

1. **Backend**:
   - Follow PEP 8 style guidelines
   - Use Django's coding style conventions
   - Write docstrings for all functions and classes

2. **Frontend**:
   - Follow Airbnb JavaScript style guide
   - Use functional components with hooks
   - Implement prop validation with PropTypes

### Testing Approach

1. **Backend Tests**:
   - Unit tests for models, services, and utilities
   - Integration tests for API endpoints
   - Use Django's test framework

2. **Frontend Tests**:
   - Component tests with React Testing Library
   - Hook tests for custom hooks
   - Mock API calls for service tests

### Data Flow

1. **Backend**:
   - Request → URL → View → Serializer → Model → Database
   - Database → Model → Serializer → View → Response

2. **Frontend**:
   - User Action → Component → Context → Service → API
   - API → Service → Context → Component → UI Update

## Contributing

When adding new features or fixing bugs, please follow these guidelines:

1. Create a feature branch from `develop`
2. Follow the existing code organization and naming conventions
3. Write tests for new functionality
4. Update documentation as needed
5. Submit a pull request with a clear description of changes

## Additional Resources

- [Django Documentation](https://docs.djangoproject.com/)
- [Django REST Framework](https://www.django-rest-framework.org/)
- [React Documentation](https://reactjs.org/docs/getting-started.html)
- [Material-UI Components](https://mui.com/components/)
- [Docker Documentation](https://docs.docker.com/)
