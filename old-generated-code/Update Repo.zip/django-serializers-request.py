from rest_framework import serializers
from introhub.models.request import IntroductionRequest
from introhub.models.contact import Contact
from introhub.serializers.contact import ContactSerializer


class IntroductionRequestSerializer(serializers.ModelSerializer):
    """
    Serializer for the IntroductionRequest model
    """
    requester = serializers.StringRelatedField(read_only=True)
    contact_owner = serializers.StringRelatedField(read_only=True)
    contact = ContactSerializer(read_only=True)
    contact_id = serializers.PrimaryKeyRelatedField(
        write_only=True,
        queryset=Contact.objects.all(),
        source='contact'
    )
    
    class Meta:
        model = IntroductionRequest
        fields = ['id', 'requester', 'contact_owner', 'contact', 'contact_id',
                  'status', 'purpose', 'message', 'created_at', 'updated_at',
                  'completed_at']
        read_only_fields = ['id', 'requester', 'contact_owner', 'status',
                            'created_at', 'updated_at', 'completed_at']
    
    def create(self, validated_data):
        """
        Create and return a new introduction request
        """
        contact = validated_data.get('contact')
        
        # Set the requester as the current user
        validated_data['requester'] = self.context['request'].user
        
        # Set the contact owner as the owner of the contact
        validated_data['contact_owner'] = contact.user
        
        return super().create(validated_data)


class IntroductionRequestUpdateSerializer(serializers.ModelSerializer):
    """
    Serializer for updating an introduction request (limited fields)
    """
    class Meta:
        model = IntroductionRequest
        fields = ['status']
        read_only_fields = ['id']
    
    def validate_status(self, value):
        """
        Validate that the status is valid
        """
        # Check if the user is the contact owner
        request = self.context['request']
        instance = self.instance
        
        if instance.contact_owner != request.user:
            raise serializers.ValidationError("Only the contact owner can update the status")
        
        # Ensure status transitions are valid
        valid_transitions = {
            'pending': ['approved', 'denied'],
            'approved': ['completed'],
            'denied': [],
            'completed': []
        }
        
        if value not in valid_transitions[instance.status]:
            raise serializers.ValidationError(
                f"Cannot transition from '{instance.status}' to '{value}'"
            )
        
        return value


class IntroductionRequestListSerializer(serializers.ModelSerializer):
    """
    Serializer for listing introduction requests (with fewer fields)
    """
    requester = serializers.StringRelatedField()
    contact_name = serializers.SerializerMethodField()
    contact_company = serializers.SerializerMethodField()
    
    class Meta:
        model = IntroductionRequest
        fields = ['id', 'requester', 'contact_name', 'contact_company', 
                  'status', 'created_at']
    
    def get_contact_name(self, obj):
        """
        Get the contact's full name
        """
        return obj.contact.full_name
    
    def get_contact_company(self, obj):
        """
        Get the contact's company
        """
        return obj.contact.company
