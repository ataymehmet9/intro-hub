from rest_framework import serializers
from introhub.models.contact import Contact


class ContactSerializer(serializers.ModelSerializer):
    """
    Serializer for the Contact model
    """
    user = serializers.HiddenField(default=serializers.CurrentUserDefault())
    full_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Contact
        fields = ['id', 'user', 'first_name', 'last_name', 'full_name', 'email', 
                 'phone', 'company', 'job_title', 'linkedin_profile', 
                 'relationship', 'notes', 'created_at', 'updated_at']
        read_only_fields = ['id', 'created_at', 'updated_at']
    
    def get_full_name(self, obj):
        """
        Get the contact's full name
        """
        return obj.full_name


class ContactListSerializer(serializers.ModelSerializer):
    """
    Serializer for listing contacts (with fewer fields)
    """
    full_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Contact
        fields = ['id', 'full_name', 'email', 'company', 'job_title']
    
    def get_full_name(self, obj):
        """
        Get the contact's full name
        """
        return obj.full_name


class ContactBulkUploadSerializer(serializers.Serializer):
    """
    Serializer for bulk uploading contacts
    """
    file = serializers.FileField()
    
    def validate_file(self, value):
        """
        Validate the file type (csv or xlsx)
        """
        import os
        ext = os.path.splitext(value.name)[1].lower()
        
        if ext not in ['.csv', '.xlsx']:
            raise serializers.ValidationError("Unsupported file type. Please upload a CSV or Excel file.")
        
        return value
