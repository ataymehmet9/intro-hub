from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django_filters.rest_framework import DjangoFilterBackend
from django.utils import timezone
from introhub.models.request import IntroductionRequest
from introhub.models.contact import Contact
from introhub.serializers.request import (
    IntroductionRequestSerializer,
    IntroductionRequestUpdateSerializer,
    IntroductionRequestListSerializer
)
from introhub.services.email import send_introduction_email


class IntroductionRequestViewSet(viewsets.ModelViewSet):
    """
    ViewSet for managing introduction requests
    """
    serializer_class = IntroductionRequestSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [DjangoFilterBackend, filters.SearchFilter, filters.OrderingFilter]
    filterset_fields = ['status']
    search_fields = ['contact__first_name', 'contact__last_name', 'contact__company']
    ordering_fields = ['created_at', 'updated_at']
    ordering = ['-created_at']
    
    def get_queryset(self):
        """
        Return requests based on user role
        """
        user = self.request.user
        
        # Get the type parameter from query string
        request_type = self.request.query_params.get('type')
        
        if request_type == 'sent':
            # Return requests sent by the user
            return IntroductionRequest.objects.filter(requester=user)
        elif request_type == 'received':
            # Return requests received by the user
            return IntroductionRequest.objects.filter(contact_owner=user)
        else:
            # Return all requests (sent and received)
            return IntroductionRequest.objects.filter(
                requester=user
            ) | IntroductionRequest.objects.filter(
                contact_owner=user
            )
    
    def get_serializer_class(self):
        """
        Return different serializers for different actions
        """
        if self.action == 'list':
            return IntroductionRequestListSerializer
        elif self.action in ['update', 'partial_update']:
            return IntroductionRequestUpdateSerializer
        return IntroductionRequestSerializer
    
    def perform_update(self, serializer):
        """
        Custom update to handle status changes
        """
        old_status = serializer.instance.status
        new_status = serializer.validated_data.get('status')
        
        # Update the instance
        instance = serializer.save()
        
        # Send email if request has been approved
        if old_status == 'pending' and new_status == 'approved':
            # Send email to both parties
            try:
                send_introduction_email(instance)
                # Update completed status and date
                instance.mark_as_completed()
            except Exception as e:
                # Log the error but don't stop the process
                print(f"Error sending introduction email: {str(e)}")
    
    @action(detail=False, methods=['get'])
    def search_contacts(self, request):
        """
        Search for contacts that can be requested for introductions
        """
        # Get search parameters
        query = request.query_params.get('q', '')
        
        if not query:
            return Response([], status=status.HTTP_200_OK)
        
        # Search for contacts not owned by the current user
        contacts = Contact.objects.exclude(user=request.user)
        
        # Apply search filter
        contacts = contacts.filter(
            models.Q(first_name__icontains=query) |
            models.Q(last_name__icontains=query) |
            models.Q(email__icontains=query) |
            models.Q(company__icontains=query) |
            models.Q(job_title__icontains=query)
        )
        
        # Limit results and serialize
        contacts = contacts[:10]
        serializer = ContactListSerializer(contacts, many=True)
        
        return Response(serializer.data, status=status.HTTP_200_OK)
