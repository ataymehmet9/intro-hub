# Django Settings
DJANGO_SETTINGS_MODULE=config.settings.production
DJANGO_SECRET_KEY=change_me_with_strong_secret_key
DJANGO_ALLOWED_HOSTS=localhost,127.0.0.1,your-domain.com
DEBUG=False

# Database Settings
DB_NAME=introhub
DB_USER=introhub_user
DB_PASSWORD=change_me_with_strong_password
DB_HOST=db
DB_PORT=5432
DATABASE_URL=postgres://${DB_USER}:${DB_PASSWORD}@${DB_HOST}:${DB_PORT}/${DB_NAME}

# Redis Settings
REDIS_URL=redis://redis:6379/1

# Email Settings
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_HOST_USER=your-email@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
DEFAULT_FROM_EMAIL=no-reply@introhub.com

# AWS S3 Settings (for production file storage)
AWS_ACCESS_KEY_ID=your_aws_access_key
AWS_SECRET_ACCESS_KEY=your_aws_secret_key
AWS_STORAGE_BUCKET_NAME=your-bucket-name

# Superuser for initial setup
DJANGO_SUPERUSER_USERNAME=admin
DJANGO_SUPERUSER_EMAIL=admin@example.com
DJANGO_SUPERUSER_PASSWORD=change_me_with_strong_password

# CORS settings
CORS_ALLOWED_ORIGINS=http://localhost:3000,https://your-domain.com

# React App Settings
REACT_APP_API_URL=https://your-domain.com/api

# Backup Settings
BACKUP_SCHEDULE=@daily
BACKUP_KEEP_DAYS=7
BACKUP_KEEP_WEEKS=4
BACKUP_KEEP_MONTHS=6

# Sentry Settings
SENTRY_DSN=your-sentry-dsn
SENTRY_ENVIRONMENT=production
