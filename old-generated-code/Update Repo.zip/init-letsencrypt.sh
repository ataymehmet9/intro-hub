#!/bin/bash

# Initialize Let's Encrypt certificates for Nginx with Docker
# Usage: ./init-letsencrypt.sh yourdomain.com email@example.com

if [ "$#" -ne 2 ]; then
    echo "Usage: $0 yourdomain.com email@example.com"
    exit 1
fi

# Parse input parameters
domains=($1)
email="$2"
rsa_key_size=4096
data_path="./nginx/certbot"
staging=0 # Set to 1 if you're testing your setup to avoid hitting rate limits

if [ -d "$data_path" ]; then
  read -p "Existing data found in $data_path. Continue and replace existing certificates? (y/N) " decision
  if [ "$decision" != "Y" ] && [ "$decision" != "y" ]; then
    exit
  fi
fi

echo "Creating $data_path directory..."
mkdir -p "$data_path/conf/live/$domains"
mkdir -p "$data_path/www"

echo "Creating dummy certificate for $domains..."
openssl req -x509 -nodes -newkey rsa:$rsa_key_size -days 1 \
  -keyout "$data_path/conf/live/$domains/privkey.pem" \
  -out "$data_path/conf/live/$domains/fullchain.pem" \
  -subj "/CN=localhost"

echo "Starting nginx container..."
docker-compose -f docker-compose.prod.yml up --force-recreate -d nginx

echo "Requesting Let's Encrypt certificate for $domains..."
# Join $domains to -d args
domain_args=""
for domain in "${domains[@]}"; do
  domain_args="$domain_args -d $domain"
done

# Select appropriate email arg
case "$email" in
  "") email_arg="--register-unsafely-without-email" ;;
  *) email_arg="--email $email" ;;
esac

# Enable staging mode if needed
if [ $staging != "0" ]; then staging_arg="--staging"; fi

docker-compose -f docker-compose.prod.yml run --rm --entrypoint "\
  certbot certonly --webroot -w /var/www/certbot \
    $staging_arg \
    $email_arg \
    $domain_args \
    --rsa-key-size $rsa_key_size \
    --agree-tos \
    --force-renewal" certbot

echo "Reloading nginx..."
docker-compose -f docker-compose.prod.yml exec nginx nginx -s reload

echo "Certificate initialization complete!"
echo "To use the certificate with your domain, update the domain name in nginx/nginx.conf"
