from django.core.mail import EmailMultiAlternatives
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from django.conf import settings
import logging

logger = logging.getLogger(__name__)

def send_introduction_email(request):
    """
    Send an introduction email between the requester and the contact
    
    Args:
        request: The IntroductionRequest instance
    
    Returns:
        bool: Whether the email was sent successfully
    """
    try:
        # Get all the required data
        requester = request.requester
        contact = request.contact
        contact_owner = request.contact_owner
        
        # Context for email template
        context = {
            'requester': requester,
            'contact': contact,
            'contact_owner': contact_owner,
            'purpose': request.purpose,
            'message': request.message,
        }
        
        # Render email templates
        html_content = render_to_string('emails/introduction.html', context)
        text_content = strip_tags(html_content)
        
        # Create email subject
        subject = f"Introduction: {requester.full_name} <> {contact.full_name}"
        
        # Create email message
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email=f"{contact_owner.full_name} <{settings.DEFAULT_FROM_EMAIL}>",
            to=[requester.email, contact.email],
            cc=[contact_owner.email],
            reply_to=[contact_owner.email],
        )
        
        # Attach HTML content
        email.attach_alternative(html_content, "text/html")
        
        # Send email
        email.send(fail_silently=False)
        
        logger.info(f"Introduction email sent: {requester.email} <> {contact.email}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending introduction email: {str(e)}")
        return False


def send_welcome_email(user):
    """
    Send a welcome email to a new user
    
    Args:
        user: The User instance
    
    Returns:
        bool: Whether the email was sent successfully
    """
    try:
        # Context for email template
        context = {
            'user': user,
        }
        
        # Render email templates
        html_content = render_to_string('emails/welcome.html', context)
        text_content = strip_tags(html_content)
        
        # Create email subject
        subject = f"Welcome to Intro-Hub, {user.first_name}!"
        
        # Create email message
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[user.email],
        )
        
        # Attach HTML content
        email.attach_alternative(html_content, "text/html")
        
        # Send email
        email.send(fail_silently=False)
        
        logger.info(f"Welcome email sent to: {user.email}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending welcome email: {str(e)}")
        return False


def send_request_notification_email(request):
    """
    Send a notification email to a contact owner about a new introduction request
    
    Args:
        request: The IntroductionRequest instance
    
    Returns:
        bool: Whether the email was sent successfully
    """
    try:
        # Get all the required data
        requester = request.requester
        contact = request.contact
        contact_owner = request.contact_owner
        
        # Context for email template
        context = {
            'requester': requester,
            'contact': contact,
            'contact_owner': contact_owner,
            'purpose': request.purpose,
            'request_id': request.id,
        }
        
        # Render email templates
        html_content = render_to_string('emails/request_notification.html', context)
        text_content = strip_tags(html_content)
        
        # Create email subject
        subject = f"New Introduction Request: {requester.full_name} to {contact.full_name}"
        
        # Create email message
        email = EmailMultiAlternatives(
            subject=subject,
            body=text_content,
            from_email=settings.DEFAULT_FROM_EMAIL,
            to=[contact_owner.email],
        )
        
        # Attach HTML content
        email.attach_alternative(html_content, "text/html")
        
        # Send email
        email.send(fail_silently=False)
        
        logger.info(f"Request notification email sent to: {contact_owner.email}")
        return True
        
    except Exception as e:
        logger.error(f"Error sending request notification email: {str(e)}")
        return False
