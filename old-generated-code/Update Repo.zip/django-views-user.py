from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework_simplejwt.views import TokenObtainPairView
from django.contrib.auth import get_user_model
from introhub.serializers.user import (
    UserSerializer, 
    UserCreateSerializer, 
    UserProfileUpdateSerializer,
    PasswordChangeSerializer
)

User = get_user_model()


class UserRegistrationView(generics.CreateAPIView):
    """
    API view for user registration
    """
    serializer_class = UserCreateSerializer
    permission_classes = [permissions.AllowAny]


class UserProfileView(generics.RetrieveUpdateAPIView):
    """
    API view for retrieving and updating the user profile
    """
    serializer_class = UserProfileUpdateSerializer
    permission_classes = [permissions.IsAuthenticated]
    
    def get_object(self):
        """
        Return the current authenticated user
        """
        return self.request.user
    
    def get_serializer_class(self):
        """
        Return different serializers for GET and PUT/PATCH
        """
        if self.request.method == 'GET':
            return UserSerializer
        return UserProfileUpdateSerializer


class PasswordChangeView(APIView):
    """
    API view for changing a user's password
    """
    permission_classes = [permissions.IsAuthenticated]
    
    def post(self, request):
        """
        Change the user's password
        """
        serializer = PasswordChangeSerializer(data=request.data)
        
        if serializer.is_valid():
            # Check if the old password is correct
            if not request.user.check_password(serializer.validated_data['old_password']):
                return Response(
                    {"old_password": ["Wrong password."]},
                    status=status.HTTP_400_BAD_REQUEST
                )
            
            # Set the new password
            request.user.set_password(serializer.validated_data['new_password'])
            request.user.save()
            
            return Response(
                {"detail": "Password changed successfully."},
                status=status.HTTP_200_OK
            )
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class CustomTokenObtainPairView(TokenObtainPairView):
    """
    Custom token view that also returns user data
    """
    def post(self, request, *args, **kwargs):
        """
        Override to add user data to the response
        """
        response = super().post(request, *args, **kwargs)
        
        if response.status_code == status.HTTP_200_OK:
            # Get the user and add user data to the response
            user = User.objects.get(email=request.data.get('email'))
            user_data = UserSerializer(user).data
            
            response.data.update({'user': user_data})
        
        return response
