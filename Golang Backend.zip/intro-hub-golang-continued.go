# Intro-Hub Golang Backend Implementation (Continued)

## API Handlers (Continued)

### Contacts Handler (Continued)

**internal/api/handlers/contacts.go** (continued)
```go
// DeleteContact godoc
// @Summary Delete a contact
// @Description Delete an existing contact
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Contact ID"
// @Success 204 "Contact deleted successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 404 {object} map[string]string "Contact not found"
// @Failure 500 {object} map[string]string "Server error"
// @Router /contacts/{id} [delete]
func (h *ContactHandler) DeleteContact(c *gin.Context) {
	userID := middleware.GetUserID(c)
	
	// Parse contact ID
	contactID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid contact ID"})
		return
	}

	// Delete contact
	err = h.contactService.DeleteContact(c.Request.Context(), uint(contactID), userID)
	if err != nil {
		status := http.StatusInternalServerError
		if err.Error() == "contact not found" {
			status = http.StatusNotFound
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}

	// Return success with no content
	c.Status(http.StatusNoContent)
}

// BatchImportContacts godoc
// @Summary Batch import contacts
// @Description Import multiple contacts at once
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body models.ContactBatchImportRequest true "Batch import data"
// @Success 200 {object} models.BatchImportResponse "Contacts imported successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /contacts/batch-import [post]
func (h *ContactHandler) BatchImportContacts(c *gin.Context) {
	userID := middleware.GetUserID(c)

	var req models.ContactBatchImportRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Import contacts
	result, err := h.contactService.BatchImportContacts(c.Request.Context(), req, userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return result
	c.JSON(http.StatusOK, result)
}
```

### Requests Handler

**internal/api/handlers/requests.go**
```go
package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/api/middleware"
	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/services"
	"github.com/yourusername/intro-hub/internal/utils"
)

// RequestHandler handles introduction request API endpoints
type RequestHandler struct {
	requestService *services.RequestService
}

// NewRequestHandler creates a new RequestHandler
func NewRequestHandler(requestService *services.RequestService) *RequestHandler {
	return &RequestHandler{
		requestService: requestService,
	}
}

// ListRequests godoc
// @Summary List requests
// @Description Get all requests for the current user
// @Tags requests
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param type query string false "Request type (sent or received, default: received)"
// @Success 200 {array} models.RequestResponse "Requests retrieved successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /requests [get]
func (h *RequestHandler) ListRequests(c *gin.Context) {
	userID := middleware.GetUserID(c)
	requestType := c.DefaultQuery("type", "received")
	isSent := requestType == "sent"

	// Get requests
	requests, err := h.requestService.GetRequestsByType(c.Request.Context(), userID, isSent)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Transform requests to responses
	responses := make([]models.RequestResponse, 0, len(requests))
	for _, request := range requests {
		// Get full request data with related entities
		fullRequest, requester, approver, contact, err := h.requestService.GetRequest(
			c.Request.Context(),
			request.ID,
			userID,
		)
		if err != nil {
			// Skip if there's an error retrieving related data (e.g., deleted user)
			continue
		}
		
		responses = append(responses, fullRequest.ToResponse(requester, approver, contact))
	}

	c.JSON(http.StatusOK, responses)
}

// GetRequest godoc
// @Summary Get a request
// @Description Get a specific request by ID
// @Tags requests
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Request ID"
// @Success 200 {object} models.RequestResponse "Request retrieved successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 404 {object} map[string]string "Request not found"
// @Failure 500 {object} map[string]string "Server error"
// @Router /requests/{id} [get]
func (h *RequestHandler) GetRequest(c *gin.Context) {
	userID := middleware.GetUserID(c)
	
	// Parse request ID
	requestID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request ID"})
		return
	}

	// Get request with related entities
	request, requester, approver, contact, err := h.requestService.GetRequest(
		c.Request.Context(),
		uint(requestID),
		userID,
	)
	if err != nil {
		status := http.StatusInternalServerError
		if err.Error() == "request not found" || err.Error() == "unauthorized to access this request" {
			status = http.StatusNotFound
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}

	// Return request data
	c.JSON(http.StatusOK, request.ToResponse(requester, approver, contact))
}

// CreateRequest godoc
// @Summary Create a request
// @Description Create a new introduction request
// @Tags requests
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body models.RequestCreateRequest true "Request creation data"
// @Success 201 {object} models.RequestResponse "Request created successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /requests [post]
func (h *RequestHandler) CreateRequest(c *gin.Context) {
	userID := middleware.GetUserID(c)

	var req models.RequestCreateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Create request
	request, err := h.requestService.CreateRequest(c.Request.Context(), req, userID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Get full request data with related entities
	fullRequest, requester, approver, contact, err := h.requestService.GetRequest(
		c.Request.Context(),
		request.ID,
		userID,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return created request
	c.JSON(http.StatusCreated, fullRequest.ToResponse(requester, approver, contact))
}

// UpdateRequest godoc
// @Summary Update a request
// @Description Update an existing request (approve/decline)
// @Tags requests
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Request ID"
// @Param request body models.RequestUpdateRequest true "Request update data"
// @Success 200 {object} models.RequestResponse "Request updated successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Request not found"
// @Failure 500 {object} map[string]string "Server error"
// @Router /requests/{id} [put]
func (h *RequestHandler) UpdateRequest(c *gin.Context) {
	userID := middleware.GetUserID(c)
	
	// Parse request ID
	requestID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request ID"})
		return
	}

	var req models.RequestUpdateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Update request
	request, err := h.requestService.UpdateRequest(c.Request.Context(), uint(requestID), userID, req)
	if err != nil {
		status := http.StatusInternalServerError
		if err.Error() == "request not found" {
			status = http.StatusNotFound
		} else if err.Error() == "only the approver can update this request" {
			status = http.StatusForbidden
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}

	// Get full request data with related entities
	fullRequest, requester, approver, contact, err := h.requestService.GetRequest(
		c.Request.Context(),
		request.ID,
		userID,
	)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return updated request
	c.JSON(http.StatusOK, fullRequest.ToResponse(requester, approver, contact))
}

// DeleteRequest godoc
// @Summary Delete a request
// @Description Delete an existing request
// @Tags requests
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Request ID"
// @Success 204 "Request deleted successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 403 {object} map[string]string "Forbidden"
// @Failure 404 {object} map[string]string "Request not found"
// @Failure 500 {object} map[string]string "Server error"
// @Router /requests/{id} [delete]
func (h *RequestHandler) DeleteRequest(c *gin.Context) {
	userID := middleware.GetUserID(c)
	
	// Parse request ID
	requestID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request ID"})
		return
	}

	// Delete request
	err = h.requestService.DeleteRequest(c.Request.Context(), uint(requestID), userID)
	if err != nil {
		status := http.StatusInternalServerError
		if err.Error() == "request not found" {
			status = http.StatusNotFound
		} else if err.Error() == "only the requester can delete this request" || err.Error() == "only pending requests can be deleted" {
			status = http.StatusForbidden
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}

	// Return success with no content
	c.Status(http.StatusNoContent)
}
```

## Middleware

**internal/api/middleware/auth.go**
```go
package middleware

import (
	"net/http"
	"strings"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/utils"
)

// AuthMiddleware is a middleware for JWT authentication
func AuthMiddleware(jwtSecret string) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Get authorization header
		authHeader := c.GetHeader("Authorization")
		if authHeader == "" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Authorization header is required"})
			return
		}

		// Check if the header has the Bearer prefix
		if !strings.HasPrefix(authHeader, "Bearer ") {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Authorization header must start with Bearer"})
			return
		}

		// Extract the token
		token := strings.TrimPrefix(authHeader, "Bearer ")
		if token == "" {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Token is required"})
			return
		}

		// Validate and parse the token
		claims, err := utils.ParseJWT(token, jwtSecret)
		if err != nil {
			c.AbortWithStatusJSON(http.StatusUnauthorized, gin.H{"error": "Invalid or expired token"})
			return
		}

		// Store user ID in context
		c.Set("userID", claims.UserID)

		c.Next()
	}
}

// GetUserID retrieves the user ID from the context
func GetUserID(c *gin.Context) uint {
	userID, exists := c.Get("userID")
	if !exists {
		return 0
	}
	return userID.(uint)
}
```

**internal/api/middleware/logger.go**
```go
package middleware

import (
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/pkg/logger"
)

// LoggerMiddleware is a middleware for logging HTTP requests
func LoggerMiddleware(l *logger.Logger) gin.HandlerFunc {
	return func(c *gin.Context) {
		// Start timer
		start := time.Now()

		// Process request
		c.Next()

		// Log request details
		duration := time.Since(start)
		l.Info("Request processed",
			"method", c.Request.Method,
			"path", c.Request.URL.Path,
			"status", c.Writer.Status(),
			"duration", duration,
			"ip", c.ClientIP(),
			"user_agent", c.Request.UserAgent(),
		)
	}
}
```

**internal/api/middleware/cors.go**
```go
package middleware

import (
	"github.com/gin-contrib/cors"
	"github.com/gin-gonic/gin"
)

// CorsMiddleware is a middleware for CORS configuration
func CorsMiddleware(allowedOrigins []string) gin.HandlerFunc {
	config := cors.DefaultConfig()
	
	// Set allowed origins
	if len(allowedOrigins) == 1 && allowedOrigins[0] == "*" {
		config.AllowAllOrigins = true
	} else {
		config.AllowOrigins = allowedOrigins
	}
	
	// Set allowed methods
	config.AllowMethods = []string{"GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"}
	
	// Set allowed headers
	config.AllowHeaders = []string{
		"Origin",
		"Content-Length",
		"Content-Type",
		"Authorization",
	}
	
	return cors.New(config)
}
```

## Router

**internal/api/router/router.go**
```go
package router

import (
	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/api/handlers"
	"github.com/yourusername/intro-hub/internal/api/middleware"
	"github.com/yourusername/intro-hub/internal/config"
	"github.com/yourusername/intro-hub/internal/domain/repositories"
	"github.com/yourusername/intro-hub/internal/email"
	"github.com/yourusername/intro-hub/internal/services"
	"github.com/yourusername/intro-hub/pkg/logger"
)

// NewRouter creates a new router with all routes configured
func NewRouter(
	cfg *config.Config,
	l *logger.Logger,
	userRepo repositories.UserRepository,
	contactRepo repositories.ContactRepository,
	requestRepo repositories.RequestRepository,
) *gin.Engine {
	// Set gin mode
	if cfg.ServerEnv == "production" {
		gin.SetMode(gin.ReleaseMode)
	}

	// Create router
	r := gin.New()

	// Add middlewares
	r.Use(gin.Recovery())
	r.Use(middleware.LoggerMiddleware(l))
	r.Use(middleware.CorsMiddleware(cfg.AllowedOrigins))

	// Set trusted proxies
	r.SetTrustedProxies(cfg.TrustedProxies)

	// Create mailer
	mailer := email.NewMailer(
		cfg.SMTPHost,
		cfg.SMTPPort,
		cfg.SMTPUsername,
		cfg.SMTPPassword,
		cfg.SMTPFromEmail,
		cfg.SMTPFromName,
	)

	// Create services
	authService := services.NewAuthService(userRepo, cfg.JWTSecret, cfg.JWTExpiryHours)
	userService := services.NewUserService(userRepo)
	contactService := services.NewContactService(contactRepo, userRepo)
	requestService := services.NewRequestService(requestRepo, contactRepo, userRepo, mailer)

	// Create handlers
	authHandler := handlers.NewAuthHandler(authService)
	userHandler := handlers.NewUserHandler(userService)
	contactHandler := handlers.NewContactHandler(contactService, userService)
	requestHandler := handlers.NewRequestHandler(requestService)

	// Health check
	r.GET("/health", func(c *gin.Context) {
		c.JSON(200, gin.H{"status": "ok"})
	})

	// API v1 routes
	v1 := r.Group("/api/v1")
	{
		// Auth routes (no authentication required)
		auth := v1.Group("/auth")
		{
			auth.POST("/register", authHandler.Register)
			auth.POST("/login", authHandler.Login)
		}

		// Protected routes (authentication required)
		protected := v1.Group("")
		protected.Use(middleware.AuthMiddleware(cfg.JWTSecret))
		{
			// User profile
			protected.GET("/profile", userHandler.GetProfile)
			protected.PUT("/profile", userHandler.UpdateProfile)

			// Contacts
			contacts := protected.Group("/contacts")
			{
				contacts.GET("", contactHandler.ListContacts)
				contacts.POST("", contactHandler.CreateContact)
				contacts.GET("/:id", contactHandler.GetContact)
				contacts.PUT("/:id", contactHandler.UpdateContact)
				contacts.DELETE("/:id", contactHandler.DeleteContact)
				contacts.POST("/batch-import", contactHandler.BatchImportContacts)
			}

			// Introduction requests
			requests := protected.Group("/requests")
			{
				requests.GET("", requestHandler.ListRequests)
				requests.POST("", requestHandler.CreateRequest)
				requests.GET("/:id", requestHandler.GetRequest)
				requests.PUT("/:id", requestHandler.UpdateRequest)
				requests.DELETE("/:id", requestHandler.DeleteRequest)
			}
		}
	}

	return r
}
```

## Server Configuration

**internal/api/server.go**
```go
package api

import (
	"fmt"
	"net/http"
	"time"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/config"
)

// Server represents the HTTP server
type Server struct {
	*http.Server
}

// NewServer creates a new HTTP server
func NewServer(cfg *config.Config, handler *gin.Engine) *Server {
	return &Server{
		Server: &http.Server{
			Addr:         fmt.Sprintf(":%s", cfg.ServerPort),
			Handler:      handler,
			ReadTimeout:  cfg.ServerTimeout,
			WriteTimeout: cfg.ServerTimeout,
			IdleTimeout:  120 * time.Second,
		},
	}
}
```

## Utility Functions

**internal/utils/jwt.go**
```go
package utils

import (
	"fmt"
	"time"

	"github.com/golang-jwt/jwt/v4"
)

// JWTClaims represents the JWT claims
type JWTClaims struct {
	UserID uint `json:"user_id"`
	jwt.RegisteredClaims
}

// GenerateJWT generates a new JWT token
func GenerateJWT(userID uint, secret string, expiry time.Duration) (string, error) {
	expirationTime := time.Now().Add(expiry)
	
	claims := JWTClaims{
		UserID: userID,
		RegisteredClaims: jwt.RegisteredClaims{
			ExpiresAt: jwt.NewNumericDate(expirationTime),
			IssuedAt:  jwt.NewNumericDate(time.Now()),
		},
	}

	token := jwt.NewWithClaims(jwt.SigningMethodHS256, claims)
	tokenString, err := token.SignedString([]byte(secret))
	if err != nil {
		return "", fmt.Errorf("error signing token: %w", err)
	}

	return tokenString, nil
}

// ParseJWT validates and parses a JWT token
func ParseJWT(tokenString, secret string) (*JWTClaims, error) {
	claims := &JWTClaims{}
	
	token, err := jwt.ParseWithClaims(tokenString, claims, func(token *jwt.Token) (interface{}, error) {
		if _, ok := token.Method.(*jwt.SigningMethodHMAC); !ok {
			return nil, fmt.Errorf("unexpected signing method: %v", token.Header["alg"])
		}
		return []byte(secret), nil
	})
	
	if err != nil {
		return nil, fmt.Errorf("error parsing token: %w", err)
	}
	
	if !token.Valid {
		return nil, fmt.Errorf("invalid token")
	}
	
	return claims, nil
}
```

**internal/utils/password.go**
```go
package utils

import (
	"fmt"

	"golang.org/x/crypto/bcrypt"
)

// HashPassword generates a bcrypt hash from a password
func HashPassword(password string) (string, error) {
	// Use a cost of 10 for bcrypt
	bytes, err := bcrypt.GenerateFromPassword([]byte(password), 10)
	if err != nil {
		return "", fmt.Errorf("error hashing password: %w", err)
	}
	return string(bytes), nil
}

// CheckPasswordHash compares a password with a hash to check if they match
func CheckPasswordHash(password, hash string) bool {
	err := bcrypt.CompareHashAndPassword([]byte(hash), []byte(password))
	return err == nil
}
```

**internal/utils/validator.go**
```go
package utils

import (
	"fmt"
	"reflect"
	"strings"

	"github.com/go-playground/locales/en"
	ut "github.com/go-playground/universal-translator"
	"github.com/go-playground/validator/v10"
	en_translations "github.com/go-playground/validator/v10/translations/en"
)

var (
	validate   *validator.Validate
	translator ut.Translator
)

func init() {
	// Initialize validator
	validate = validator.New()
	
	// Register validation for struct fields
	validate.RegisterTagNameFunc(func(fld reflect.StructField) string {
		name := strings.SplitN(fld.Tag.Get("json"), ",", 2)[0]
		if name == "-" {
			return ""
		}
		return name
	})
	
	// Set up translator
	english := en.New()
	uni := ut.New(english, english)
	translator, _ = uni.GetTranslator("en")
	en_translations.RegisterDefaultTranslations(validate, translator)
}

// Validate validates a struct using the validator
func Validate(s interface{}) error {
	if err := validate.Struct(s); err != nil {
		validationErrors := err.(validator.ValidationErrors)
		translatedErrors := validationErrors.Translate(translator)
		
		// Build user-friendly error messages
		var errorMessages []string
		for _, e := range validationErrors {
			errorMessages = append(errorMessages, translatedErrors[e.Namespace()])
		}
		
		if len(errorMessages) > 0 {
			return fmt.Errorf("validation failed: %s", strings.Join(errorMessages, ", "))
		}
		
		return fmt.Errorf("validation failed")
	}
	
	return nil
}
```

## Logger Package

**pkg/logger/logger.go**
```go
package logger

import (
	"os"
	"strings"

	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
)

// Logger is a wrapper around zerolog.Logger
type Logger struct {
	logger zerolog.Logger
}

// NewLogger creates a new logger with the specified log level
func NewLogger(level string) *Logger {
	// Set up pretty console logging for development
	output := zerolog.ConsoleWriter{Out: os.Stdout, TimeFormat: "2006-01-02 15:04:05"}
	
	// Set log level
	var logLevel zerolog.Level
	switch strings.ToLower(level) {
	case "debug":
		logLevel = zerolog.DebugLevel
	case "info":
		logLevel = zerolog.InfoLevel
	case "warn":
		logLevel = zerolog.WarnLevel
	case "error":
		logLevel = zerolog.ErrorLevel
	case "fatal":
		logLevel = zerolog.FatalLevel
	default:
		logLevel = zerolog.InfoLevel
	}
	
	// Configure zerolog
	zerolog.SetGlobalLevel(logLevel)
	l := log.Output(output).With().Timestamp().Logger()
	
	return &Logger{
		logger: l,
	}
}

// Debug logs a debug message
func (l *Logger) Debug(msg string, args ...interface{}) {
	l.logger.Debug().Fields(argsToMap(args)).Msg(msg)
}

// Info logs an info message
func (l *Logger) Info(msg string, args ...interface{}) {
	l.logger.Info().Fields(argsToMap(args)).Msg(msg)
}

// Warn logs a warning message
func (l *Logger) Warn(msg string, args ...interface{}) {
	l.logger.Warn().Fields(argsToMap(args)).Msg(msg)
}

// Error logs an error message
func (l *Logger) Error(msg string, args ...interface{}) {
	l.logger.Error().Fields(argsToMap(args)).Msg(msg)
}

// Fatal logs a fatal message and terminates the application
func (l *Logger) Fatal(msg string, args ...interface{}) {
	l.logger.Fatal().Fields(argsToMap(args)).Msg(msg)
}

// Helper function to convert a slice of key-value pairs to a map
func argsToMap(args []interface{}) map[string]interface{} {
	if len(args) == 0 {
		return nil
	}
	
	if len(args)%2 != 0 {
		// If the number of arguments is odd, add a placeholder for the last value
		args = append(args, "(missing)")
	}
	
	result := make(map[string]interface{}, len(args)/2)
	for i := 0; i < len(args); i += 2 {
		key, ok := args[i].(string)
		if !ok {
			key = "unknown"
		}
		result[key] = args[i+1]
	}
	
	return result
}
```

## Email Templates

**internal/email/templates/new_request.html**
```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction Request</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        blockquote {
            background-color: #f9f9f9;
            border-left: 4px solid #2c3e50;
            margin: 15px 0;
            padding: 10px 20px;
        }
        .button {
            display: inline-block;
            background-color: #3498db;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            margin-top: 20px;
        }
    </style>
</head>
<body>
    <h1>Introduction Request</h1>

    <p>{{ .Requester.FirstName }} {{ .Requester.LastName }} would like you to introduce them to your contact {{ .Contact.FirstName }} {{ .Contact.LastName }}.</p>

    <h2>Message from {{ .Requester.FirstName }}:</h2>
    <blockquote>
        {{ .Request.Message }}
    </blockquote>

    <p>
        To approve or decline this request, please log in to your Intro-Hub account.
    </p>
</body>
</html>
```

**internal/email/templates/request_approved.html**
```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction: {{ .Requester.FirstName }} {{ .Requester.LastName }} and {{ .Contact.FirstName }} {{ .Contact.LastName }}</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        hr {
            border: 0;
            height: 1px;
            background-color: #eee;
            margin: 20px 0;
        }
        blockquote {
            background-color: #f9f9f9;
            border-left: 4px solid #2c3e50;
            margin: 15px 0;
            padding: 10px 20px;
        }
    </style>
</head>
<body>
    <h1>Introduction: {{ .Requester.FirstName }} {{ .Requester.LastName }} and {{ .Contact.FirstName }} {{ .Contact.LastName }}</h1>

    <p>Hello both,</p>

    <p>I'd like to introduce:</p>

    <p>
        <strong>{{ .Requester.FirstName }} {{ .Requester.LastName }}</strong> ({{ .Requester.Email }})
        {{ if .Requester.Company }}
            of {{ .Requester.Company }}
            {{ if .Requester.Position }}
                ({{ .Requester.Position }})
            {{ end }}
        {{ end }}
    </p>

    <p>to</p>

    <p>
        <strong>{{ .Contact.FirstName }} {{ .Contact.LastName }}</strong> ({{ .Contact.Email }})
        {{ if .Contact.Company }}
            of {{ .Contact.Company }}
            {{ if .Contact.Position }}
                ({{ .Contact.Position }})
            {{ end }}
        {{ end }}
    </p>

    {{ if .Request.ResponseMessage }}
        <p><em>{{ .Approver.FirstName }} says: {{ .Request.ResponseMessage }}</em></p>
    {{ end }}

    <hr>

    <p>{{ .Requester.FirstName }} wrote:</p>
    <blockquote>
        {{ .Request.Message }}
    </blockquote>

    <p>I'll leave you to take it from here!</p>

    <p>Best,<br>{{ .Approver.FirstName }} {{ .Approver.LastName }}</p>
</body>
</html>
```

**internal/email/templates/request_declined.html**
```html
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Introduction Request Declined</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
        }
        h1 {
            color: #2c3e50;
            border-bottom: 1px solid #eee;
            padding-bottom: 10px;
        }
        blockquote {
            background-color: #f9f9f9;
            border-left: 4px solid #2c3e50;
            margin: 15px 0;
            padding: 10px 20px;
        }
    </style>
</head>
<body>
    <h1>Introduction Request Declined</h1>

    <p>Hello {{ .Requester.FirstName }},</p>

    <p>
        Your request for an introduction to {{ .Contact.FirstName }} {{ .Contact.LastName }} has been declined by {{ .Approver.FirstName }} {{ .Approver.LastName }}.
    </p>

    {{ if .Request.ResponseMessage }}
        <p>Message from {{ .Approver.FirstName }}:</p>
        <blockquote>
            {{ .Request.ResponseMessage }}
        </blockquote>
    {{ end }}
</body>
</html>
```

## Docker Configuration

**Dockerfile**
```dockerfile
# Build stage
FROM golang:1.18-alpine AS build

# Set working directory
WORKDIR /app

# Install build dependencies
RUN apk add --no-cache git

# Copy go.mod and go.sum files
COPY go.mod go.sum ./

# Download dependencies
RUN go mod download

# Copy source code
COPY . .

# Build the application
RUN CGO_ENABLED=0 GOOS=linux go build -a -installsuffix cgo -o intro-hub ./cmd/api

# Final stage
FROM alpine:3.15

# Set working directory
WORKDIR /app

# Install CA certificates
RUN apk --no-cache add ca-certificates

# Copy the binary from the build stage
COPY --from=build /app/intro-hub .

# Copy email templates
COPY --from=build /app/internal/email/templates ./internal/email/templates

# Expose port
EXPOSE 8080

# Run the application
CMD ["./intro-hub"]
```

**docker-compose.yml**
```yaml
version: '3.8'

services:
  app:
    build: .
    ports:
      - "8080:8080"
    env_file:
      - .env
    depends_on:
      - db
    restart: unless-stopped

  db:
    image: mysql:8.0
    environment:
      MYSQL_ROOT_PASSWORD: ${MYSQL_ROOT_PASSWORD}
      MYSQL_DATABASE: ${MYSQL_DATABASE}
      MYSQL_USER: ${MYSQL_USER}
      MYSQL_PASSWORD: ${MYSQL_PASSWORD}
    ports:
      - "3306:3306"
    volumes:
      - mysql_data:/var/lib/mysql
    command: --default-authentication-plugin=mysql_native_password
    restart: unless-stopped

volumes:
  mysql_data:
```

## Environment File

**.env.example**
```
# Server
SERVER_PORT=8080
SERVER_TIMEOUT_SECONDS=30
SERVER_ENV=development
ALLOWED_ORIGINS=*
LOG_LEVEL=info

# Database
MYSQL_DSN=root:password@tcp(db:3306)/introhub?parseTime=true
MYSQL_ROOT_PASSWORD=password
MYSQL_DATABASE=introhub
MYSQL_USER=introhub
MYSQL_PASSWORD=password

# JWT
JWT_SECRET=your-secret-key
JWT_EXPIRY_HOURS=24

# SMTP
SMTP_HOST=smtp.example.com
SMTP_PORT=587
SMTP_USERNAME=your-username
SMTP_PASSWORD=your-password
SMTP_FROM_EMAIL=noreply@introhub.com
SMTP_FROM_NAME=Intro-Hub
```

## Module Dependencies

**go.mod**
```go
module github.com/yourusername/intro-hub

go 1.18

require (
	github.com/gin-contrib/cors v1.4.0
	github.com/gin-gonic/gin v1.8.1
	github.com/go-playground/locales v0.14.0
	github.com/go-playground/universal-translator v0.18.0
	github.com/go-playground/validator/v10 v10.11.0
	github.com/go-sql-driver/mysql v1.6.0
	github.com/golang-jwt/jwt/v4 v4.4.2
	github.com/golang-migrate/migrate/v4 v4.15.2
	github.com/joho/godotenv v1.4.0
	github.com/rs/zerolog v1.27.0
	golang.org/x/crypto v0.0.0-20220622213112-05595931fe9d
)

require (
	github.com/gin-contrib/sse v0.1.0 // indirect
	github.com/goccy/go-json v0.9.7 // indirect
	github.com/hashicorp/errwrap v1.1.0 // indirect
	github.com/hashicorp/go-multierror v1.1.1 // indirect
	github.com/json-iterator/go v1.1.12 // indirect
	github.com/leodido/go-urn v1.2.1 // indirect
	github.com/mattn/go-colorable v0.1.12 // indirect
	github.com/mattn/go-isatty v0.0.14 // indirect
	github.com/modern-go/concurrent v0.0.0-20180306012644-bacd9c7ef1dd // indirect
	github.com/modern-go/reflect2 v1.0.2 // indirect
	github.com/pelletier/go-toml/v2 v2.0.1 // indirect
	github.com/ugorji/go/codec v1.2.7 // indirect
	go.uber.org/atomic v1.7.0 // indirect
	golang.org/x/net v0.0.0-20220225172249-27dd8689420f // indirect
	golang.org/x/sys v0.0.0-20220317061510-51cd9980dadf // indirect
	golang.org/x/text v0.3.7 // indirect
	google.golang.org/protobuf v1.28.0 // indirect
	gopkg.in/yaml.v2 v2.4.0 // indirect
)
```

## README

**README.md**
```markdown
# Intro-Hub Golang Backend

A Golang backend for the Intro-Hub platform for facilitating warm introductions between B2B SaaS sales teams and potential leads through existing networks.

## Features

- User Authentication: Sign-up and login functionality with JWT
- Contact Management: Upload and manage your contacts
- Introduction Requests: Search for contacts and request introductions
- Introduction Approval: Review and approve/deny introduction requests
- Email Introductions: Send introduction emails when requests are approved

## Technologies Used

- Golang 1.18+
- Gin Web Framework
- MySQL Database
- JWT Authentication
- Clean Architecture
- Docker & Docker Compose

## Project Structure

The project follows a clean architecture approach with the following components:

- `cmd/api`: Application entry point
- `internal/domain`: Domain models and repository interfaces
- `internal/repository`: Repository implementations (MySQL)
- `internal/services`: Business logic services
- `internal/api`: HTTP handlers and middleware
- `internal/utils`: Utility functions
- `pkg/logger`: Logging package

## Getting Started

### Prerequisites

- Go 1.18 or higher
- MySQL 8.0
- Docker and Docker Compose (optional)

### Installation

#### Using Docker

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   ```

2. Set up environment variables:
   ```
   cp .env.example .env
   ```
   Edit the `.env` file to match your desired settings.

3. Start the application with Docker Compose:
   ```
   docker-compose up -d
   ```

#### Manual Setup

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   ```

2. Set up environment variables:
   ```
   cp .env.example .env
   ```
   Edit the `.env` file to match your local environment.

3. Set up MySQL database:
   ```
   mysql -u root -p
   CREATE DATABASE introhub;
   ```

4. Build and run the application:
   ```
   go build -o intro-hub ./cmd/api
   ./intro-hub
   ```

## API Endpoints

### Authentication
- `POST /api/v1/auth/register` - Create a new user account
- `POST /api/v1/auth/login` - Login and get JWT token

### Profile
- `GET /api/v1/profile` - Get current user profile
- `PUT /api/v1/profile` - Update current user profile

### Contacts
- `GET /api/v1/contacts` - List all contacts (with optional search query)
- `GET /api/v1/contacts/:id` - Get a specific contact
- `POST /api/v1/contacts` - Create a new contact
- `PUT /api/v1/contacts/:id` - Update a contact
- `DELETE /api/v1/contacts/:id` - Delete a contact
- `POST /api/v1/contacts/batch-import` - Import multiple contacts

### Introduction Requests
- `GET /api/v1/requests` - List all requests (use `?type=sent` for sent requests)
- `GET /api/v1/requests/:id` - Get a specific request
- `POST /api/v1/requests` - Create a new request
- `PUT /api/v1/requests/:id` - Update a request (approve/decline)
- `DELETE /api/v1/requests/:id` - Delete a request

## License

This project is licensed under the MIT License.
```
