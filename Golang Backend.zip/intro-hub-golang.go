# Intro-Hub Golang Backend

This document outlines the complete Golang implementation for the Intro-Hub backend, using MySQL for data persistence and following industry best practices.

## Project Structure

```
intro-hub/
├── cmd/
│   └── api/
│       └── main.go                 # Application entry point
├── internal/
│   ├── api/
│   │   ├── handlers/               # API handlers
│   │   │   ├── auth.go
│   │   │   ├── contacts.go
│   │   │   ├── requests.go
│   │   │   └── users.go
│   │   ├── middleware/             # Middleware components
│   │   │   ├── auth.go
│   │   │   ├── logger.go
│   │   │   └── cors.go
│   │   ├── router/                 # Router setup
│   │   │   └── router.go
│   │   └── server.go               # HTTP server configuration
│   ├── config/                     # Configuration
│   │   └── config.go
│   ├── domain/                     # Domain models and interfaces
│   │   ├── models/
│   │   │   ├── user.go
│   │   │   ├── contact.go
│   │   │   └── request.go
│   │   └── repositories/
│   │       ├── user_repository.go
│   │       ├── contact_repository.go
│   │       └── request_repository.go
│   ├── email/                      # Email functionality
│   │   └── mailer.go
│   ├── errors/                     # Custom error types
│   │   └── errors.go
│   ├── repository/                 # Repository implementations
│   │   ├── mysql/
│   │   │   ├── mysql.go
│   │   │   ├── user_repository.go
│   │   │   ├── contact_repository.go
│   │   │   └── request_repository.go
│   │   └── migrations/             # Database migrations
│   │       ├── 000001_init_schema.up.sql
│   │       └── 000001_init_schema.down.sql
│   ├── services/                   # Business logic services
│   │   ├── auth_service.go
│   │   ├── contact_service.go
│   │   ├── request_service.go
│   │   └── user_service.go
│   └── utils/                      # Utility functions
│       ├── jwt.go
│       ├── password.go
│       └── validator.go
├── pkg/                            # Public packages
│   └── logger/
│       └── logger.go
├── .env.example                    # Example environment variables
├── Dockerfile                      # Docker configuration
├── docker-compose.yml              # Docker Compose configuration
├── go.mod                          # Go module definition
├── go.sum                          # Go module checksums
└── README.md                       # Project documentation
```

## Implementation Details

### Main Application Entry Point

**cmd/api/main.go**
```go
package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/joho/godotenv"
	"github.com/yourusername/intro-hub/internal/api/router"
	"github.com/yourusername/intro-hub/internal/api/server"
	"github.com/yourusername/intro-hub/internal/config"
	"github.com/yourusername/intro-hub/internal/repository/mysql"
	"github.com/yourusername/intro-hub/pkg/logger"
)

func main() {
	// Load environment variables
	if err := godotenv.Load(); err != nil {
		log.Println("No .env file found, using environment variables")
	}

	// Initialize config
	cfg := config.NewConfig()

	// Initialize logger
	l := logger.NewLogger(cfg.LogLevel)

	// Connect to MySQL
	db, err := mysql.NewMySQLConnection(cfg.MySQLDSN)
	if err != nil {
		l.Fatal("Failed to connect to MySQL", "error", err)
	}
	defer db.Close()

	// Run database migrations
	if err := mysql.MigrateDatabase(cfg.MySQLDSN); err != nil {
		l.Fatal("Failed to run database migrations", "error", err)
	}

	// Initialize repositories
	userRepo := mysql.NewUserRepository(db)
	contactRepo := mysql.NewContactRepository(db)
	requestRepo := mysql.NewRequestRepository(db)

	// Create the router
	r := router.NewRouter(cfg, l, userRepo, contactRepo, requestRepo)

	// Initialize and start the server
	srv := server.NewServer(cfg, r)
	go func() {
		l.Info("Starting server", "port", cfg.ServerPort)
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			l.Fatal("Server failed to start", "error", err)
		}
	}()

	// Wait for interrupt signal to gracefully shut down the server
	quit := make(chan os.Signal, 1)
	signal.Notify(quit, syscall.SIGINT, syscall.SIGTERM)
	<-quit

	l.Info("Shutting down server...")

	// Create a deadline for server shutdown
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	// Attempt graceful shutdown
	if err := srv.Shutdown(ctx); err != nil {
		l.Fatal("Server forced to shutdown", "error", err)
	}

	l.Info("Server exited properly")
}
```

### Configuration

**internal/config/config.go**
```go
package config

import (
	"os"
	"strconv"
	"time"
)

// Config holds all configuration for the application
type Config struct {
	// Server
	ServerPort      string
	ServerTimeout   time.Duration
	ServerEnv       string
	AllowedOrigins  []string
	TrustedProxies  []string
	LogLevel        string

	// Database
	MySQLDSN        string

	// JWT
	JWTSecret       string
	JWTExpiryHours  int

	// Email
	SMTPHost        string
	SMTPPort        int
	SMTPUsername    string
	SMTPPassword    string
	SMTPFromEmail   string
	SMTPFromName    string
}

// NewConfig creates a new Config instance
func NewConfig() *Config {
	jwtExpiryHours, _ := strconv.Atoi(getEnv("JWT_EXPIRY_HOURS", "24"))
	smtpPort, _ := strconv.Atoi(getEnv("SMTP_PORT", "587"))

	return &Config{
		// Server
		ServerPort:      getEnv("SERVER_PORT", "8080"),
		ServerTimeout:   time.Duration(getIntEnv("SERVER_TIMEOUT_SECONDS", 30)) * time.Second,
		ServerEnv:       getEnv("SERVER_ENV", "development"),
		AllowedOrigins:  getEnvSlice("ALLOWED_ORIGINS", []string{"*"}),
		TrustedProxies:  getEnvSlice("TRUSTED_PROXIES", []string{}),
		LogLevel:        getEnv("LOG_LEVEL", "info"),

		// Database
		MySQLDSN:        getEnv("MYSQL_DSN", "root:password@tcp(localhost:3306)/introhub?parseTime=true"),

		// JWT
		JWTSecret:       getEnv("JWT_SECRET", "your-secret-key"),
		JWTExpiryHours:  jwtExpiryHours,

		// Email
		SMTPHost:        getEnv("SMTP_HOST", "smtp.example.com"),
		SMTPPort:        smtpPort,
		SMTPUsername:    getEnv("SMTP_USERNAME", ""),
		SMTPPassword:    getEnv("SMTP_PASSWORD", ""),
		SMTPFromEmail:   getEnv("SMTP_FROM_EMAIL", "noreply@introhub.com"),
		SMTPFromName:    getEnv("SMTP_FROM_NAME", "Intro-Hub"),
	}
}

// Helper function to get environment variable with fallback
func getEnv(key, fallback string) string {
	if value, exists := os.LookupEnv(key); exists {
		return value
	}
	return fallback
}

// Helper function to get integer environment variable with fallback
func getIntEnv(key string, fallback int) int {
	if value, exists := os.LookupEnv(key); exists {
		if intVal, err := strconv.Atoi(value); err == nil {
			return intVal
		}
	}
	return fallback
}

// Helper function to get slice environment variable with fallback
func getEnvSlice(key string, fallback []string) []string {
	if value, exists := os.LookupEnv(key); exists {
		return []string{value} // For simplicity; in a real app, you might split by comma
	}
	return fallback
}
```

### Domain Models

**internal/domain/models/user.go**
```go
package models

import (
	"time"

	"github.com/yourusername/intro-hub/internal/utils"
)

// User represents a user entity
type User struct {
	ID              uint      `json:"id"`
	Email           string    `json:"email"`
	PasswordHash    string    `json:"-"` // Never expose in JSON
	FirstName       string    `json:"first_name"`
	LastName        string    `json:"last_name"`
	Company         string    `json:"company"`
	Position        string    `json:"position"`
	Bio             string    `json:"bio"`
	ProfilePicture  string    `json:"profile_picture"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}

// UserSignupRequest represents the request to create a new user
type UserSignupRequest struct {
	Email             string `json:"email" validate:"required,email"`
	Password          string `json:"password" validate:"required,min=6"`
	PasswordConfirm   string `json:"password_confirm" validate:"required,eqfield=Password"`
	FirstName         string `json:"first_name" validate:"required"`
	LastName          string `json:"last_name" validate:"required"`
	Company           string `json:"company"`
	Position          string `json:"position"`
}

// UserLoginRequest represents the request to login a user
type UserLoginRequest struct {
	Email    string `json:"email" validate:"required,email"`
	Password string `json:"password" validate:"required"`
}

// UserUpdateRequest represents the request to update a user's profile
type UserUpdateRequest struct {
	FirstName       string `json:"first_name"`
	LastName        string `json:"last_name"`
	Company         string `json:"company"`
	Position        string `json:"position"`
	Bio             string `json:"bio"`
	ProfilePicture  string `json:"profile_picture"`
}

// UserResponse represents the user data to be returned in responses
type UserResponse struct {
	ID              uint      `json:"id"`
	Email           string    `json:"email"`
	FirstName       string    `json:"first_name"`
	LastName        string    `json:"last_name"`
	FullName        string    `json:"full_name"`
	Company         string    `json:"company"`
	Position        string    `json:"position"`
	Bio             string    `json:"bio,omitempty"`
	ProfilePicture  string    `json:"profile_picture,omitempty"`
	CreatedAt       time.Time `json:"created_at"`
	UpdatedAt       time.Time `json:"updated_at"`
}

// NewUserFromSignupRequest creates a new User from a UserSignupRequest
func NewUserFromSignupRequest(req UserSignupRequest) (*User, error) {
	passwordHash, err := utils.HashPassword(req.Password)
	if err != nil {
		return nil, err
	}

	now := time.Now()
	return &User{
		Email:          req.Email,
		PasswordHash:   passwordHash,
		FirstName:      req.FirstName,
		LastName:       req.LastName,
		Company:        req.Company,
		Position:       req.Position,
		CreatedAt:      now,
		UpdatedAt:      now,
	}, nil
}

// ToResponse converts a User to a UserResponse
func (u *User) ToResponse() UserResponse {
	return UserResponse{
		ID:             u.ID,
		Email:          u.Email,
		FirstName:      u.FirstName,
		LastName:       u.LastName,
		FullName:       u.FirstName + " " + u.LastName,
		Company:        u.Company,
		Position:       u.Position,
		Bio:            u.Bio,
		ProfilePicture: u.ProfilePicture,
		CreatedAt:      u.CreatedAt,
		UpdatedAt:      u.UpdatedAt,
	}
}

// CheckPassword validates the provided password against the user's stored hash
func (u *User) CheckPassword(password string) bool {
	return utils.CheckPasswordHash(password, u.PasswordHash)
}
```

**internal/domain/models/contact.go**
```go
package models

import (
	"time"
)

// Contact represents a contact entity
type Contact struct {
	ID           uint      `json:"id"`
	UserID       uint      `json:"user_id"`
	Email        string    `json:"email"`
	FirstName    string    `json:"first_name"`
	LastName     string    `json:"last_name"`
	Company      string    `json:"company"`
	Position     string    `json:"position"`
	Notes        string    `json:"notes"`
	Phone        string    `json:"phone"`
	LinkedInURL  string    `json:"linkedin_url"`
	CreatedAt    time.Time `json:"created_at"`
	UpdatedAt    time.Time `json:"updated_at"`
}

// ContactCreateRequest represents the request to create a new contact
type ContactCreateRequest struct {
	Email        string `json:"email" validate:"required,email"`
	FirstName    string `json:"first_name" validate:"required"`
	LastName     string `json:"last_name" validate:"required"`
	Company      string `json:"company"`
	Position     string `json:"position"`
	Notes        string `json:"notes"`
	Phone        string `json:"phone"`
	LinkedInURL  string `json:"linkedin_url"`
}

// ContactUpdateRequest represents the request to update a contact
type ContactUpdateRequest struct {
	Email        string `json:"email" validate:"omitempty,email"`
	FirstName    string `json:"first_name"`
	LastName     string `json:"last_name"`
	Company      string `json:"company"`
	Position     string `json:"position"`
	Notes        string `json:"notes"`
	Phone        string `json:"phone"`
	LinkedInURL  string `json:"linkedin_url"`
}

// ContactBatchImportRequest represents a batch of contacts to import
type ContactBatchImportRequest struct {
	Contacts []ContactCreateRequest `json:"contacts" validate:"required,dive"`
}

// ContactResponse represents a contact in API responses
type ContactResponse struct {
	ID           uint         `json:"id"`
	Email        string       `json:"email"`
	FirstName    string       `json:"first_name"`
	LastName     string       `json:"last_name"`
	FullName     string       `json:"full_name"`
	Company      string       `json:"company"`
	Position     string       `json:"position"`
	Notes        string       `json:"notes,omitempty"`
	Phone        string       `json:"phone,omitempty"`
	LinkedInURL  string       `json:"linkedin_url,omitempty"`
	User         UserResponse `json:"user"`
	CreatedAt    time.Time    `json:"created_at"`
	UpdatedAt    time.Time    `json:"updated_at"`
}

// BatchImportResponse represents the response for a batch import
type BatchImportResponse struct {
	SuccessCount int                 `json:"success_count"`
	ErrorCount   int                 `json:"error_count"`
	Errors       []BatchImportError  `json:"errors,omitempty"`
}

// BatchImportError represents an error during batch import
type BatchImportError struct {
	Data   ContactCreateRequest `json:"data"`
	Errors []string             `json:"errors"`
}

// NewContactFromCreateRequest creates a new Contact from a ContactCreateRequest
func NewContactFromCreateRequest(req ContactCreateRequest, userID uint) *Contact {
	now := time.Now()
	return &Contact{
		UserID:      userID,
		Email:       req.Email,
		FirstName:   req.FirstName,
		LastName:    req.LastName,
		Company:     req.Company,
		Position:    req.Position,
		Notes:       req.Notes,
		Phone:       req.Phone,
		LinkedInURL: req.LinkedInURL,
		CreatedAt:   now,
		UpdatedAt:   now,
	}
}

// ToResponse converts a Contact to a ContactResponse
func (c *Contact) ToResponse(user *User) ContactResponse {
	return ContactResponse{
		ID:          c.ID,
		Email:       c.Email,
		FirstName:   c.FirstName,
		LastName:    c.LastName,
		FullName:    c.FirstName + " " + c.LastName,
		Company:     c.Company,
		Position:    c.Position,
		Notes:       c.Notes,
		Phone:       c.Phone,
		LinkedInURL: c.LinkedInURL,
		User:        user.ToResponse(),
		CreatedAt:   c.CreatedAt,
		UpdatedAt:   c.UpdatedAt,
	}
}
```

**internal/domain/models/request.go**
```go
package models

import (
	"time"
)

// RequestStatus represents the status of an introduction request
type RequestStatus string

const (
	RequestStatusPending  RequestStatus = "pending"
	RequestStatusApproved RequestStatus = "approved"
	RequestStatusDeclined RequestStatus = "declined"
)

// IntroductionRequest represents an introduction request
type IntroductionRequest struct {
	ID               uint          `json:"id"`
	RequesterID      uint          `json:"requester_id"`
	ApproverID       uint          `json:"approver_id"`
	TargetContactID  uint          `json:"target_contact_id"`
	Message          string        `json:"message"`
	Status           RequestStatus `json:"status"`
	ResponseMessage  string        `json:"response_message"`
	CreatedAt        time.Time     `json:"created_at"`
	UpdatedAt        time.Time     `json:"updated_at"`
}

// RequestCreateRequest represents a request to create an introduction request
type RequestCreateRequest struct {
	ApproverID      uint   `json:"approver_id" validate:"required"`
	TargetContactID uint   `json:"target_contact_id" validate:"required"`
	Message         string `json:"message" validate:"required"`
}

// RequestUpdateRequest represents a request to update an introduction request
type RequestUpdateRequest struct {
	Status          RequestStatus `json:"status" validate:"required,oneof=pending approved declined"`
	ResponseMessage string        `json:"response_message"`
}

// RequestResponse represents an introduction request in API responses
type RequestResponse struct {
	ID               uint           `json:"id"`
	Requester        UserResponse   `json:"requester"`
	Approver         UserResponse   `json:"approver"`
	TargetContact    ContactResponse `json:"target_contact"`
	Message          string         `json:"message"`
	Status           RequestStatus  `json:"status"`
	ResponseMessage  string         `json:"response_message,omitempty"`
	CreatedAt        time.Time      `json:"created_at"`
	UpdatedAt        time.Time      `json:"updated_at"`
}

// NewIntroductionRequest creates a new introduction request
func NewIntroductionRequest(req RequestCreateRequest, requesterID uint) *IntroductionRequest {
	now := time.Now()
	return &IntroductionRequest{
		RequesterID:     requesterID,
		ApproverID:      req.ApproverID,
		TargetContactID: req.TargetContactID,
		Message:         req.Message,
		Status:          RequestStatusPending,
		CreatedAt:       now,
		UpdatedAt:       now,
	}
}

// ToResponse converts an IntroductionRequest to a RequestResponse
func (r *IntroductionRequest) ToResponse(requester *User, approver *User, contact *Contact) RequestResponse {
	return RequestResponse{
		ID:              r.ID,
		Requester:       requester.ToResponse(),
		Approver:        approver.ToResponse(),
		TargetContact:   contact.ToResponse(approver),
		Message:         r.Message,
		Status:          r.Status,
		ResponseMessage: r.ResponseMessage,
		CreatedAt:       r.CreatedAt,
		UpdatedAt:       r.UpdatedAt,
	}
}
```

### Repository Interfaces

**internal/domain/repositories/user_repository.go**
```go
package repositories

import (
	"context"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// UserRepository defines the interface for user data operations
type UserRepository interface {
	// Create a new user
	Create(ctx context.Context, user *models.User) error
	
	// Get a user by ID
	GetByID(ctx context.Context, id uint) (*models.User, error)
	
	// Get a user by email
	GetByEmail(ctx context.Context, email string) (*models.User, error)
	
	// Update user information
	Update(ctx context.Context, user *models.User) error
	
	// Delete a user
	Delete(ctx context.Context, id uint) error
}
```

**internal/domain/repositories/contact_repository.go**
```go
package repositories

import (
	"context"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// ContactRepository defines the interface for contact data operations
type ContactRepository interface {
	// Create a new contact
	Create(ctx context.Context, contact *models.Contact) error
	
	// Get a contact by ID
	GetByID(ctx context.Context, id uint) (*models.Contact, error)
	
	// Get a contact by ID and ensure it belongs to the specified user
	GetByIDAndUserID(ctx context.Context, id, userID uint) (*models.Contact, error)
	
	// Get all contacts for a user
	GetAllByUserID(ctx context.Context, userID uint) ([]*models.Contact, error)
	
	// Search for contacts by name or company
	SearchByNameOrCompany(ctx context.Context, userID uint, query string) ([]*models.Contact, error)
	
	// Update a contact
	Update(ctx context.Context, contact *models.Contact) error
	
	// Delete a contact
	Delete(ctx context.Context, id, userID uint) error
	
	// Check if an email is already used for a user's contact
	IsEmailUsed(ctx context.Context, email string, userID uint) (bool, error)
}
```

**internal/domain/repositories/request_repository.go**
```go
package repositories

import (
	"context"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// RequestRepository defines the interface for introduction request data operations
type RequestRepository interface {
	// Create a new introduction request
	Create(ctx context.Context, request *models.IntroductionRequest) error
	
	// Get a request by ID
	GetByID(ctx context.Context, id uint) (*models.IntroductionRequest, error)
	
	// Get all requests where the user is the requester
	GetAllByRequesterID(ctx context.Context, requesterID uint) ([]*models.IntroductionRequest, error)
	
	// Get all requests where the user is the approver
	GetAllByApproverID(ctx context.Context, approverID uint) ([]*models.IntroductionRequest, error)
	
	// Update a request
	Update(ctx context.Context, request *models.IntroductionRequest) error
	
	// Delete a request
	Delete(ctx context.Context, id uint) error
	
	// Check if a request already exists for this requester and contact
	Exists(ctx context.Context, requesterID, targetContactID uint) (bool, error)
}
```

### Services

**internal/services/auth_service.go**
```go
package services

import (
	"context"
	"errors"
	"time"

	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/domain/repositories"
	"github.com/yourusername/intro-hub/internal/utils"
)

// AuthService handles authentication related business logic
type AuthService struct {
	userRepo     repositories.UserRepository
	jwtSecret    string
	jwtExpiryHrs int
}

// NewAuthService creates a new AuthService
func NewAuthService(
	userRepo repositories.UserRepository,
	jwtSecret string,
	jwtExpiryHrs int,
) *AuthService {
	return &AuthService{
		userRepo:     userRepo,
		jwtSecret:    jwtSecret,
		jwtExpiryHrs: jwtExpiryHrs,
	}
}

// Login authenticates a user and returns a JWT token
func (s *AuthService) Login(ctx context.Context, req models.UserLoginRequest) (string, *models.User, error) {
	// Find user by email
	user, err := s.userRepo.GetByEmail(ctx, req.Email)
	if err != nil {
		return "", nil, errors.New("invalid email or password")
	}

	// Verify password
	if !user.CheckPassword(req.Password) {
		return "", nil, errors.New("invalid email or password")
	}

	// Generate JWT token
	token, err := utils.GenerateJWT(user.ID, s.jwtSecret, time.Duration(s.jwtExpiryHrs)*time.Hour)
	if err != nil {
		return "", nil, err
	}

	return token, user, nil
}

// Register creates a new user and returns a JWT token
func (s *AuthService) Register(ctx context.Context, req models.UserSignupRequest) (string, *models.User, error) {
	// Check if user already exists
	existingUser, err := s.userRepo.GetByEmail(ctx, req.Email)
	if err == nil && existingUser != nil {
		return "", nil, errors.New("email already registered")
	}

	// Create user
	user, err := models.NewUserFromSignupRequest(req)
	if err != nil {
		return "", nil, err
	}

	// Save user to database
	if err := s.userRepo.Create(ctx, user); err != nil {
		return "", nil, err
	}

	// Generate JWT token
	token, err := utils.GenerateJWT(user.ID, s.jwtSecret, time.Duration(s.jwtExpiryHrs)*time.Hour)
	if err != nil {
		return "", nil, err
	}

	return token, user, nil
}

// GetUserByID retrieves a user by ID
func (s *AuthService) GetUserByID(ctx context.Context, id uint) (*models.User, error) {
	return s.userRepo.GetByID(ctx, id)
}
```

**internal/services/user_service.go**
```go
package services

import (
	"context"

	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/domain/repositories"
)

// UserService handles user-related business logic
type UserService struct {
	userRepo repositories.UserRepository
}

// NewUserService creates a new UserService
func NewUserService(userRepo repositories.UserRepository) *UserService {
	return &UserService{
		userRepo: userRepo,
	}
}

// GetProfile retrieves a user's profile
func (s *UserService) GetProfile(ctx context.Context, userID uint) (*models.User, error) {
	return s.userRepo.GetByID(ctx, userID)
}

// UpdateProfile updates a user's profile
func (s *UserService) UpdateProfile(ctx context.Context, userID uint, req models.UserUpdateRequest) (*models.User, error) {
	// Get existing user
	user, err := s.userRepo.GetByID(ctx, userID)
	if err != nil {
		return nil, err
	}

	// Update fields if provided
	if req.FirstName != "" {
		user.FirstName = req.FirstName
	}
	if req.LastName != "" {
		user.LastName = req.LastName
	}
	
	// These fields can be updated to empty strings
	user.Company = req.Company
	user.Position = req.Position
	user.Bio = req.Bio
	user.ProfilePicture = req.ProfilePicture

	// Save updates
	if err := s.userRepo.Update(ctx, user); err != nil {
		return nil, err
	}

	return user, nil
}
```

**internal/services/contact_service.go**
```go
package services

import (
	"context"
	"errors"

	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/domain/repositories"
)

// ContactService handles contact-related business logic
type ContactService struct {
	contactRepo repositories.ContactRepository
	userRepo    repositories.UserRepository
}

// NewContactService creates a new ContactService
func NewContactService(
	contactRepo repositories.ContactRepository,
	userRepo repositories.UserRepository,
) *ContactService {
	return &ContactService{
		contactRepo: contactRepo,
		userRepo:    userRepo,
	}
}

// CreateContact creates a new contact for a user
func (s *ContactService) CreateContact(ctx context.Context, req models.ContactCreateRequest, userID uint) (*models.Contact, error) {
	// Check if email is already used
	exists, err := s.contactRepo.IsEmailUsed(ctx, req.Email, userID)
	if err != nil {
		return nil, err
	}
	if exists {
		return nil, errors.New("email already exists for one of your contacts")
	}

	// Create contact
	contact := models.NewContactFromCreateRequest(req, userID)
	if err := s.contactRepo.Create(ctx, contact); err != nil {
		return nil, err
	}

	return contact, nil
}

// GetContact retrieves a contact by ID
func (s *ContactService) GetContact(ctx context.Context, id, userID uint) (*models.Contact, error) {
	return s.contactRepo.GetByIDAndUserID(ctx, id, userID)
}

// GetAllContacts retrieves all contacts for a user
func (s *ContactService) GetAllContacts(ctx context.Context, userID uint) ([]*models.Contact, error) {
	return s.contactRepo.GetAllByUserID(ctx, userID)
}

// SearchContacts searches for contacts by name or company
func (s *ContactService) SearchContacts(ctx context.Context, userID uint, query string) ([]*models.Contact, error) {
	return s.contactRepo.SearchByNameOrCompany(ctx, userID, query)
}

// UpdateContact updates a contact
func (s *ContactService) UpdateContact(ctx context.Context, id, userID uint, req models.ContactUpdateRequest) (*models.Contact, error) {
	// Get existing contact
	contact, err := s.contactRepo.GetByIDAndUserID(ctx, id, userID)
	if err != nil {
		return nil, err
	}

	// Check if new email is already used (if email is being updated)
	if req.Email != "" && req.Email != contact.Email {
		exists, err := s.contactRepo.IsEmailUsed(ctx, req.Email, userID)
		if err != nil {
			return nil, err
		}
		if exists {
			return nil, errors.New("email already exists for one of your contacts")
		}
		contact.Email = req.Email
	}

	// Update other fields if provided
	if req.FirstName != "" {
		contact.FirstName = req.FirstName
	}
	if req.LastName != "" {
		contact.LastName = req.LastName
	}
	
	// These fields can be updated to empty strings
	contact.Company = req.Company
	contact.Position = req.Position
	contact.Notes = req.Notes
	contact.Phone = req.Phone
	contact.LinkedInURL = req.LinkedInURL

	// Save updates
	if err := s.contactRepo.Update(ctx, contact); err != nil {
		return nil, err
	}

	return contact, nil
}

// DeleteContact deletes a contact
func (s *ContactService) DeleteContact(ctx context.Context, id, userID uint) error {
	return s.contactRepo.Delete(ctx, id, userID)
}

// BatchImportContacts imports multiple contacts at once
func (s *ContactService) BatchImportContacts(ctx context.Context, req models.ContactBatchImportRequest, userID uint) (*models.BatchImportResponse, error) {
	result := &models.BatchImportResponse{
		SuccessCount: 0,
		ErrorCount:   0,
		Errors:       []models.BatchImportError{},
	}

	for _, contactReq := range req.Contacts {
		contact := models.NewContactFromCreateRequest(contactReq, userID)
		
		// Check if email is already used
		exists, err := s.contactRepo.IsEmailUsed(ctx, contact.Email, userID)
		if err != nil {
			importError := models.BatchImportError{
				Data:   contactReq,
				Errors: []string{err.Error()},
			}
			result.Errors = append(result.Errors, importError)
			result.ErrorCount++
			continue
		}
		
		if exists {
			importError := models.BatchImportError{
				Data:   contactReq,
				Errors: []string{"email already exists for one of your contacts"},
			}
			result.Errors = append(result.Errors, importError)
			result.ErrorCount++
			continue
		}

		// Create contact
		if err := s.contactRepo.Create(ctx, contact); err != nil {
			importError := models.BatchImportError{
				Data:   contactReq,
				Errors: []string{err.Error()},
			}
			result.Errors = append(result.Errors, importError)
			result.ErrorCount++
			continue
		}

		result.SuccessCount++
	}

	return result, nil
}
```

**internal/services/request_service.go**
```go
package services

import (
	"context"
	"errors"

	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/domain/repositories"
	"github.com/yourusername/intro-hub/internal/email"
)

// RequestService handles introduction request business logic
type RequestService struct {
	requestRepo repositories.RequestRepository
	contactRepo repositories.ContactRepository
	userRepo    repositories.UserRepository
	mailer      *email.Mailer
}

// NewRequestService creates a new RequestService
func NewRequestService(
	requestRepo repositories.RequestRepository,
	contactRepo repositories.ContactRepository,
	userRepo repositories.UserRepository,
	mailer *email.Mailer,
) *RequestService {
	return &RequestService{
		requestRepo: requestRepo,
		contactRepo: contactRepo,
		userRepo:    userRepo,
		mailer:      mailer,
	}
}

// CreateRequest creates a new introduction request
func (s *RequestService) CreateRequest(ctx context.Context, req models.RequestCreateRequest, requesterID uint) (*models.IntroductionRequest, error) {
	// Verify target contact exists and belongs to approver
	contact, err := s.contactRepo.GetByID(ctx, req.TargetContactID)
	if err != nil {
		return nil, err
	}
	if contact.UserID != req.ApproverID {
		return nil, errors.New("target contact does not belong to specified approver")
	}

	// Check if a request already exists
	exists, err := s.requestRepo.Exists(ctx, requesterID, req.TargetContactID)
	if err != nil {
		return nil, err
	}
	if exists {
		return nil, errors.New("a request for this contact already exists")
	}

	// Create request
	request := models.NewIntroductionRequest(req, requesterID)
	if err := s.requestRepo.Create(ctx, request); err != nil {
		return nil, err
	}

	// Send notification to approver (asynchronously)
	go s.sendNewRequestNotification(request)

	return request, nil
}

// GetRequest retrieves a request by ID
func (s *RequestService) GetRequest(ctx context.Context, id, userID uint) (*models.IntroductionRequest, *models.User, *models.User, *models.Contact, error) {
	// Get request
	request, err := s.requestRepo.GetByID(ctx, id)
	if err != nil {
		return nil, nil, nil, nil, err
	}

	// Verify user is either requester or approver
	if request.RequesterID != userID && request.ApproverID != userID {
		return nil, nil, nil, nil, errors.New("unauthorized to access this request")
	}

	// Get requester, approver, and target contact
	requester, err := s.userRepo.GetByID(ctx, request.RequesterID)
	if err != nil {
		return nil, nil, nil, nil, err
	}

	approver, err := s.userRepo.GetByID(ctx, request.ApproverID)
	if err != nil {
		return nil, nil, nil, nil, err
	}

	contact, err := s.contactRepo.GetByID(ctx, request.TargetContactID)
	if err != nil {
		return nil, nil, nil, nil, err
	}

	return request, requester, approver, contact, nil
}

// GetRequestsByType retrieves requests by type (sent or received)
func (s *RequestService) GetRequestsByType(ctx context.Context, userID uint, isSent bool) ([]*models.IntroductionRequest, error) {
	if isSent {
		return s.requestRepo.GetAllByRequesterID(ctx, userID)
	}
	return s.requestRepo.GetAllByApproverID(ctx, userID)
}

// UpdateRequest updates a request's status
func (s *RequestService) UpdateRequest(ctx context.Context, id, userID uint, req models.RequestUpdateRequest) (*models.IntroductionRequest, error) {
	// Get request
	request, err := s.requestRepo.GetByID(ctx, id)
	if err != nil {
		return nil, err
	}

	// Verify user is the approver
	if request.ApproverID != userID {
		return nil, errors.New("only the approver can update this request")
	}

	// Update request
	request.Status = req.Status
	request.ResponseMessage = req.ResponseMessage
	if err := s.requestRepo.Update(ctx, request); err != nil {
		return nil, err
	}

	// Send notification based on status (asynchronously)
	if request.Status == models.RequestStatusApproved {
		go s.sendApprovalNotification(request)
	} else if request.Status == models.RequestStatusDeclined {
		go s.sendDeclineNotification(request)
	}

	return request, nil
}

// DeleteRequest deletes a request
func (s *RequestService) DeleteRequest(ctx context.Context, id, userID uint) error {
	// Get request
	request, err := s.requestRepo.GetByID(ctx, id)
	if err != nil {
		return err
	}

	// Verify user is the requester and request is pending
	if request.RequesterID != userID {
		return errors.New("only the requester can delete this request")
	}
	if request.Status != models.RequestStatusPending {
		return errors.New("only pending requests can be deleted")
	}

	return s.requestRepo.Delete(ctx, id)
}

// Helper functions for email notifications

func (s *RequestService) sendNewRequestNotification(request *models.IntroductionRequest) {
	ctx := context.Background()
	
	requester, err := s.userRepo.GetByID(ctx, request.RequesterID)
	if err != nil {
		return
	}
	
	approver, err := s.userRepo.GetByID(ctx, request.ApproverID)
	if err != nil {
		return
	}
	
	contact, err := s.contactRepo.GetByID(ctx, request.TargetContactID)
	if err != nil {
		return
	}
	
	s.mailer.SendNewRequestEmail(approver.Email, requester, approver, contact, request)
}

func (s *RequestService) sendApprovalNotification(request *models.IntroductionRequest) {
	ctx := context.Background()
	
	requester, err := s.userRepo.GetByID(ctx, request.RequesterID)
	if err != nil {
		return
	}
	
	approver, err := s.userRepo.GetByID(ctx, request.ApproverID)
	if err != nil {
		return
	}
	
	contact, err := s.contactRepo.GetByID(ctx, request.TargetContactID)
	if err != nil {
		return
	}
	
	s.mailer.SendRequestApprovedEmail(requester.Email, contact.Email, approver.Email, requester, approver, contact, request)
}

func (s *RequestService) sendDeclineNotification(request *models.IntroductionRequest) {
	ctx := context.Background()
	
	requester, err := s.userRepo.GetByID(ctx, request.RequesterID)
	if err != nil {
		return
	}
	
	approver, err := s.userRepo.GetByID(ctx, request.ApproverID)
	if err != nil {
		return
	}
	
	contact, err := s.contactRepo.GetByID(ctx, request.TargetContactID)
	if err != nil {
		return
	}
	
	s.mailer.SendRequestDeclinedEmail(requester.Email, requester, approver, contact, request)
}
```

### MySQL Repository Implementation

**internal/repository/mysql/mysql.go**
```go
package mysql

import (
	"database/sql"
	"fmt"

	_ "github.com/go-sql-driver/mysql"
	"github.com/golang-migrate/migrate/v4"
	"github.com/golang-migrate/migrate/v4/database/mysql"
	_ "github.com/golang-migrate/migrate/v4/source/file"
)

// NewMySQLConnection creates a new MySQL database connection
func NewMySQLConnection(dsn string) (*sql.DB, error) {
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		return nil, fmt.Errorf("error opening database: %w", err)
	}

	if err := db.Ping(); err != nil {
		return nil, fmt.Errorf("error connecting to database: %w", err)
	}

	// Configure connection pool
	db.SetMaxOpenConns(25)
	db.SetMaxIdleConns(25)

	return db, nil
}

// MigrateDatabase runs database migrations
func MigrateDatabase(dsn string) error {
	db, err := sql.Open("mysql", dsn)
	if err != nil {
		return fmt.Errorf("error opening database for migration: %w", err)
	}
	defer db.Close()

	driver, err := mysql.WithInstance(db, &mysql.Config{})
	if err != nil {
		return fmt.Errorf("error creating migration driver: %w", err)
	}

	m, err := migrate.NewWithDatabaseInstance(
		"file://internal/repository/migrations",
		"mysql",
		driver,
	)
	if err != nil {
		return fmt.Errorf("error creating migration instance: %w", err)
	}

	if err := m.Up(); err != nil && err != migrate.ErrNoChange {
		return fmt.Errorf("error running migrations: %w", err)
	}

	return nil
}
```

**internal/repository/mysql/user_repository.go**
```go
package mysql

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// UserRepository is a MySQL implementation of the UserRepository interface
type UserRepository struct {
	db *sql.DB
}

// NewUserRepository creates a new MySQL UserRepository
func NewUserRepository(db *sql.DB) *UserRepository {
	return &UserRepository{
		db: db,
	}
}

// Create adds a new user to the database
func (r *UserRepository) Create(ctx context.Context, user *models.User) error {
	query := `
		INSERT INTO users (
			email, password_hash, first_name, last_name, 
			company, position, bio, profile_picture,
			created_at, updated_at
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`

	result, err := r.db.ExecContext(
		ctx,
		query,
		strings.ToLower(user.Email),
		user.PasswordHash,
		user.FirstName,
		user.LastName,
		user.Company,
		user.Position,
		user.Bio,
		user.ProfilePicture,
		user.CreatedAt,
		user.UpdatedAt,
	)
	if err != nil {
		if strings.Contains(err.Error(), "Duplicate entry") && strings.Contains(err.Error(), "users_email_key") {
			return errors.New("email already in use")
		}
		return fmt.Errorf("error creating user: %w", err)
	}

	id, err := result.LastInsertId()
	if err != nil {
		return fmt.Errorf("error getting last insert ID: %w", err)
	}

	user.ID = uint(id)
	return nil
}

// GetByID retrieves a user by ID
func (r *UserRepository) GetByID(ctx context.Context, id uint) (*models.User, error) {
	query := `
		SELECT 
			id, email, password_hash, first_name, last_name,
			company, position, bio, profile_picture,
			created_at, updated_at
		FROM users
		WHERE id = ?
	`

	var user models.User
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&user.ID,
		&user.Email,
		&user.PasswordHash,
		&user.FirstName,
		&user.LastName,
		&user.Company,
		&user.Position,
		&user.Bio,
		&user.ProfilePicture,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.New("user not found")
		}
		return nil, fmt.Errorf("error getting user: %w", err)
	}

	return &user, nil
}

// GetByEmail retrieves a user by email
func (r *UserRepository) GetByEmail(ctx context.Context, email string) (*models.User, error) {
	query := `
		SELECT 
			id, email, password_hash, first_name, last_name,
			company, position, bio, profile_picture,
			created_at, updated_at
		FROM users
		WHERE email = ?
	`

	var user models.User
	err := r.db.QueryRowContext(ctx, query, strings.ToLower(email)).Scan(
		&user.ID,
		&user.Email,
		&user.PasswordHash,
		&user.FirstName,
		&user.LastName,
		&user.Company,
		&user.Position,
		&user.Bio,
		&user.ProfilePicture,
		&user.CreatedAt,
		&user.UpdatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.New("user not found")
		}
		return nil, fmt.Errorf("error getting user by email: %w", err)
	}

	return &user, nil
}

// Update updates user information
func (r *UserRepository) Update(ctx context.Context, user *models.User) error {
	query := `
		UPDATE users
		SET 
			first_name = ?,
			last_name = ?,
			company = ?,
			position = ?,
			bio = ?,
			profile_picture = ?,
			updated_at = ?
		WHERE id = ?
	`

	user.UpdatedAt = time.Now()
	_, err := r.db.ExecContext(
		ctx,
		query,
		user.FirstName,
		user.LastName,
		user.Company,
		user.Position,
		user.Bio,
		user.ProfilePicture,
		user.UpdatedAt,
		user.ID,
	)

	if err != nil {
		return fmt.Errorf("error updating user: %w", err)
	}

	return nil
}

// Delete removes a user
func (r *UserRepository) Delete(ctx context.Context, id uint) error {
	query := `DELETE FROM users WHERE id = ?`

	_, err := r.db.ExecContext(ctx, query, id)
	if err != nil {
		return fmt.Errorf("error deleting user: %w", err)
	}

	return nil
}
```

**internal/repository/mysql/contact_repository.go**
```go
package mysql

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"strings"
	"time"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// ContactRepository is a MySQL implementation of the ContactRepository interface
type ContactRepository struct {
	db *sql.DB
}

// NewContactRepository creates a new MySQL ContactRepository
func NewContactRepository(db *sql.DB) *ContactRepository {
	return &ContactRepository{
		db: db,
	}
}

// Create adds a new contact to the database
func (r *ContactRepository) Create(ctx context.Context, contact *models.Contact) error {
	query := `
		INSERT INTO contacts (
			user_id, email, first_name, last_name,
			company, position, notes, phone, linkedin_url,
			created_at, updated_at
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
	`

	result, err := r.db.ExecContext(
		ctx,
		query,
		contact.UserID,
		strings.ToLower(contact.Email),
		contact.FirstName,
		contact.LastName,
		contact.Company,
		contact.Position,
		contact.Notes,
		contact.Phone,
		contact.LinkedInURL,
		contact.CreatedAt,
		contact.UpdatedAt,
	)
	if err != nil {
		if strings.Contains(err.Error(), "Duplicate entry") && strings.Contains(err.Error(), "contacts_user_id_email_key") {
			return errors.New("email already exists for one of your contacts")
		}
		return fmt.Errorf("error creating contact: %w", err)
	}

	id, err := result.LastInsertId()
	if err != nil {
		return fmt.Errorf("error getting last insert ID: %w", err)
	}

	contact.ID = uint(id)
	return nil
}

// GetByID retrieves a contact by ID
func (r *ContactRepository) GetByID(ctx context.Context, id uint) (*models.Contact, error) {
	query := `
		SELECT 
			id, user_id, email, first_name, last_name,
			company, position, notes, phone, linkedin_url,
			created_at, updated_at
		FROM contacts
		WHERE id = ?
	`

	var contact models.Contact
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&contact.ID,
		&contact.UserID,
		&contact.Email,
		&contact.FirstName,
		&contact.LastName,
		&contact.Company,
		&contact.Position,
		&contact.Notes,
		&contact.Phone,
		&contact.LinkedInURL,
		&contact.CreatedAt,
		&contact.UpdatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.New("contact not found")
		}
		return nil, fmt.Errorf("error getting contact: %w", err)
	}

	return &contact, nil
}

// GetByIDAndUserID retrieves a contact by ID and ensures it belongs to the specified user
func (r *ContactRepository) GetByIDAndUserID(ctx context.Context, id, userID uint) (*models.Contact, error) {
	query := `
		SELECT 
			id, user_id, email, first_name, last_name,
			company, position, notes, phone, linkedin_url,
			created_at, updated_at
		FROM contacts
		WHERE id = ? AND user_id = ?
	`

	var contact models.Contact
	err := r.db.QueryRowContext(ctx, query, id, userID).Scan(
		&contact.ID,
		&contact.UserID,
		&contact.Email,
		&contact.FirstName,
		&contact.LastName,
		&contact.Company,
		&contact.Position,
		&contact.Notes,
		&contact.Phone,
		&contact.LinkedInURL,
		&contact.CreatedAt,
		&contact.UpdatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.New("contact not found")
		}
		return nil, fmt.Errorf("error getting contact: %w", err)
	}

	return &contact, nil
}

// GetAllByUserID retrieves all contacts for a user
func (r *ContactRepository) GetAllByUserID(ctx context.Context, userID uint) ([]*models.Contact, error) {
	query := `
		SELECT 
			id, user_id, email, first_name, last_name,
			company, position, notes, phone, linkedin_url,
			created_at, updated_at
		FROM contacts
		WHERE user_id = ?
		ORDER BY first_name, last_name
	`

	rows, err := r.db.QueryContext(ctx, query, userID)
	if err != nil {
		return nil, fmt.Errorf("error querying contacts: %w", err)
	}
	defer rows.Close()

	var contacts []*models.Contact
	for rows.Next() {
		var contact models.Contact
		if err := rows.Scan(
			&contact.ID,
			&contact.UserID,
			&contact.Email,
			&contact.FirstName,
			&contact.LastName,
			&contact.Company,
			&contact.Position,
			&contact.Notes,
			&contact.Phone,
			&contact.LinkedInURL,
			&contact.CreatedAt,
			&contact.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("error scanning contact row: %w", err)
		}
		contacts = append(contacts, &contact)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating contact rows: %w", err)
	}

	return contacts, nil
}

// SearchByNameOrCompany searches for contacts by name or company
func (r *ContactRepository) SearchByNameOrCompany(ctx context.Context, userID uint, query string) ([]*models.Contact, error) {
	searchQuery := `
		SELECT 
			id, user_id, email, first_name, last_name,
			company, position, notes, phone, linkedin_url,
			created_at, updated_at
		FROM contacts
		WHERE user_id = ? AND (
			LOWER(first_name) LIKE ? OR
			LOWER(last_name) LIKE ? OR
			LOWER(company) LIKE ?
		)
		ORDER BY first_name, last_name
	`

	searchPattern := "%" + strings.ToLower(query) + "%"
	rows, err := r.db.QueryContext(
		ctx,
		searchQuery,
		userID,
		searchPattern,
		searchPattern,
		searchPattern,
	)
	if err != nil {
		return nil, fmt.Errorf("error searching contacts: %w", err)
	}
	defer rows.Close()

	var contacts []*models.Contact
	for rows.Next() {
		var contact models.Contact
		if err := rows.Scan(
			&contact.ID,
			&contact.UserID,
			&contact.Email,
			&contact.FirstName,
			&contact.LastName,
			&contact.Company,
			&contact.Position,
			&contact.Notes,
			&contact.Phone,
			&contact.LinkedInURL,
			&contact.CreatedAt,
			&contact.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("error scanning contact row: %w", err)
		}
		contacts = append(contacts, &contact)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating contact rows: %w", err)
	}

	return contacts, nil
}

// Update updates a contact
func (r *ContactRepository) Update(ctx context.Context, contact *models.Contact) error {
	query := `
		UPDATE contacts
		SET 
			email = ?,
			first_name = ?,
			last_name = ?,
			company = ?,
			position = ?,
			notes = ?,
			phone = ?,
			linkedin_url = ?,
			updated_at = ?
		WHERE id = ? AND user_id = ?
	`

	contact.UpdatedAt = time.Now()
	result, err := r.db.ExecContext(
		ctx,
		query,
		strings.ToLower(contact.Email),
		contact.FirstName,
		contact.LastName,
		contact.Company,
		contact.Position,
		contact.Notes,
		contact.Phone,
		contact.LinkedInURL,
		contact.UpdatedAt,
		contact.ID,
		contact.UserID,
	)
	if err != nil {
		if strings.Contains(err.Error(), "Duplicate entry") && strings.Contains(err.Error(), "contacts_user_id_email_key") {
			return errors.New("email already exists for one of your contacts")
		}
		return fmt.Errorf("error updating contact: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("error getting rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return errors.New("contact not found")
	}

	return nil
}

// Delete removes a contact
func (r *ContactRepository) Delete(ctx context.Context, id, userID uint) error {
	query := `DELETE FROM contacts WHERE id = ? AND user_id = ?`

	result, err := r.db.ExecContext(ctx, query, id, userID)
	if err != nil {
		return fmt.Errorf("error deleting contact: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("error getting rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return errors.New("contact not found")
	}

	return nil
}

// IsEmailUsed checks if an email is already used for a user's contact
func (r *ContactRepository) IsEmailUsed(ctx context.Context, email string, userID uint) (bool, error) {
	query := `
		SELECT COUNT(*) 
		FROM contacts 
		WHERE email = ? AND user_id = ?
	`

	var count int
	err := r.db.QueryRowContext(ctx, query, strings.ToLower(email), userID).Scan(&count)
	if err != nil {
		return false, fmt.Errorf("error checking email usage: %w", err)
	}

	return count > 0, nil
}
```

**internal/repository/mysql/request_repository.go**
```go
package mysql

import (
	"context"
	"database/sql"
	"errors"
	"fmt"
	"time"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// RequestRepository is a MySQL implementation of the RequestRepository interface
type RequestRepository struct {
	db *sql.DB
}

// NewRequestRepository creates a new MySQL RequestRepository
func NewRequestRepository(db *sql.DB) *RequestRepository {
	return &RequestRepository{
		db: db,
	}
}

// Create adds a new introduction request to the database
func (r *RequestRepository) Create(ctx context.Context, request *models.IntroductionRequest) error {
	query := `
		INSERT INTO introduction_requests (
			requester_id, approver_id, target_contact_id,
			message, status, response_message,
			created_at, updated_at
		) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
	`

	result, err := r.db.ExecContext(
		ctx,
		query,
		request.RequesterID,
		request.ApproverID,
		request.TargetContactID,
		request.Message,
		request.Status,
		request.ResponseMessage,
		request.CreatedAt,
		request.UpdatedAt,
	)
	if err != nil {
		if err.Error() == "Error 1062: Duplicate entry" {
			return errors.New("a request for this contact already exists")
		}
		return fmt.Errorf("error creating request: %w", err)
	}

	id, err := result.LastInsertId()
	if err != nil {
		return fmt.Errorf("error getting last insert ID: %w", err)
	}

	request.ID = uint(id)
	return nil
}

// GetByID retrieves a request by ID
func (r *RequestRepository) GetByID(ctx context.Context, id uint) (*models.IntroductionRequest, error) {
	query := `
		SELECT 
			id, requester_id, approver_id, target_contact_id,
			message, status, response_message,
			created_at, updated_at
		FROM introduction_requests
		WHERE id = ?
	`

	var request models.IntroductionRequest
	var status string
	err := r.db.QueryRowContext(ctx, query, id).Scan(
		&request.ID,
		&request.RequesterID,
		&request.ApproverID,
		&request.TargetContactID,
		&request.Message,
		&status,
		&request.ResponseMessage,
		&request.CreatedAt,
		&request.UpdatedAt,
	)

	if err != nil {
		if err == sql.ErrNoRows {
			return nil, errors.New("request not found")
		}
		return nil, fmt.Errorf("error getting request: %w", err)
	}

	request.Status = models.RequestStatus(status)
	return &request, nil
}

// GetAllByRequesterID retrieves all requests where the user is the requester
func (r *RequestRepository) GetAllByRequesterID(ctx context.Context, requesterID uint) ([]*models.IntroductionRequest, error) {
	query := `
		SELECT 
			id, requester_id, approver_id, target_contact_id,
			message, status, response_message,
			created_at, updated_at
		FROM introduction_requests
		WHERE requester_id = ?
		ORDER BY created_at DESC
	`

	return r.queryRequests(ctx, query, requesterID)
}

// GetAllByApproverID retrieves all requests where the user is the approver
func (r *RequestRepository) GetAllByApproverID(ctx context.Context, approverID uint) ([]*models.IntroductionRequest, error) {
	query := `
		SELECT 
			id, requester_id, approver_id, target_contact_id,
			message, status, response_message,
			created_at, updated_at
		FROM introduction_requests
		WHERE approver_id = ?
		ORDER BY created_at DESC
	`

	return r.queryRequests(ctx, query, approverID)
}

// Update updates a request
func (r *RequestRepository) Update(ctx context.Context, request *models.IntroductionRequest) error {
	query := `
		UPDATE introduction_requests
		SET 
			status = ?,
			response_message = ?,
			updated_at = ?
		WHERE id = ?
	`

	request.UpdatedAt = time.Now()
	result, err := r.db.ExecContext(
		ctx,
		query,
		request.Status,
		request.ResponseMessage,
		request.UpdatedAt,
		request.ID,
	)
	if err != nil {
		return fmt.Errorf("error updating request: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("error getting rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return errors.New("request not found")
	}

	return nil
}

// Delete removes a request
func (r *RequestRepository) Delete(ctx context.Context, id uint) error {
	query := `DELETE FROM introduction_requests WHERE id = ?`

	result, err := r.db.ExecContext(ctx, query, id)
	if err != nil {
		return fmt.Errorf("error deleting request: %w", err)
	}

	rowsAffected, err := result.RowsAffected()
	if err != nil {
		return fmt.Errorf("error getting rows affected: %w", err)
	}

	if rowsAffected == 0 {
		return errors.New("request not found")
	}

	return nil
}

// Exists checks if a request already exists for this requester and contact
func (r *RequestRepository) Exists(ctx context.Context, requesterID, targetContactID uint) (bool, error) {
	query := `
		SELECT COUNT(*) 
		FROM introduction_requests 
		WHERE requester_id = ? AND target_contact_id = ?
	`

	var count int
	err := r.db.QueryRowContext(ctx, query, requesterID, targetContactID).Scan(&count)
	if err != nil {
		return false, fmt.Errorf("error checking request existence: %w", err)
	}

	return count > 0, nil
}

// Helper function to query requests
func (r *RequestRepository) queryRequests(ctx context.Context, query string, id uint) ([]*models.IntroductionRequest, error) {
	rows, err := r.db.QueryContext(ctx, query, id)
	if err != nil {
		return nil, fmt.Errorf("error querying requests: %w", err)
	}
	defer rows.Close()

	var requests []*models.IntroductionRequest
	for rows.Next() {
		var request models.IntroductionRequest
		var status string
		if err := rows.Scan(
			&request.ID,
			&request.RequesterID,
			&request.ApproverID,
			&request.TargetContactID,
			&request.Message,
			&status,
			&request.ResponseMessage,
			&request.CreatedAt,
			&request.UpdatedAt,
		); err != nil {
			return nil, fmt.Errorf("error scanning request row: %w", err)
		}
		request.Status = models.RequestStatus(status)
		requests = append(requests, &request)
	}

	if err := rows.Err(); err != nil {
		return nil, fmt.Errorf("error iterating request rows: %w", err)
	}

	return requests, nil
}
```

### Database Migrations

**internal/repository/migrations/000001_init_schema.up.sql**
```sql
-- Create users table
CREATE TABLE IF NOT EXISTS users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    email VARCHAR(255) NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    company VARCHAR(255),
    position VARCHAR(255),
    bio TEXT,
    profile_picture VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT users_email_key UNIQUE (email)
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Create contacts table
CREATE TABLE IF NOT EXISTS contacts (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    email VARCHAR(255) NOT NULL,
    first_name VARCHAR(100) NOT NULL,
    last_name VARCHAR(100) NOT NULL,
    company VARCHAR(255),
    position VARCHAR(255),
    notes TEXT,
    phone VARCHAR(50),
    linkedin_url VARCHAR(255),
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT contacts_user_id_email_key UNIQUE (user_id, email),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Create index for searching contacts
CREATE INDEX contacts_search_idx ON contacts (user_id, first_name, last_name, company);

-- Create introduction_requests table
CREATE TABLE IF NOT EXISTS introduction_requests (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    requester_id INT UNSIGNED NOT NULL,
    approver_id INT UNSIGNED NOT NULL,
    target_contact_id INT UNSIGNED NOT NULL,
    message TEXT NOT NULL,
    status ENUM('pending', 'approved', 'declined') NOT NULL DEFAULT 'pending',
    response_message TEXT,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT requests_requester_target_key UNIQUE (requester_id, target_contact_id),
    FOREIGN KEY (requester_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (approver_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (target_contact_id) REFERENCES contacts(id) ON DELETE CASCADE
) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;

-- Create indexes for listing requests
CREATE INDEX requests_requester_idx ON introduction_requests (requester_id);
CREATE INDEX requests_approver_idx ON introduction_requests (approver_id);
```

**internal/repository/migrations/000001_init_schema.down.sql**
```sql
-- Drop tables in reverse order to respect foreign keys
DROP TABLE IF EXISTS introduction_requests;
DROP TABLE IF EXISTS contacts;
DROP TABLE IF EXISTS users;
```

### Email Services

**internal/email/mailer.go**
```go
package email

import (
	"bytes"
	"fmt"
	"html/template"
	"log"
	"net/smtp"
	"path/filepath"

	"github.com/yourusername/intro-hub/internal/domain/models"
)

// Mailer handles sending emails
type Mailer struct {
	host     string
	port     int
	username string
	password string
	from     string
	fromName string
}

// NewMailer creates a new Mailer
func NewMailer(host string, port int, username, password, from, fromName string) *Mailer {
	return &Mailer{
		host:     host,
		port:     port,
		username: username,
		password: password,
		from:     from,
		fromName: fromName,
	}
}

// SendNewRequestEmail sends an email notification about a new introduction request
func (m *Mailer) SendNewRequestEmail(to string, requester *models.User, approver *models.User, contact *models.Contact, request *models.IntroductionRequest) error {
	subject := fmt.Sprintf("%s would like an introduction to %s", requester.FirstName+" "+requester.LastName, contact.FirstName+" "+contact.LastName)
	
	data := map[string]interface{}{
		"Requester": requester,
		"Approver":  approver,
		"Contact":   contact,
		"Request":   request,
	}
	
	return m.sendEmail(to, subject, "new_request.html", data)
}

// SendRequestApprovedEmail sends an email when a request is approved
func (m *Mailer) SendRequestApprovedEmail(toRequester, toContact, ccApprover string, requester *models.User, approver *models.User, contact *models.Contact, request *models.IntroductionRequest) error {
	subject := fmt.Sprintf("Introduction: %s <> %s", requester.FirstName+" "+requester.LastName, contact.FirstName+" "+contact.LastName)
	
	data := map[string]interface{}{
		"Requester": requester,
		"Approver":  approver,
		"Contact":   contact,
		"Request":   request,
	}
	
	// In a real implementation, you'd handle multiple recipients more gracefully
	to := []string{toRequester, toContact, ccApprover}
	return m.sendEmailToMultiple(to, subject, "request_approved.html", data)
}

// SendRequestDeclinedEmail sends an email when a request is declined
func (m *Mailer) SendRequestDeclinedEmail(to string, requester *models.User, approver *models.User, contact *models.Contact, request *models.IntroductionRequest) error {
	subject := fmt.Sprintf("Introduction request to %s was declined", contact.FirstName+" "+contact.LastName)
	
	data := map[string]interface{}{
		"Requester": requester,
		"Approver":  approver,
		"Contact":   contact,
		"Request":   request,
	}
	
	return m.sendEmail(to, subject, "request_declined.html", data)
}

// Helper method to send an email
func (m *Mailer) sendEmail(to, subject, templateFile string, data map[string]interface{}) error {
	return m.sendEmailToMultiple([]string{to}, subject, templateFile, data)
}

// Helper method to send an email to multiple recipients
func (m *Mailer) sendEmailToMultiple(to []string, subject, templateFile string, data map[string]interface{}) error {
	// Load template
	tmpl, err := template.ParseFiles(filepath.Join("internal", "email", "templates", templateFile))
	if err != nil {
		log.Printf("Error loading email template: %v", err)
		return err
	}
	
	// Render template
	var body bytes.Buffer
	if err := tmpl.Execute(&body, data); err != nil {
		log.Printf("Error rendering email template: %v", err)
		return err
	}
	
	// Prepare email
	from := fmt.Sprintf("%s <%s>", m.fromName, m.from)
	msg := []byte(fmt.Sprintf("From: %s\r\n"+
		"To: %s\r\n"+
		"Subject: %s\r\n"+
		"MIME-Version: 1.0\r\n"+
		"Content-Type: text/html; charset=UTF-8\r\n"+
		"\r\n"+
		"%s", from, to[0], subject, body.String()))
	
	// Send email
	auth := smtp.PlainAuth("", m.username, m.password, m.host)
	addr := fmt.Sprintf("%s:%d", m.host, m.port)
	
	// In a real implementation, you would handle authentication and sending more gracefully
	// Here we're just logging errors for simplicity
	if err := smtp.SendMail(addr, auth, m.from, to, msg); err != nil {
		log.Printf("Error sending email: %v", err)
		return err
	}
	
	return nil
}
```

### API Handlers

**internal/api/handlers/auth.go**
```go
package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/services"
	"github.com/yourusername/intro-hub/internal/utils"
)

// AuthHandler handles authentication-related API endpoints
type AuthHandler struct {
	authService *services.AuthService
}

// NewAuthHandler creates a new AuthHandler
func NewAuthHandler(authService *services.AuthService) *AuthHandler {
	return &AuthHandler{
		authService: authService,
	}
}

// Register godoc
// @Summary Register a new user
// @Description Register a new user and return JWT token
// @Tags auth
// @Accept json
// @Produce json
// @Param request body models.UserSignupRequest true "User registration info"
// @Success 201 {object} map[string]interface{} "User registered successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 500 {object} map[string]string "Server error"
// @Router /auth/register [post]
func (h *AuthHandler) Register(c *gin.Context) {
	var req models.UserSignupRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Register user
	token, user, err := h.authService.Register(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Return token and user data
	c.JSON(http.StatusCreated, gin.H{
		"token": token,
		"user":  user.ToResponse(),
	})
}

// Login godoc
// @Summary Login a user
// @Description Authenticate a user and return JWT token
// @Tags auth
// @Accept json
// @Produce json
// @Param request body models.UserLoginRequest true "User login credentials"
// @Success 200 {object} map[string]interface{} "User logged in successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Invalid credentials"
// @Failure 500 {object} map[string]string "Server error"
// @Router /auth/login [post]
func (h *AuthHandler) Login(c *gin.Context) {
	var req models.UserLoginRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Login user
	token, user, err := h.authService.Login(c.Request.Context(), req)
	if err != nil {
		c.JSON(http.StatusUnauthorized, gin.H{"error": err.Error()})
		return
	}

	// Return token and user data
	c.JSON(http.StatusOK, gin.H{
		"token": token,
		"user":  user.ToResponse(),
	})
}
```

**internal/api/handlers/users.go**
```go
package handlers

import (
	"net/http"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/api/middleware"
	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/services"
	"github.com/yourusername/intro-hub/internal/utils"
)

// UserHandler handles user-related API endpoints
type UserHandler struct {
	userService *services.UserService
}

// NewUserHandler creates a new UserHandler
func NewUserHandler(userService *services.UserService) *UserHandler {
	return &UserHandler{
		userService: userService,
	}
}

// GetProfile godoc
// @Summary Get user profile
// @Description Get the current user's profile
// @Tags users
// @Accept json
// @Produce json
// @Security BearerAuth
// @Success 200 {object} models.UserResponse "User profile retrieved successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /profile [get]
func (h *UserHandler) GetProfile(c *gin.Context) {
	userID := middleware.GetUserID(c)

	// Get user profile
	user, err := h.userService.GetProfile(c.Request.Context(), userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return user data
	c.JSON(http.StatusOK, user.ToResponse())
}

// UpdateProfile godoc
// @Summary Update user profile
// @Description Update the current user's profile
// @Tags users
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body models.UserUpdateRequest true "User profile update data"
// @Success 200 {object} models.UserResponse "User profile updated successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /profile [put]
func (h *UserHandler) UpdateProfile(c *gin.Context) {
	userID := middleware.GetUserID(c)

	var req models.UserUpdateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Update user profile
	user, err := h.userService.UpdateProfile(c.Request.Context(), userID, req)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return updated user data
	c.JSON(http.StatusOK, user.ToResponse())
}
```

**internal/api/handlers/contacts.go**
```go
package handlers

import (
	"net/http"
	"strconv"

	"github.com/gin-gonic/gin"
	"github.com/yourusername/intro-hub/internal/api/middleware"
	"github.com/yourusername/intro-hub/internal/domain/models"
	"github.com/yourusername/intro-hub/internal/services"
	"github.com/yourusername/intro-hub/internal/utils"
)

// ContactHandler handles contact-related API endpoints
type ContactHandler struct {
	contactService *services.ContactService
	userService    *services.UserService
}

// NewContactHandler creates a new ContactHandler
func NewContactHandler(contactService *services.ContactService, userService *services.UserService) *ContactHandler {
	return &ContactHandler{
		contactService: contactService,
		userService:    userService,
	}
}

// ListContacts godoc
// @Summary List contacts
// @Description Get all contacts for the current user
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param query query string false "Search query"
// @Success 200 {array} models.ContactResponse "Contacts retrieved successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /contacts [get]
func (h *ContactHandler) ListContacts(c *gin.Context) {
	userID := middleware.GetUserID(c)
	query := c.Query("query")

	var contacts []*models.Contact
	var err error

	// If search query is provided, search contacts
	if query != "" {
		contacts, err = h.contactService.SearchContacts(c.Request.Context(), userID, query)
	} else {
		contacts, err = h.contactService.GetAllContacts(c.Request.Context(), userID)
	}

	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Get user info for response
	user, err := h.userService.GetProfile(c.Request.Context(), userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Transform contacts to responses
	responses := make([]models.ContactResponse, len(contacts))
	for i, contact := range contacts {
		responses[i] = contact.ToResponse(user)
	}

	c.JSON(http.StatusOK, responses)
}

// GetContact godoc
// @Summary Get a contact
// @Description Get a specific contact by ID
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Contact ID"
// @Success 200 {object} models.ContactResponse "Contact retrieved successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 404 {object} map[string]string "Contact not found"
// @Failure 500 {object} map[string]string "Server error"
// @Router /contacts/{id} [get]
func (h *ContactHandler) GetContact(c *gin.Context) {
	userID := middleware.GetUserID(c)
	
	// Parse contact ID
	contactID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid contact ID"})
		return
	}

	// Get contact
	contact, err := h.contactService.GetContact(c.Request.Context(), uint(contactID), userID)
	if err != nil {
		c.JSON(http.StatusNotFound, gin.H{"error": err.Error()})
		return
	}

	// Get user info for response
	user, err := h.userService.GetProfile(c.Request.Context(), userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return contact data
	c.JSON(http.StatusOK, contact.ToResponse(user))
}

// CreateContact godoc
// @Summary Create a contact
// @Description Create a new contact for the current user
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param request body models.ContactCreateRequest true "Contact creation data"
// @Success 201 {object} models.ContactResponse "Contact created successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 500 {object} map[string]string "Server error"
// @Router /contacts [post]
func (h *ContactHandler) CreateContact(c *gin.Context) {
	userID := middleware.GetUserID(c)

	var req models.ContactCreateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Create contact
	contact, err := h.contactService.CreateContact(c.Request.Context(), req, userID)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Get user info for response
	user, err := h.userService.GetProfile(c.Request.Context(), userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return created contact
	c.JSON(http.StatusCreated, contact.ToResponse(user))
}

// UpdateContact godoc
// @Summary Update a contact
// @Description Update an existing contact
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Contact ID"
// @Param request body models.ContactUpdateRequest true "Contact update data"
// @Success 200 {object} models.ContactResponse "Contact updated successfully"
// @Failure 400 {object} map[string]string "Validation error"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 404 {object} map[string]string "Contact not found"
// @Failure 500 {object} map[string]string "Server error"
// @Router /contacts/{id} [put]
func (h *ContactHandler) UpdateContact(c *gin.Context) {
	userID := middleware.GetUserID(c)
	
	// Parse contact ID
	contactID, err := strconv.ParseUint(c.Param("id"), 10, 32)
	if err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid contact ID"})
		return
	}

	var req models.ContactUpdateRequest
	if err := c.ShouldBindJSON(&req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": "Invalid request body"})
		return
	}

	// Validate request
	if err := utils.Validate(req); err != nil {
		c.JSON(http.StatusBadRequest, gin.H{"error": err.Error()})
		return
	}

	// Update contact
	contact, err := h.contactService.UpdateContact(c.Request.Context(), uint(contactID), userID, req)
	if err != nil {
		status := http.StatusInternalServerError
		if err.Error() == "contact not found" {
			status = http.StatusNotFound
		} else if err.Error() == "email already exists for one of your contacts" {
			status = http.StatusBadRequest
		}
		c.JSON(status, gin.H{"error": err.Error()})
		return
	}

	// Get user info for response
	user, err := h.userService.GetProfile(c.Request.Context(), userID)
	if err != nil {
		c.JSON(http.StatusInternalServerError, gin.H{"error": err.Error()})
		return
	}

	// Return updated contact
	c.JSON(http.StatusOK, contact.ToResponse(user))
}

// DeleteContact godoc
// @Summary Delete a contact
// @Description Delete an existing contact
// @Tags contacts
// @Accept json
// @Produce json
// @Security BearerAuth
// @Param id path int true "Contact ID"
// @Success 204 "Contact deleted successfully"
// @Failure 401 {object} map[string]string "Unauthorized"
// @Failure 404 {object} map[string]string "Contact not found"
// @Failure 500 {