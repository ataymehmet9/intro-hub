import React, { useState, useEffect } from 'react';
import { FiSearch, FiInfo } from 'react-icons/fi';
import { apiService } from '../services/api';
import { toast } from 'react-toastify';

const Search = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [requestModalOpen, setRequestModalOpen] = useState(false);
  const [selectedContact, setSelectedContact] = useState(null);
  const [requestNote, setRequestNote] = useState('');
  const [submittingRequest, setSubmittingRequest] = useState(false);

  // Search for contacts
  const searchContacts = async (page = 1, term = '') => {
    if (!term.trim()) {
      setSearchResults([]);
      setTotalPages(1);
      return;
    }
    
    setLoading(true);
    try {
      const params = { 
        page, 
        search: term
      };
      
      const response = await apiService.searchContacts(params);
      setSearchResults(response.data.results || []);
      setTotalPages(Math.ceil(response.data.count / 10)); // Assuming page size of 10
    } catch (error) {
      console.error('Error searching contacts:', error);
      toast.error('Failed to search contacts');
    } finally {
      setLoading(false);
    }
  };

  // Handle search input submission
  const handleSearch = (e) => {
    e.preventDefault();
    setCurrentPage(1);
    searchContacts(1, searchTerm);
  };

  // Handle pagination
  const handlePageChange = (newPage) => {
    if (newPage > 0 && newPage <= totalPages) {
      setCurrentPage(newPage);
      searchContacts(newPage, searchTerm);
    }
  };

  // Open request modal
  const openRequestModal = (contact) => {
    setSelectedContact(contact);
    setRequestNote('');
    setRequestModalOpen(true);
  };

  // Close request modal
  const closeRequestModal = () => {
    setSelectedContact(null);
    setRequestModalOpen(false);
  };

  // Submit introduction request
  const submitRequest = async () => {
    if (!selectedContact) return;
    
    setSubmittingRequest(true);
    try {
      await apiService.createRequest({
        contact: selectedContact.id,
        request_notes: requestNote
      });
      
      toast.success('Introduction request sent successfully');
      closeRequestModal();
    } catch (error) {
      console.error('Error submitting request:', error);
      toast.error('Failed to send introduction request');
    } finally {
      setSubmittingRequest(false);
    }
  };

  // Render request modal
  const renderRequestModal = () => {
    if (!requestModalOpen || !selectedContact) return null;
    
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto">
        <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          <div className="fixed inset-0 transition-opacity" onClick={closeRequestModal}>
            <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
          </div>
          
          <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-lg sm:w-full">
            <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <div className="sm:flex sm:items-start">
                <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                  <FiInfo className="h-6 w-6 text-blue-600" />
                </div>
                <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">
                    Request Introduction
                  </h3>
                  <div className="mt-2">
                    <p className="text-sm text-gray-500">
                      You're requesting an introduction to <strong>{selectedContact.first_name} {selectedContact.last_name}</strong> at <strong>{selectedContact.company}</strong>.
                    </p>
                    <div className="mt-4">
                      <label htmlFor="request_note" className="block text-sm font-medium text-gray-700">
                        Why would you like this introduction?
                      </label>
                      <div className="mt-1">
                        <textarea
                          id="request_note"
                          name="request_note"
                          rows={4}
                          className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                          placeholder="Briefly explain why you'd like to be introduced to this person..."
                          value={requestNote}
                          onChange={(e) => setRequestNote(e.target.value)}
                        />
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
              <button
                type="button"
                className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                onClick={submitRequest}
                disabled={submittingRequest}
              >
                {submittingRequest ? 'Sending...' : 'Send Request'}
              </button>
              <button
                type="button"
                className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                onClick={closeRequestModal}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Find Contacts</h1>
        <p className="mt-1 text-sm text-gray-500">
          Search for contacts in other users' networks to request introductions.
        </p>
      </div>

      {/* Search form */}
      <div className="mb-6">
        <form onSubmit={handleSearch} className="flex w-full">
          <div className="relative flex-grow">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <FiSearch className="h-5 w-5 text-gray-400" />
            </div>
            <input
              type="text"
              className="focus:ring-blue-500 focus:border-blue-500 block w-full pl-10 sm:text-sm border-gray-300 rounded-md"
              placeholder="Search by name, company, or keyword..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <button
            type="submit"
            className="ml-3 inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            Search
          </button>
        </form>
      </div>

      {/* Search tips */}
      <div className="mb-6 p-4 bg-blue-50 rounded-md">
        <div className="flex">
          <div className="flex-shrink-0">
            <FiInfo className="h-5 w-5 text-blue-400" />
          </div>
          <div className="ml-3 text-sm text-blue-700">
            <h3 className="font-medium text-blue-800">Search Tips</h3>
            <p>Try searching by name, company, or industry to find relevant contacts.</p>
          </div>
        </div>
      </div>

      {/* Search results */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <ul className="divide-y divide-gray-200">
          {loading ? (
            <li className="px-6 py-4 flex items-center justify-center">
              <div className="animate-spin rounded-full h-6 w-6 border-t-2 border-b-2 border-blue-500"></div>
            </li>
          ) : searchResults.length === 0 ? (
            <li className="px-6 py-4 text-center text-gray-500">
              {searchTerm.trim() 
                ? 'No contacts found matching your search criteria.' 
                : 'Enter a search term to find contacts.'}
            </li>
          ) : (
            searchResults.map((contact) => (
              <li key={contact.id} className="hover:bg-gray-50">
                <div className="px-6 py-4 flex items-center justify-between">
                  <div>
                    <h3 className="text-base font-medium text-gray-800">
                      {contact.first_name} {contact.last_name}
                    </h3>
                    <p className="text-sm text-gray-500">
                      {contact.company || 'No company listed'}
                    </p>
                    <p className="text-xs text-gray-400 mt-1">
                      Connected to: {contact.owner_name}
                    </p>
                  </div>
                  <div>
                    <button
                      type="button"
                      onClick={() => openRequestModal(contact)}
                      className="inline-flex items-center px-3 py-1.5 border border-transparent text-xs font-medium rounded text-blue-700 bg-blue-100 hover:bg-blue-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                    >
                      Request Introduction
                    </button>
                  </div>
                </div>
              </li>
            ))
          )}
        </ul>
      </div>

      {/* Pagination */}
      {!loading && searchResults.length > 0 && totalPages > 1 && (
        <div className="flex justify-between items-center mt-6">
          <div className="flex-1 flex justify-between sm:hidden">
            <button
              onClick={() => handlePageChange(currentPage - 1)}
              disabled={currentPage === 1}
              className="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              Previous
            </button>
            <button
              onClick={() => handlePageChange(currentPage + 1)}
              disabled={currentPage === totalPages}
              className="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50 disabled:opacity-50"
            >
              Next
            </button>
          </div>
          <div className="hidden sm:flex-1 sm:flex sm:items-center sm:justify-between">
            <div>
              <p className="text-sm text-gray-700">
                Showing page <span className="font-medium">{currentPage}</span> of{' '}
                <span className="font-medium">{totalPages}</span>
              </p>
            </div>
            <div>
              <nav className="relative z-0 inline-flex rounded-md shadow-sm -space-x-px" aria-label="Pagination">
                <button
                  onClick={() => handlePageChange(currentPage - 1)}
                  disabled={currentPage === 1}
                  className="relative inline-flex items-center px-2 py-2 rounded-l-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  <span className="sr-only">Previous</span>
                  {/* Chevron left icon */}
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M12.707 5.293a1 1 0 010 1.414L9.414 10l3.293 3.293a1 1 0 01-1.414 1.414l-4-4a1 1 0 010-1.414l4-4a1 1 0 011.414 0z" clipRule="evenodd" />
                  </svg>
                </button>
                {/* Page numbers */}
                {Array.from({ length: totalPages }, (_, i) => i + 1)
                  .filter(page => 
                    page === 1 || 
                    page === totalPages || 
                    (page >= currentPage - 1 && page <= currentPage + 1)
                  )
                  .map((page, i, filtered) => (
                    <React.Fragment key={page}>
                      {i > 0 && filtered[i - 1] !== page - 1 && (
                        <span className="relative inline-flex items-center px-4 py-2 border border-gray-300 bg-white text-sm font-medium text-gray-700">
                          ...
                        </span>
                      )}
                      <button
                        onClick={() => handlePageChange(page)}
                        className={`relative inline-flex items-center px-4 py-2 border text-sm font-medium ${
                          currentPage === page
                            ? 'z-10 bg-blue-50 border-blue-500 text-blue-600'
                            : 'bg-white border-gray-300 text-gray-500 hover:bg-gray-50'
                        }`}
                      >
                        {page}
                      </button>
                    </React.Fragment>
                  ))
                }
                <button
                  onClick={() => handlePageChange(currentPage + 1)}
                  disabled={currentPage === totalPages}
                  className="relative inline-flex items-center px-2 py-2 rounded-r-md border border-gray-300 bg-white text-sm font-medium text-gray-500 hover:bg-gray-50 disabled:opacity-50"
                >
                  <span className="sr-only">Next</span>
                  {/* Chevron right icon */}
                  <svg className="h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
                    <path fillRule="evenodd" d="M7.293 14.707a1 1 0 010-1.414L10.586 10 7.293 6.707a1 1 0 011.414-1.414l4 4a1 1 0 010 1.414l-4 4a1 1 0 01-1.414 0z" clipRule="evenodd" />
                  </svg>
                </button>
              </nav>
            </div>
          </div>
        </div>
      )}

      {/* Request introduction modal */}
      {renderRequestModal()}
    </div>
  );
};

export default Search;
