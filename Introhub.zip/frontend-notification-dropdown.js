import React, { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { FiBell, FiCheck } from 'react-icons/fi';
import { useNotifications } from '../context/NotificationContext';
import { formatDistanceToNow } from '../utils/dateUtils';

const NotificationDropdown = ({ onClose }) => {
  const { notifications, loading, markAsRead, markAllAsRead } = useNotifications();
  const dropdownRef = useRef(null);

  // Format notification message based on type
  const formatNotificationMessage = (notification) => {
    return notification.message;
  };

  // Get notification link based on type and related request
  const getNotificationLink = (notification) => {
    if (notification.related_request) {
      return `/requests/${notification.related_request}`;
    }
    return '#';
  };

  // Handle click outside to close dropdown
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        onClose();
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, [onClose]);

  return (
    <div 
      ref={dropdownRef}
      className="absolute right-0 z-50 w-80 mt-2 origin-top-right bg-white rounded-md shadow-lg ring-1 ring-black ring-opacity-5"
    >
      <div className="py-2">
        {/* Header */}
        <div className="px-4 py-2 border-b flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900">Notifications</h3>
          <button
            onClick={markAllAsRead}
            className="flex items-center text-xs text-blue-600 hover:text-blue-800"
          >
            <FiCheck className="mr-1" /> Mark all as read
          </button>
        </div>

        {/* Notification List */}
        <div className="max-h-96 overflow-y-auto">
          {loading ? (
            <div className="px-4 py-2 text-center text-gray-500">Loading...</div>
          ) : notifications.length > 0 ? (
            notifications.map((notification) => (
              <Link
                key={notification.id}
                to={getNotificationLink(notification)}
                className={`block px-4 py-3 hover:bg-gray-50 transition ${!notification.is_read ? 'bg-blue-50' : ''}`}
                onClick={() => {
                  if (!notification.is_read) {
                    markAsRead(notification.id);
                  }
                  onClose();
                }}
              >
                <div className="flex items-start">
                  <div className="flex-shrink-0 mt-0.5">
                    <FiBell className={`w-5 h-5 ${!notification.is_read ? 'text-blue-600' : 'text-gray-400'}`} />
                  </div>
                  <div className="ml-3 w-0 flex-1">
                    <p className={`text-sm ${!notification.is_read ? 'font-medium text-gray-900' : 'text-gray-500'}`}>
                      {formatNotificationMessage(notification)}
                    </p>
                    <p className="mt-1 text-xs text-gray-500">
                      {formatDistanceToNow(notification.created_at)}
                    </p>
                  </div>
                </div>
              </Link>
            ))
          ) : (
            <div className="px-4 py-3 text-center text-gray-500">No notifications</div>
          )}
        </div>
      </div>
    </div>
  );
};

export default NotificationDropdown;
