from rest_framework import serializers
from django.contrib.auth.models import User
from .models import Contact, IntroductionRequest, UserProfile, Notification


class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['id', 'username', 'email', 'first_name', 'last_name']


class UserProfileSerializer(serializers.ModelSerializer):
    user = UserSerializer(read_only=True)
    
    class Meta:
        model = UserProfile
        fields = ['user', 'company', 'title', 'bio', 'linkedin_url', 
                  'profile_image', 'introductions_made', 'introductions_received']


class ContactSerializer(serializers.ModelSerializer):
    owner_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Contact
        fields = ['id', 'owner', 'owner_name', 'first_name', 'last_name', 
                  'email', 'company', 'website_domain', 'linkedin_url', 
                  'is_visible', 'notes', 'relationship_strength', 
                  'created_at', 'updated_at']
        read_only_fields = ['owner', 'owner_name', 'created_at', 'updated_at']
    
    def get_owner_name(self, obj):
        return f"{obj.owner.first_name} {obj.owner.last_name}"
    
    def create(self, validated_data):
        # Set the owner to the current user
        validated_data['owner'] = self.context['request'].user
        return super().create(validated_data)


class ContactListSerializer(serializers.ModelSerializer):
    """
    Limited serializer for displaying contacts in search results.
    Excludes sensitive information like email.
    """
    owner_name = serializers.SerializerMethodField()
    
    class Meta:
        model = Contact
        fields = ['id', 'owner_name', 'first_name', 'last_name', 
                  'company', 'website_domain']
    
    def get_owner_name(self, obj):
        return f"{obj.owner.first_name} {obj.owner.last_name}"


class IntroductionRequestSerializer(serializers.ModelSerializer):
    requester_name = serializers.SerializerMethodField()
    contact_name = serializers.SerializerMethodField()
    contact_company = serializers.SerializerMethodField()
    owner_name = serializers.SerializerMethodField()
    
    class Meta:
        model = IntroductionRequest
        fields = ['id', 'requester', 'requester_name', 'contact', 'contact_name', 
                  'contact_company', 'owner', 'owner_name', 'status', 
                  'request_notes', 'owner_notes', 'intro_email_subject', 
                  'intro_email_body', 'created_at', 'updated_at', 'completed_at']
        read_only_fields = ['requester', 'owner', 'created_at', 'updated_at', 'completed_at']
    
    def get_requester_name(self, obj):
        return f"{obj.requester.first_name} {obj.requester.last_name}"
    
    def get_contact_name(self, obj):
        return f"{obj.contact.first_name} {obj.contact.last_name}"
    
    def get_contact_company(self, obj):
        return obj.contact.company
    
    def get_owner_name(self, obj):
        return f"{obj.owner.first_name} {obj.owner.last_name}"
    
    def create(self, validated_data):
        # Set the requester to the current user
        validated_data['requester'] = self.context['request'].user
        # Set the owner to the contact's owner
        validated_data['owner'] = validated_data['contact'].owner
        return super().create(validated_data)


class CreateIntroductionRequestSerializer(serializers.ModelSerializer):
    """
    Simplified serializer for creating a new introduction request.
    """
    class Meta:
        model = IntroductionRequest
        fields = ['contact', 'request_notes']
    
    def create(self, validated_data):
        # Set the requester to the current user
        validated_data['requester'] = self.context['request'].user
        # Set the owner to the contact's owner
        validated_data['owner'] = validated_data['contact'].owner
        return super().create(validated_data)


class NotificationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Notification
        fields = ['id', 'user', 'notification_type', 'related_request', 
                  'is_read', 'message', 'created_at']
        read_only_fields = ['user', 'notification_type', 'related_request', 
                           'message', 'created_at']


class UserRegistrationSerializer(serializers.ModelSerializer):
    password = serializers.CharField(write_only=True)
    confirm_password = serializers.CharField(write_only=True)
    
    class Meta:
        model = User
        fields = ['username', 'email', 'password', 'confirm_password', 
                  'first_name', 'last_name']
    
    def validate(self, data):
        # Check if passwords match
        if data['password'] != data['confirm_password']:
            raise serializers.ValidationError({"confirm_password": "Passwords don't match"})
        return data
    
    def create(self, validated_data):
        # Remove confirm_password from validated data
        validated_data.pop('confirm_password')
        
        # Create user
        user = User.objects.create_user(
            username=validated_data['username'],
            email=validated_data['email'],
            password=validated_data['password'],
            first_name=validated_data.get('first_name', ''),
            last_name=validated_data.get('last_name', '')
        )
        
        # Create associated profile
        UserProfile.objects.create(user=user)
        
        return user
