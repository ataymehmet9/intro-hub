# Intro-Hub

Intro-Hub is a platform for facilitating warm introductions between B2B SaaS sales teams and potential leads through existing professional networks.

## Features

- **Contact Management**: Upload and manage your network of contacts available for introductions
- **Introduction Requests**: Search for contacts in other users' networks and request introductions
- **Request Approval**: Review and approve/deny introduction requests
- **Email Introductions**: Send introduction emails directly through the platform
- **User Profiles**: Manage your profile and track your introduction metrics

## Technology Stack

### Backend
- **Framework**: Django 4.2 with Django REST Framework
- **Database**: PostgreSQL (SQLite for development)
- **Authentication**: JWT (JSON Web Tokens)
- **Email**: SendGrid

### Frontend
- **Framework**: React 18 with React Router
- **UI Library**: Tailwind CSS
- **Form Handling**: Formik with Yup validation
- **API Client**: Axios
- **Notifications**: React Toastify

## Getting Started

### Prerequisites
- Python 3.8+
- Node.js 16+
- npm or yarn

### Backend Setup

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/intro-hub.git
   cd intro-hub
   ```

2. Create a virtual environment:
   ```
   cd backend
   python -m venv venv
   source venv/bin/activate  # On Windows: venv\Scripts\activate
   ```

3. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

4. Create a `.env` file in the backend directory with the following variables:
   ```
   DEBUG=True
   SECRET_KEY=your_secret_key_here
   ALLOWED_HOSTS=localhost,127.0.0.1
   ```

5. Run migrations:
   ```
   python manage.py migrate
   ```

6. Create a superuser:
   ```
   python manage.py createsuperuser
   ```

7. Start the development server:
   ```
   python manage.py runserver
   ```

### Frontend Setup

1. Navigate to the frontend directory:
   ```
   cd frontend
   ```

2. Install dependencies:
   ```
   npm install
   # or
   yarn install
   ```

3. Create a `.env` file in the frontend directory:
   ```
   REACT_APP_API_URL=http://localhost:8000/api
   ```

4. Start the development server:
   ```
   npm start
   # or
   yarn start
   ```

## Project Structure

### Backend
- `introhub/`: Main Django app
  - `models.py`: Database models
  - `serializers.py`: API serializers
  - `views.py`: API views
  - `urls.py`: URL routing
- `config/`: Project settings

### Frontend
- `src/components/`: Reusable UI components
- `src/pages/`: Main page components
- `src/context/`: React context providers
- `src/services/`: API service functions
- `src/utils/`: Utility functions

## API Endpoints

### Authentication
- `POST /api/register/`: Register a new user
- `POST /api/token/`: Get JWT token
- `POST /api/token/refresh/`: Refresh JWT token

### User Profile
- `GET /api/profile/me/`: Get current user profile
- `PATCH /api/profile/me/`: Update user profile

### Contacts
- `GET /api/contacts/`: List user's contacts
- `POST /api/contacts/`: Create a new contact
- `GET /api/contacts/{id}/`: Get a specific contact
- `PATCH /api/contacts/{id}/`: Update a contact
- `DELETE /api/contacts/{id}/`: Delete a contact
- `PATCH /api/contacts/{id}/toggle_visibility/`: Toggle contact visibility
- `POST /api/contacts/bulk_create/`: Create multiple contacts

### Contact Search
- `GET /api/search-contacts/`: Search for contacts

### Introduction Requests
- `GET /api/requests/`: List introduction requests
- `POST /api/requests/`: Create a new request
- `GET /api/requests/{id}/`: Get a specific request
- `POST /api/requests/{id}/approve/`: Approve a request
- `POST /api/requests/{id}/reject/`: Reject a request
- `POST /api/requests/{id}/send_introduction/`: Send introduction email

### Notifications
- `GET /api/notifications/`: List notifications
- `POST /api/notifications/{id}/mark_as_read/`: Mark a notification as read
- `POST /api/notifications/mark_all_as_read/`: Mark all notifications as read

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Acknowledgements

- [Django](https://www.djangoproject.com/)
- [Django REST Framework](https://www.django-rest-framework.org/)
- [React](https://reactjs.org/)
- [Tailwind CSS](https://tailwindcss.com/)
