from rest_framework import viewsets, permissions, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from rest_framework.views import APIView
from django.db.models import Q
from django.core.mail import send_mail
from django.conf import settings
from django.utils import timezone

from .models import Contact, IntroductionRequest, UserProfile, Notification
from .serializers import (
    ContactSerializer, ContactListSerializer, IntroductionRequestSerializer,
    CreateIntroductionRequestSerializer, UserProfileSerializer,
    NotificationSerializer, UserRegistrationSerializer, UserSerializer
)


class UserRegistrationView(APIView):
    """
    API endpoint for user registration.
    """
    permission_classes = [permissions.AllowAny]

    def post(self, request, *args, **kwargs):
        serializer = UserRegistrationSerializer(data=request.data)
        if serializer.is_valid():
            user = serializer.save()
            return Response(
                {"message": "User created successfully"},
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class UserProfileViewSet(viewsets.ModelViewSet):
    """
    API endpoint for user profiles.
    """
    serializer_class = UserProfileSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        # Users can only view their own profile
        return UserProfile.objects.filter(user=self.request.user)

    @action(detail=False, methods=['get'])
    def me(self, request):
        serializer = self.get_serializer(request.user.profile)
        return Response(serializer.data)


class ContactViewSet(viewsets.ModelViewSet):
    """
    API endpoint for contacts.
    """
    serializer_class = ContactSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [filters.SearchFilter]
    search_fields = ['first_name', 'last_name', 'company']

    def get_queryset(self):
        # Users can only see their own contacts
        return Contact.objects.filter(owner=self.request.user)

    @action(detail=True, methods=['patch'])
    def toggle_visibility(self, request, pk=None):
        contact = self.get_object()
        contact.is_visible = not contact.is_visible
        contact.save()
        serializer = self.get_serializer(contact)
        return Response(serializer.data)

    @action(detail=False, methods=['post'])
    def bulk_create(self, request):
        """
        Endpoint for bulk creation of contacts (e.g., from CSV upload).
        """
        serializer = self.get_serializer(data=request.data, many=True)
        if serializer.is_valid():
            serializer.save(owner=request.user)
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)


class ContactSearchViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint for searching contacts that are available for introduction.
    """
    serializer_class = ContactListSerializer
    permission_classes = [permissions.IsAuthenticated]
    filter_backends = [filters.SearchFilter]
    search_fields = ['first_name', 'last_name', 'company']

    def get_queryset(self):
        """
        Return all visible contacts that are not owned by the current user.
        """
        return Contact.objects.filter(
            is_visible=True
        ).exclude(
            owner=self.request.user
        )


class IntroductionRequestViewSet(viewsets.ModelViewSet):
    """
    API endpoint for introduction requests.
    """
    permission_classes = [permissions.IsAuthenticated]

    def get_serializer_class(self):
        if self.action == 'create':
            return CreateIntroductionRequestSerializer
        return IntroductionRequestSerializer

    def get_queryset(self):
        user = self.request.user
        # Combine requests sent by the user and requests for contacts owned by the user
        return IntroductionRequest.objects.filter(
            Q(requester=user) | Q(owner=user)
        ).distinct()

    def create(self, request, *args, **kwargs):
        """
        Create a new introduction request and notify the contact owner.
        """
        serializer = self.get_serializer(data=request.data)
        if serializer.is_valid():
            intro_request = serializer.save()
            
            # Create notification for the contact owner
            Notification.objects.create(
                user=intro_request.owner,
                notification_type='request',
                related_request=intro_request,
                message=f"{request.user.first_name} {request.user.last_name} has requested an introduction to {intro_request.contact.first_name} {intro_request.contact.last_name}."
            )
            
            return Response(
                IntroductionRequestSerializer(intro_request, context={'request': request}).data,
                status=status.HTTP_201_CREATED
            )
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    @action(detail=True, methods=['post'])
    def approve(self, request, pk=None):
        """
        Approve an introduction request.
        """
        intro_request = self.get_object()
        
        # Only the owner can approve the request
        if intro_request.owner != request.user:
            return Response(
                {"detail": "You don't have permission to approve this request."},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if the status is pending
        if intro_request.status != 'pending':
            return Response(
                {"detail": "This request has already been processed."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update the status to approved
        intro_request.status = 'approved'
        intro_request.owner_notes = request.data.get('owner_notes', '')
        intro_request.save()
        
        # Create notification for the requester
        Notification.objects.create(
            user=intro_request.requester,
            notification_type='approval',
            related_request=intro_request,
            message=f"{request.user.first_name} {request.user.last_name} has approved your introduction request to {intro_request.contact.first_name} {intro_request.contact.last_name}."
        )
        
        return Response(
            IntroductionRequestSerializer(intro_request, context={'request': request}).data
        )

    @action(detail=True, methods=['post'])
    def reject(self, request, pk=None):
        """
        Reject an introduction request.
        """
        intro_request = self.get_object()
        
        # Only the owner can reject the request
        if intro_request.owner != request.user:
            return Response(
                {"detail": "You don't have permission to reject this request."},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if the status is pending
        if intro_request.status != 'pending':
            return Response(
                {"detail": "This request has already been processed."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Update the status to rejected
        intro_request.status = 'rejected'
        intro_request.owner_notes = request.data.get('owner_notes', '')
        intro_request.save()
        
        # Create notification for the requester
        Notification.objects.create(
            user=intro_request.requester,
            notification_type='rejection',
            related_request=intro_request,
            message=f"{request.user.first_name} {request.user.last_name} has rejected your introduction request to {intro_request.contact.first_name} {intro_request.contact.last_name}."
        )
        
        return Response(
            IntroductionRequestSerializer(intro_request, context={'request': request}).data
        )

    @action(detail=True, methods=['post'])
    def send_introduction(self, request, pk=None):
        """
        Send an introduction email.
        """
        intro_request = self.get_object()
        
        # Only the owner can send the introduction
        if intro_request.owner != request.user:
            return Response(
                {"detail": "You don't have permission to send this introduction."},
                status=status.HTTP_403_FORBIDDEN
            )
        
        # Check if the status is approved
        if intro_request.status != 'approved':
            return Response(
                {"detail": "This request has not been approved yet."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Email fields
        subject = request.data.get('subject')
        body = request.data.get('body')
        
        if not subject or not body:
            return Response(
                {"detail": "Subject and body are required."},
                status=status.HTTP_400_BAD_REQUEST
            )
        
        # Store email content
        intro_request.intro_email_subject = subject
        intro_request.intro_email_body = body
        intro_request.status = 'completed'
        intro_request.completed_at = timezone.now()
        intro_request.save()
        
        # Send the email
        try:
            send_mail(
                subject,
                body,
                settings.DEFAULT_FROM_EMAIL,
                [intro_request.contact.email, intro_request.requester.email],
                fail_silently=False,
            )
            
            # Update stats
            owner_profile = intro_request.owner.profile
            owner_profile.introductions_made += 1
            owner_profile.save()
            
            requester_profile = intro_request.requester.profile
            requester_profile.introductions_received += 1
            requester_profile.save()
            
            # Create notifications
            Notification.objects.create(
                user=intro_request.requester,
                notification_type='introduction',
                related_request=intro_request,
                message=f"{request.user.first_name} {request.user.last_name} has introduced you to {intro_request.contact.first_name} {intro_request.contact.last_name}."
            )
            
            return Response({
                "message": "Introduction email sent successfully",
                "request": IntroductionRequestSerializer(intro_request, context={'request': request}).data
            })
            
        except Exception as e:
            return Response(
                {"detail": f"Failed to send email: {str(e)}"},
                status=status.HTTP_500_INTERNAL_SERVER_ERROR
            )


class NotificationViewSet(viewsets.ReadOnlyModelViewSet):
    """
    API endpoint for user notifications.
    """
    serializer_class = NotificationSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Notification.objects.filter(user=self.request.user)

    @action(detail=True, methods=['post'])
    def mark_as_read(self, request, pk=None):
        notification = self.get_object()
        notification.is_read = True
        notification.save()
        return Response(self.get_serializer(notification).data)

    @action(detail=False, methods=['post'])
    def mark_all_as_read(self, request):
        Notification.objects.filter(user=request.user, is_read=False).update(is_read=True)
        return Response({"message": "All notifications marked as read."})
