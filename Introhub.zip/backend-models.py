from django.db import models
from django.contrib.auth.models import User


class Contact(models.Model):
    """
    Represents a contact that can be introduced to others.
    """
    owner = models.ForeignKey(User, related_name='owned_contacts', on_delete=models.CASCADE)
    first_name = models.CharField(max_length=100)
    last_name = models.CharField(max_length=100)
    email = models.EmailField(blank=True, null=True)
    company = models.CharField(max_length=200, blank=True, null=True)
    website_domain = models.CharField(max_length=255, blank=True, null=True)
    linkedin_url = models.URLField(blank=True, null=True)
    
    # Visibility settings
    is_visible = models.BooleanField(default=True)
    
    # Additional optional fields
    notes = models.TextField(blank=True, null=True)
    relationship_strength = models.CharField(
        max_length=20, 
        choices=[('strong', 'Strong'), ('medium', 'Medium'), ('weak', 'Weak')],
        blank=True, 
        null=True
    )
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    
    def __str__(self):
        return f"{self.first_name} {self.last_name} ({self.company})"

    class Meta:
        unique_together = ['owner', 'email']
        ordering = ['last_name', 'first_name']


class IntroductionRequest(models.Model):
    """
    Represents a request to be introduced to a contact.
    """
    REQUEST_STATUS = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected'),
        ('completed', 'Completed'),
    ]
    
    requester = models.ForeignKey(User, related_name='introduction_requests_sent', on_delete=models.CASCADE)
    contact = models.ForeignKey(Contact, related_name='introduction_requests_received', on_delete=models.CASCADE)
    owner = models.ForeignKey(User, related_name='introduction_requests_for_owned', on_delete=models.CASCADE)
    
    status = models.CharField(max_length=20, choices=REQUEST_STATUS, default='pending')
    request_notes = models.TextField(blank=True, null=True)
    owner_notes = models.TextField(blank=True, null=True)  # Notes from contact owner to requester
    
    # Email content for introduction
    intro_email_subject = models.CharField(max_length=255, blank=True, null=True)
    intro_email_body = models.TextField(blank=True, null=True)
    
    # Timestamps
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    completed_at = models.DateTimeField(blank=True, null=True)
    
    def __str__(self):
        return f"Request from {self.requester.username} for {self.contact.first_name} {self.contact.last_name}"

    class Meta:
        ordering = ['-created_at']


class UserProfile(models.Model):
    """
    Extended profile information for users.
    """
    user = models.OneToOneField(User, on_delete=models.CASCADE, related_name='profile')
    company = models.CharField(max_length=255, blank=True, null=True)
    title = models.CharField(max_length=255, blank=True, null=True)
    bio = models.TextField(blank=True, null=True)
    linkedin_url = models.URLField(blank=True, null=True)
    profile_image = models.ImageField(upload_to='profile_images', blank=True, null=True)
    
    # Stats
    introductions_made = models.PositiveIntegerField(default=0)
    introductions_received = models.PositiveIntegerField(default=0)
    
    def __str__(self):
        return f"Profile for {self.user.username}"


class Notification(models.Model):
    """
    System notifications for users.
    """
    NOTIFICATION_TYPES = [
        ('request', 'Introduction Request'),
        ('approval', 'Request Approved'),
        ('rejection', 'Request Rejected'),
        ('introduction', 'Introduction Made'),
    ]
    
    user = models.ForeignKey(User, related_name='notifications', on_delete=models.CASCADE)
    notification_type = models.CharField(max_length=20, choices=NOTIFICATION_TYPES)
    related_request = models.ForeignKey(IntroductionRequest, on_delete=models.CASCADE, blank=True, null=True)
    is_read = models.BooleanField(default=False)
    message = models.TextField()
    created_at = models.DateTimeField(auto_now_add=True)
    
    def __str__(self):
        return f"{self.notification_type} notification for {self.user.username}"

    class Meta:
        ordering = ['-created_at']
