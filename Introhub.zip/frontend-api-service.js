import axios from 'axios';

// Create axios instance with baseURL
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:8000/api',
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add request interceptor to include auth token in requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers['Authorization'] = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add response interceptor for error handling and token refresh
api.interceptors.response.use(
  (response) => {
    return response;
  },
  async (error) => {
    const originalRequest = error.config;
    
    // If error is 401 (Unauthorized) and not already retrying
    if (error.response?.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        // Try to refresh the token
        const refreshToken = localStorage.getItem('refreshToken');
        if (!refreshToken) {
          // No refresh token available, logout
          localStorage.removeItem('token');
          localStorage.removeItem('refreshToken');
          window.location.href = '/login';
          return Promise.reject(error);
        }
        
        // Call token refresh endpoint
        const response = await axios.post(
          `${process.env.REACT_APP_API_URL || 'http://localhost:8000/api'}/token/refresh/`,
          { refresh: refreshToken }
        );
        
        if (response.data.access) {
          localStorage.setItem('token', response.data.access);
          originalRequest.headers['Authorization'] = `Bearer ${response.data.access}`;
          return api(originalRequest);
        }
      } catch (refreshError) {
        // Token refresh failed, redirect to login
        localStorage.removeItem('token');
        localStorage.removeItem('refreshToken');
        window.location.href = '/login';
        return Promise.reject(error);
      }
    }
    
    return Promise.reject(error);
  }
);

// API service methods
const apiService = {
  // Auth
  login: (credentials) => api.post('/token/', credentials),
  register: (userData) => api.post('/register/', userData),
  refreshToken: (refreshToken) => api.post('/token/refresh/', { refresh: refreshToken }),
  
  // User Profile
  getProfile: () => api.get('/profile/me/'),
  updateProfile: (profileData) => api.patch('/profile/me/', profileData),
  
  // Contacts
  getContacts: (params) => api.get('/contacts/', { params }),
  getContact: (id) => api.get(`/contacts/${id}/`),
  createContact: (contactData) => api.post('/contacts/', contactData),
  updateContact: (id, contactData) => api.patch(`/contacts/${id}/`, contactData),
  deleteContact: (id) => api.delete(`/contacts/${id}/`),
  toggleContactVisibility: (id) => api.patch(`/contacts/${id}/toggle_visibility/`),
  bulkCreateContacts: (contactsData) => api.post('/contacts/bulk_create/', contactsData),
  
  // Contact Search
  searchContacts: (params) => api.get('/search-contacts/', { params }),
  
  // Introduction Requests
  getRequests: (params) => api.get('/requests/', { params }),
  getRequest: (id) => api.get(`/requests/${id}/`),
  createRequest: (requestData) => api.post('/requests/', requestData),
  approveRequest: (id, notes) => api.post(`/requests/${id}/approve/`, { owner_notes: notes }),
  rejectRequest: (id, notes) => api.post(`/requests/${id}/reject/`, { owner_notes: notes }),
  sendIntroduction: (id, emailData) => api.post(`/requests/${id}/send_introduction/`, emailData),
  
  // Notifications
  getNotifications: () => api.get('/notifications/'),
  markNotificationAsRead: (id) => api.post(`/notifications/${id}/mark_as_read/`),
  markAllNotificationsAsRead: () => api.post('/notifications/mark_all_as_read/'),
};

export default api;
export { apiService };
