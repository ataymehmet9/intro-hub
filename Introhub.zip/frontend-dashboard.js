import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { FiUsers, FiSearch, FiMail, FiCheckCircle, FiClock } from 'react-icons/fi';
import { apiService } from '../services/api';
import { useAuth } from '../context/AuthContext';
import { useNotifications } from '../context/NotificationContext';
import { formatDateTime } from '../utils/dateUtils';

const Dashboard = () => {
  const { currentUser } = useAuth();
  const { notifications } = useNotifications();
  const [stats, setStats] = useState({
    totalContacts: 0,
    pendingRequests: 0,
    completedIntros: 0
  });
  const [recentRequests, setRecentRequests] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        setLoading(true);
        
        // Fetch contacts count
        const contactsResponse = await apiService.getContacts({ page_size: 1 });
        
        // Fetch requests
        const requestsResponse = await apiService.getRequests({ page_size: 5 });
        
        // Process the data
        const pendingRequests = requestsResponse.data.results.filter(
          req => req.status === 'pending'
        ).length;
        
        const completedIntros = requestsResponse.data.results.filter(
          req => req.status === 'completed'
        ).length;
        
        // Update state
        setStats({
          totalContacts: contactsResponse.data.count || 0,
          pendingRequests,
          completedIntros
        });
        
        setRecentRequests(requestsResponse.data.results || []);
      } catch (error) {
        console.error('Error fetching dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchDashboardData();
  }, []);

  const StatCard = ({ icon, title, value, linkTo, color }) => {
    const Icon = icon;
    return (
      <Link
        to={linkTo}
        className={`bg-white overflow-hidden shadow rounded-lg p-5 hover:shadow-md transition-shadow duration-300 border-l-4 ${color}`}
      >
        <div className="flex items-center">
          <div className={`flex-shrink-0 mr-4 p-3 rounded-full ${color.replace('border-', 'bg-').replace('-600', '-100')}`}>
            <Icon className={`h-6 w-6 ${color.replace('border-', 'text-')}`} />
          </div>
          <div>
            <div className="text-sm font-medium text-gray-500 truncate">{title}</div>
            <div className="mt-1 text-3xl font-semibold text-gray-900">{value}</div>
          </div>
        </div>
      </Link>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Welcome, {currentUser?.first_name}!</h1>
        <p className="mt-1 text-sm text-gray-500">
          Here's an overview of your activity on Intro-Hub.
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-3">
        <StatCard 
          icon={FiUsers} 
          title="Total Contacts" 
          value={stats.totalContacts}
          linkTo="/contacts"
          color="border-blue-600"
        />
        <StatCard 
          icon={FiClock} 
          title="Pending Requests" 
          value={stats.pendingRequests}
          linkTo="/requests"
          color="border-yellow-600"
        />
        <StatCard 
          icon={FiCheckCircle} 
          title="Completed Introductions" 
          value={stats.completedIntros}
          linkTo="/requests"
          color="border-green-600"
        />
      </div>

      {/* Quick Actions */}
      <div className="bg-white overflow-hidden shadow rounded-lg divide-y divide-gray-200">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg font-medium text-gray-900">Quick Actions</h3>
        </div>
        <div className="p-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
          <Link 
            to="/contacts/add" 
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            <FiUsers className="mr-2 -ml-1 h-5 w-5" />
            Add New Contact
          </Link>
          <Link 
            to="/search" 
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500"
          >
            <FiSearch className="mr-2 -ml-1 h-5 w-5" />
            Find Contacts
          </Link>
        </div>
      </div>

      {/* Recent Requests */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900">Recent Introduction Requests</h3>
          <Link to="/requests" className="text-sm font-medium text-blue-600 hover:text-blue-500">
            View All
          </Link>
        </div>
        <ul className="divide-y divide-gray-200">
          {recentRequests.length > 0 ? (
            recentRequests.map((request) => (
              <li key={request.id}>
                <Link to={`/requests/${request.id}`} className="block hover:bg-gray-50">
                  <div className="px-4 py-4 sm:px-6">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center">
                        <p className="text-sm font-medium text-blue-600 truncate">
                          {request.requester_name === `${currentUser?.first_name} ${currentUser?.last_name}`
                            ? `Request to ${request.contact_name}`
                            : `Request from ${request.requester_name} for ${request.contact_name}`}
                        </p>
                        <div className={`ml-2 flex-shrink-0 flex`}>
                          <p className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full 
                            ${request.status === 'pending' 
                              ? 'bg-yellow-100 text-yellow-800' 
                              : request.status === 'approved' 
                                ? 'bg-blue-100 text-blue-800' 
                                : request.status === 'completed' 
                                  ? 'bg-green-100 text-green-800' 
                                  : 'bg-red-100 text-red-800'}`}
                          >
                            {request.status.charAt(0).toUpperCase() + request.status.slice(1)}
                          </p>
                        </div>
                      </div>
                      <div className="ml-2 flex-shrink-0 flex">
                        <p className="text-sm text-gray-500">
                          {formatDateTime(request.created_at)}
                        </p>
                      </div>
                    </div>
                    <div className="mt-2 sm:flex sm:justify-between">
                      <div className="sm:flex">
                        <p className="flex items-center text-sm text-gray-500">
                          <span className="truncate">{request.contact_company}</span>
                        </p>
                      </div>
                    </div>
                  </div>
                </Link>
              </li>
            ))
          ) : (
            <li className="px-4 py-5 text-center text-sm text-gray-500">
              No recent requests. Start networking by searching for contacts!
            </li>
          )}
        </ul>
      </div>

      {/* Recent Notifications */}
      <div className="bg-white shadow overflow-hidden sm:rounded-md">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <h3 className="text-lg font-medium text-gray-900">Recent Notifications</h3>
        </div>
        <ul className="divide-y divide-gray-200">
          {notifications.length > 0 ? (
            notifications.slice(0, 5).map((notification) => (
              <li key={notification.id} className={`${!notification.is_read ? 'bg-blue-50' : ''}`}>
                <div className="px-4 py-4 sm:px-6">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center">
                      <FiMail className={`mr-3 h-5 w-5 ${!notification.is_read ? 'text-blue-500' : 'text-gray-400'}`} />
                      <p className="text-sm text-gray-900">
                        {notification.message}
                      </p>
                    </div>
                    <div className="ml-2 flex-shrink-0 flex">
                      <p className="text-sm text-gray-500">
                        {formatDateTime(notification.created_at)}
                      </p>
                    </div>
                  </div>
                </div>
              </li>
            ))
          ) : (
            <li className="px-4 py-5 text-center text-sm text-gray-500">
              No notifications yet.
            </li>
          )}
        </ul>
      </div>
    </div>
  );
};

export default Dashboard;
