import React from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { apiService } from '../../services/api';
import { toast } from 'react-toastify';
import { FiArrowLeft } from 'react-icons/fi';

// Validation schema for contact form
const ContactSchema = Yup.object().shape({
  first_name: Yup.string().required('First name is required'),
  last_name: Yup.string().required('Last name is required'),
  email: Yup.string().email('Invalid email format').required('Email is required'),
  company: Yup.string(),
  website_domain: Yup.string(),
  linkedin_url: Yup.string().url('Invalid URL format'),
  relationship_strength: Yup.string(),
  notes: Yup.string(),
  is_visible: Yup.boolean(),
});

const AddContact = () => {
  const navigate = useNavigate();

  // Initial form values
  const initialValues = {
    first_name: '',
    last_name: '',
    email: '',
    company: '',
    website_domain: '',
    linkedin_url: '',
    relationship_strength: '',
    notes: '',
    is_visible: true,
  };

  // Handle form submission
  const handleSubmit = async (values, { setSubmitting }) => {
    try {
      await apiService.createContact(values);
      toast.success('Contact added successfully');
      navigate('/contacts'); // Redirect to contacts list
    } catch (error) {
      console.error('Error adding contact:', error);
      toast.error('Failed to add contact');
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div>
      <div className="mb-6">
        <Link to="/contacts" className="inline-flex items-center text-blue-600 hover:text-blue-800">
          <FiArrowLeft className="mr-2" />
          Back to Contacts
        </Link>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">Add New Contact</h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            Add details of someone you'd like to introduce to others in your network.
          </p>
        </div>
        
        <div className="border-t border-gray-200">
          <Formik
            initialValues={initialValues}
            validationSchema={ContactSchema}
            onSubmit={handleSubmit}
          >
            {({ isSubmitting, setFieldValue }) => (
              <Form className="px-4 py-5 sm:p-6">
                <div className="grid grid-cols-1 gap-y-6 gap-x-4 sm:grid-cols-6">
                  {/* First Name */}
                  <div className="sm:col-span-3">
                    <label htmlFor="first_name" className="block text-sm font-medium text-gray-700">
                      First Name *
                    </label>
                    <div className="mt-1">
                      <Field
                        type="text"
                        name="first_name"
                        id="first_name"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                      <ErrorMessage name="first_name" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* Last Name */}
                  <div className="sm:col-span-3">
                    <label htmlFor="last_name" className="block text-sm font-medium text-gray-700">
                      Last Name *
                    </label>
                    <div className="mt-1">
                      <Field
                        type="text"
                        name="last_name"
                        id="last_name"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                      <ErrorMessage name="last_name" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* Email */}
                  <div className="sm:col-span-4">
                    <label htmlFor="email" className="block text-sm font-medium text-gray-700">
                      Email Address *
                    </label>
                    <div className="mt-1">
                      <Field
                        type="email"
                        name="email"
                        id="email"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                      <ErrorMessage name="email" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* Company */}
                  <div className="sm:col-span-3">
                    <label htmlFor="company" className="block text-sm font-medium text-gray-700">
                      Company
                    </label>
                    <div className="mt-1">
                      <Field
                        type="text"
                        name="company"
                        id="company"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                      <ErrorMessage name="company" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* Website Domain */}
                  <div className="sm:col-span-3">
                    <label htmlFor="website_domain" className="block text-sm font-medium text-gray-700">
                      Website Domain
                    </label>
                    <div className="mt-1">
                      <Field
                        type="text"
                        name="website_domain"
                        id="website_domain"
                        placeholder="example.com"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                      <ErrorMessage name="website_domain" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* LinkedIn URL */}
                  <div className="sm:col-span-4">
                    <label htmlFor="linkedin_url" className="block text-sm font-medium text-gray-700">
                      LinkedIn URL
                    </label>
                    <div className="mt-1">
                      <Field
                        type="text"
                        name="linkedin_url"
                        id="linkedin_url"
                        placeholder="https://www.linkedin.com/in/username"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      />
                      <ErrorMessage name="linkedin_url" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* Relationship Strength */}
                  <div className="sm:col-span-3">
                    <label htmlFor="relationship_strength" className="block text-sm font-medium text-gray-700">
                      Relationship Strength
                    </label>
                    <div className="mt-1">
                      <Field
                        as="select"
                        name="relationship_strength"
                        id="relationship_strength"
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                      >
                        <option value="">-- Select --</option>
                        <option value="strong">Strong</option>
                        <option value="medium">Medium</option>
                        <option value="weak">Weak</option>
                      </Field>
                      <ErrorMessage name="relationship_strength" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>

                  {/* Visibility */}
                  <div className="sm:col-span-3">
                    <div className="flex items-start mt-6">
                      <div className="flex items-center h-5">
                        <Field
                          type="checkbox"
                          name="is_visible"
                          id="is_visible"
                          className="focus:ring-blue-500 h-4 w-4 text-blue-600 border-gray-300 rounded"
                        />
                      </div>
                      <div className="ml-3 text-sm">
                        <label htmlFor="is_visible" className="font-medium text-gray-700">
                          Make contact visible for introduction requests
                        </label>
                        <p className="text-gray-500">
                          Others will be able to find and request introductions to this contact.
                        </p>
                      </div>
                    </div>
                  </div>

                  {/* Notes */}
                  <div className="sm:col-span-6">
                    <label htmlFor="notes" className="block text-sm font-medium text-gray-700">
                      Notes
                    </label>
                    <div className="mt-1">
                      <Field
                        as="textarea"
                        name="notes"
                        id="notes"
                        rows={3}
                        className="shadow-sm focus:ring-blue-500 focus:border-blue-500 block w-full sm:text-sm border-gray-300 rounded-md"
                        placeholder="Add any additional information about this contact..."
                      />
                      <ErrorMessage name="notes" component="div" className="mt-1 text-sm text-red-600" />
                    </div>
                  </div>
                </div>

                <div className="mt-6 flex justify-end space-x-3">
                  <Link
                    to="/contacts"
                    className="bg-white py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
                  >
                    Cancel
                  </Link>
                  <button
                    type="submit"
                    disabled={isSubmitting}
                    className="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 disabled:opacity-50"
                  >
                    {isSubmitting ? 'Saving...' : 'Save Contact'}
                  </button>
                </div>
              </Form>
            )}
          </Formik>
        </div>
      </div>
    </div>
  );
};

export default AddContact;
