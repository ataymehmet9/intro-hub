import React, { useState, useEffect } from 'react';
import { Link, useParams, useNavigate } from 'react-router-dom';
import { FiArrowLeft, FiClock, FiCheckCircle, FiXCircle, FiMail, FiUser } from 'react-icons/fi';
import { apiService } from '../../services/api';
import { toast } from 'react-toastify';
import { formatDateTime } from '../../utils/dateUtils';
import { useAuth } from '../../context/AuthContext';

const RequestDetail = () => {
  const { id } = useParams();
  const { currentUser } = useAuth();
  const navigate = useNavigate();
  
  const [request, setRequest] = useState(null);
  const [loading, setLoading] = useState(true);
  const [actionLoading, setActionLoading] = useState(false);
  const [ownerNotes, setOwnerNotes] = useState('');
  
  const [emailModalOpen, setEmailModalOpen] = useState(false);
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');

  // Fetch request details
  const fetchRequestDetails = async () => {
    setLoading(true);
    try {
      const response = await apiService.getRequest(id);
      setRequest(response.data);
      
      // Pre-populate owner notes if they exist
      if (response.data.owner_notes) {
        setOwnerNotes(response.data.owner_notes);
      }
      
      // Pre-populate email content with defaults if not set
      if (!emailSubject && !emailBody) {
        const requesterName = `${response.data.requester_name}`;
        const contactName = `${response.data.contact_name}`;
        
        setEmailSubject(`Introduction: ${requesterName} <> ${contactName}`);
        
        const defaultBody = `Hi ${contactName},

I wanted to introduce you to ${requesterName}, who I think you should meet.

${requesterName} is interested in connecting with you regarding a potential opportunity. I'll let you both take it from here.

Best,
${currentUser?.first_name}`;
        
        setEmailBody(defaultBody);
      }
    } catch (error) {
      console.error('Error fetching request details:', error);
      toast.error('Failed to load request details');
      navigate('/requests'); // Redirect back on error
    } finally {
      setLoading(false);
    }
  };

  // Load request on initial render
  useEffect(() => {
    fetchRequestDetails();
  }, [id]);

  // Check if current user is the owner of the contact
  const isOwner = () => {
    return request && currentUser && request.owner === currentUser.id;
  };

  // Check if current user is the requester
  const isRequester = () => {
    return request && currentUser && request.requester === currentUser.id;
  };

  // Approve request
  const approveRequest = async () => {
    setActionLoading(true);
    try {
      await apiService.approveRequest(id, ownerNotes);
      toast.success('Request approved successfully');
      fetchRequestDetails(); // Refresh data
    } catch (error) {
      console.error('Error approving request:', error);
      toast.error('Failed to approve request');
    } finally {
      setActionLoading(false);
    }
  };

  // Reject request
  const rejectRequest = async () => {
    setActionLoading(true);
    try {
      await apiService.rejectRequest(id, ownerNotes);
      toast.success('Request rejected successfully');
      fetchRequestDetails(); // Refresh data
    } catch (error) {
      console.error('Error rejecting request:', error);
      toast.error('Failed to reject request');
    } finally {
      setActionLoading(false);
    }
  };

  // Send introduction email
  const sendIntroduction = async () => {
    if (!emailSubject.trim() || !emailBody.trim()) {
      toast.error('Email subject and body are required');
      return;
    }
    
    setActionLoading(true);
    try {
      await apiService.sendIntroduction(id, {
        subject: emailSubject,
        body: emailBody
      });
      
      toast.success('Introduction email sent successfully');
      setEmailModalOpen(false);
      fetchRequestDetails(); // Refresh data
    } catch (error) {
      console.error('Error sending introduction email:', error);
      toast.error('Failed to send introduction email');
    } finally {
      setActionLoading(false);
    }
  };

  // Render status badge
  const renderStatusBadge = (status) => {
    switch (status) {
      case 'pending':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-yellow-100 text-yellow-800">
            <FiClock className="mr-1" /> Pending
          </span>
        );
      case 'approved':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800">
            <FiCheckCircle className="mr-1" /> Approved
          </span>
        );
      case 'rejected':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-red-100 text-red-800">
            <FiXCircle className="mr-1" /> Rejected
          </span>
        );
      case 'completed':
        return (
          <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
            <FiMail className="mr-1" /> Completed
          </span>
        );
      default:
        return null;
    }
  };

  // Render email modal
  const renderEmailModal = () => {
    if (!emailModalOpen) return null;
    
    return (
      <div className="fixed inset-0 z-50 overflow-y-auto">
        <div className="flex items-center justify-center min-h-screen pt-4 px-4 pb-20 text-center sm:block sm:p-0">
          <div className="fixed inset-0 transition-opacity" onClick={() => setEmailModalOpen(false)}>
            <div className="absolute inset-0 bg-gray-500 opacity-75"></div>
          </div>
          
          <div className="inline-block align-bottom bg-white rounded-lg text-left overflow-hidden shadow-xl transform transition-all sm:my-8 sm:align-middle sm:max-w-xl sm:w-full">
            <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
              <div className="sm:flex sm:items-start">
                <div className="mx-auto flex-shrink-0 flex items-center justify-center h-12 w-12 rounded-full bg-blue-100 sm:mx-0 sm:h-10 sm:w-10">
                  <FiMail className="h-6 w-6 text-blue-600" />
                </div>
                <div className="mt-3 text-center sm:mt-0 sm:ml-4 sm:text-left w-full">
                  <h3 className="text-lg leading-6 font-medium text-gray-900">
                    Send Introduction Email
                  </h3>
                  <div className="mt-4 w-full">
                    <div className="mb-4">
                      <label htmlFor="email_subject" className="block text-sm font-medium text-gray-700">
                        Subject
                      </label>
                      <input
                        type="text"
                        id="email_subject"
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        value={emailSubject}
                        onChange={(e) => setEmailSubject(e.target.value)}
                      />
                    </div>
                    
                    <div>
                      <label htmlFor="email_body" className="block text-sm font-medium text-gray-700">
                        Email Body
                      </label>
                      <textarea
                        id="email_body"
                        rows={10}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                        value={emailBody}
                        onChange={(e) => setEmailBody(e.target.value)}
                      />
                      <p className="mt-2 text-sm text-gray-500">
                        This email will be sent to both {request?.contact_name} and {request?.requester_name}.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
              <button
                type="button"
                className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:ml-3 sm:w-auto sm:text-sm"
                onClick={sendIntroduction}
                disabled={actionLoading}
              >
                {actionLoading ? 'Sending...' : 'Send Introduction'}
              </button>
              <button
                type="button"
                className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 sm:mt-0 sm:ml-3 sm:w-auto sm:text-sm"
                onClick={() => setEmailModalOpen(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      </div>
    );
  };

  if (loading) {
    return (
      <div className="flex justify-center items-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  if (!request) {
    return (
      <div className="text-center py-12">
        <p className="text-lg text-gray-700">Request not found</p>
        <Link to="/requests" className="mt-4 inline-flex items-center text-blue-600 hover:text-blue-800">
          <FiArrowLeft className="mr-2" />
          Back to Requests
        </Link>
      </div>
    );
  }

  return (
    <div>
      <div className="mb-6">
        <Link to="/requests" className="inline-flex items-center text-blue-600 hover:text-blue-800">
          <FiArrowLeft className="mr-2" />
          Back to Requests
        </Link>
      </div>
      
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6 flex justify-between items-center">
          <div>
            <h3 className="text-lg leading-6 font-medium text-gray-900">
              Introduction Request
            </h3>
            <p className="mt-1 max-w-2xl text-sm text-gray-500">
              {isRequester() 
                ? `Your request for introduction to ${request.contact_name}`
                : `Request from ${request.requester_name} for introduction to ${request.contact_name}`}
            </p>
          </div>
          <div>
            {renderStatusBadge(request.status)}
          </div>
        </div>
        
        <div className="border-t border-gray-200 px-4 py-5 sm:p-0">
          <dl className="sm:divide-y sm:divide-gray-200">
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Status</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {renderStatusBadge(request.status)}
                
                {request.status === 'completed' && (
                  <p className="mt-1 text-xs text-gray-500">
                    Completed on {formatDateTime(request.completed_at)}
                  </p>
                )}
              </dd>
            </div>
            
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Requester</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {request.requester_name}
                {isRequester() && <span className="ml-2 text-xs italic text-gray-500">(You)</span>}
              </dd>
            </div>
            
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Contact</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                <div>
                  <span className="font-medium">{request.contact_name}</span>
                  {request.contact_company && (
                    <span className="text-gray-500"> at {request.contact_company}</span>
                  )}
                </div>
              </dd>
            </div>
            
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Contact Owner</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {request.owner_name}
                {isOwner() && <span className="ml-2 text-xs italic text-gray-500">(You)</span>}
              </dd>
            </div>
            
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Request Date</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {formatDateTime(request.created_at)}
              </dd>
            </div>
            
            <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
              <dt className="text-sm font-medium text-gray-500">Request Notes</dt>
              <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                {request.request_notes || <span className="text-gray-500 italic">No notes provided</span>}
              </dd>
            </div>
            
            {request.owner_notes && (
              <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt className="text-sm font-medium text-gray-500">Response Notes</dt>
                <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                  {request.owner_notes}
                </dd>
              </div>
            )}
            
            {request.status === 'completed' && request.intro_email_subject && (
              <div className="py-4 sm:py-5 sm:grid sm:grid-cols-3 sm:gap-4 sm:px-6">
                <dt className="text-sm font-medium text-gray-500">Introduction Email</dt>
                <dd className="mt-1 text-sm text-gray-900 sm:mt-0 sm:col-span-2">
                  <div className="border rounded-md p-4 bg-gray-50">
                    <p className="font-medium">{request.intro_email_subject}</p>
                    <pre className="mt-2 text-sm text-gray-700 whitespace-pre-wrap">
                      {request.intro_email_body}
                    </pre>
                  </div>
                </dd>
              </div>
            )}
          </dl>
        </div>
        
        {/* Action buttons based on status and role */}
        <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
          {/* Pending actions for owner */}
          {request.status === 'pending' && isOwner() && (
            <div>
              <h4 className="text-sm font-medium text-gray-500 mb-4">Response</h4>
              <div className="mb-4">
                <label htmlFor="owner_notes" className="block text-sm font-medium text-gray-700">
                  Add notes (optional)
                </label>
                <textarea
                  id="owner_notes"
                  className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 sm:text-sm"
                  rows={3}
                  placeholder="Add any additional information for the requester..."
                  value={ownerNotes}
                  onChange={(e) => setOwnerNotes(e.target.value)}
                />
              </div>
              <div className="flex space-x-3">
                <button
                  type="button"
                  onClick={approveRequest}
                  disabled={actionLoading}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-green-600 hover:bg-green-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-green-500 disabled:opacity-50"
                >
                  <FiCheckCircle className="mr-2 -ml-1 h-5 w-5" />
                  Approve Request
                </button>
                <button
                  type="button"
                  onClick={rejectRequest}
                  disabled={actionLoading}
                  className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-red-500 disabled:opacity-50"
                >
                  <FiXCircle className="mr-2 -ml-1 h-5 w-5" />
                  Decline Request
                </button>
              </div>
            </div>
          )}
          
          {/* Approved status - introduction email action */}
          {request.status === 'approved' && isOwner() && (
            <div>
              <button
                type="button"
                onClick={() => setEmailModalOpen(true)}
                className="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
              >
                <FiMail className="mr-2 -ml-1 h-5 w-5" />
                Send Introduction Email
              </button>
            </div>
          )}
          
          {/* Pending status - for requester */}
          {request.status === 'pending' && isRequester() && (
            <p className="text-sm text-gray-500">
              Your request is pending approval from {request.owner_name}.
            </p>
          )}
          
          {/* Rejected status - for requester */}
          {request.status === 'rejected' && isRequester() && (
            <p className="text-sm text-yellow-700">
              Your request has been declined by {request.owner_name}.
            </p>
          )}
        </div>
      </div>
      
      {/* Email modal */}
      {renderEmailModal()}
    </div>
  );
};

export default RequestDetail;
