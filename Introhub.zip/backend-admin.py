from django.contrib import admin
from .models import Contact, IntroductionRequest, UserProfile, Notification


@admin.register(Contact)
class ContactAdmin(admin.ModelAdmin):
    list_display = ('id', 'first_name', 'last_name', 'company', 'owner', 'is_visible', 'created_at')
    list_filter = ('is_visible', 'relationship_strength', 'created_at')
    search_fields = ('first_name', 'last_name', 'company', 'email')
    date_hierarchy = 'created_at'


@admin.register(IntroductionRequest)
class IntroductionRequestAdmin(admin.ModelAdmin):
    list_display = ('id', 'requester', 'contact', 'owner', 'status', 'created_at')
    list_filter = ('status', 'created_at')
    search_fields = ('requester__username', 'contact__first_name', 'contact__last_name')
    date_hierarchy = 'created_at'


@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'company', 'title', 'introductions_made', 'introductions_received')
    list_filter = ('company',)
    search_fields = ('user__username', 'user__email', 'company', 'title')


@admin.register(Notification)
class NotificationAdmin(admin.ModelAdmin):
    list_display = ('id', 'user', 'notification_type', 'is_read', 'created_at')
    list_filter = ('notification_type', 'is_read', 'created_at')
    search_fields = ('user__username', 'message')
    date_hierarchy = 'created_at'
